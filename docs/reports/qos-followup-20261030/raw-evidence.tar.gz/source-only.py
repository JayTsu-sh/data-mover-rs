from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact
r=Path.cwd()
while not (r/'reproduce/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'source-only';folder.mkdir();rng=random.Random(202610307);order=[['baseline','high']]*2+[['high','baseline']]*2;rng.shuffle(order);(folder/'plan.json').write_text(json.dumps({'pairs':4,'order':order,'size_mib':512,'scope':'diagnostic only, full CIFS read concurrency, no S3 writes','binary_sha256':hashlib.sha256((r/'source-probe').read_bytes()).hexdigest()},indent=2));values={'baseline':[],'high':[]}
for i,pair in enumerate(order):
 for arm in pair:
  cmd=[str(r/'source-probe'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);label=f'{arm}-{i}';(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'source-only failed';d=json.loads(v.stdout);d['command']=cmd;(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};ratio=med['high']/med['baseline'];d={'medians':med,'ratio':ratio,'passed':ratio>=.98,'diagnostic_only':True};(folder/'summary.json').write_text(json.dumps(d,indent=2));(folder/'complete.json').write_text(json.dumps(d));print(d,flush=True)
