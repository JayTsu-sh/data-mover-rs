from pathlib import Path
import json,time,subprocess,hashlib
r=Path.cwd()
while not (r/'buffer-source-limits/complete.json').exists():time.sleep(1)
folder=r/'buffer-harness';folder.mkdir();command=['python3',str(r/'final-harness/run-backend-qos.py'),'--config',str(r/'buffer-harness-profile.private.json'),'--root',str(r),'--binary',str(r/'buffer-bin'),'--phase','survey','--repeats','3','--performance-control','--isolated-destinations','--cleanup-binary',str(r/'qos-cleanup'),'--reuse-fixtures','--retain-source','--performance-idle-ms','1000','--output',str(folder/'survey')];(folder/'plan.json').write_text(json.dumps({'command':command,'binary_sha256':hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest(),'scope':'current binary all four scenarios on isolated RAM S3; diagnostic environment, original disk results separately retained','default_write_cap':4,'performance_size_mib':512,'finite_size_mib':128,'soft_mibps':8},indent=2))
statuses=[]
for phase in ['survey','final']:
 command[command.index('--phase')+1]=phase;command[command.index('--output')+1]=str(folder/phase)
 if phase=='final':command+=['--baseline',str(folder/'survey')]
 with (folder/(phase+'.log')).open('w') as log:v=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 statuses.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'phase_exit_codes':statuses,'survey_checks':json.load(open(folder/'survey/checks.json')),'final_checks':json.load(open(folder/'final/checks.json'))},indent=2));print('Candidate public-harness phases',statuses,flush=True)
