from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib,resource,shutil,shlex
from qos_evidence import secret_values,redact,compare_performance
r=Path.cwd();assert r.name=='nightly-qos-followup-20261030045923';assert (r/'cleanup.json').exists();folder=r/'nfs-source-long';folder.mkdir(exist_ok=True);cfg=json.load(open('endpoints.private.json'));env={**os.environ,**cfg['sources']['nfs41']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);data=r/'nfs-source-long-data';golden=data/'fixtures';destination=data/'destination';golden.mkdir(parents=True);destination.mkdir(parents=True);source_root='/srv/nfs/v4/ci/'+r.name
ssh=['ssh','-i','/home/github-runner/.ssh/terrasync_lab','-o','BatchMode=yes','root@10.131.9.12']
setup="from pathlib import Path;import os,json;p=Path("+repr(source_root)+");assert p.parent==Path('/srv/nfs/v4/ci') and not p.exists();v=os.statvfs(p.parent);assert v.f_bavail*v.f_frsize>12*1024**3;p.mkdir(mode=0o755);print(json.dumps({'source_export_free_bytes':v.f_bavail*v.f_frsize,'scope':'recreate only this already-cleaned owned NFS run for source-only followup'}))"
assert shutil.disk_usage(r).free>12*1024**3
v=subprocess.run(ssh+['python3 -c '+shlex.quote(setup)],capture_output=True,text=True,timeout=20);assert v.returncode==0,'owned source setup failed';(folder/'capacity.json').write_text(v.stdout)
initial=(r/'cleanup.json').read_bytes();(r/'cleanup.before-nfs-source-long-retry.json').write_bytes(initial);statuses=[];cleanup=None
try:
 block=(r/'fixture-patterns/main-512.block.bin').read_bytes();assert len(block)==1048576
 with (golden/'4096.bin').open('wb') as f:
  for _ in range(4096):f.write(block)
 arms=['baseline','control','high'];rng=random.Random(202610327);order=[]
 for _ in range(2):
  base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle);order.extend(cycle)
 plan={'seed':202610327,'blocks':6,'order':order,'size_mib':4096,'binary':'source-probe','binary_sha256':hashlib.sha256((r/'source-probe').read_bytes()).hexdigest(),'source_and_qos_code':'identical9b source, full backend read_concurrency; no destination payload writes','purpose':'diagnose512MiB source-only92% result by length scaling and A/A; never replace original512MiB or end-to-end failures','measured_samples':18,'idle_ms':1000,'runtime_workers':4};(folder/'plan.json').write_text(json.dumps(plan,indent=2))
 seed=[str(r/'source-probe'),'--source',str(golden),'--destination',str(destination),'--path','4096.bin','--chunk-bytes','2097152','--seed'];v=subprocess.run(seed,env=env,capture_output=True,text=True,timeout=300);(folder/'seed.stderr').write_text(redact(v.stderr,secrets));assert v.returncode==0,'source long seed failed'
 values={a:[] for a in arms}
 for i,group in enumerate(order):
  for arm in group:
   label=f'{arm}-{i}';cmd=[str(r/'source-probe'),'--source',str(golden),'--destination',str(destination),'--path','4096.bin','--chunk-bytes','2097152','--idle-ms','1000']
   if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
   before=resource.getrusage(resource.RUSAGE_CHILDREN);v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);after=resource.getrusage(resource.RUSAGE_CHILDREN);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));statuses.append(v.returncode);assert v.returncode==0,'source long measurement failed';d=json.loads(v.stdout);d['command']=cmd;d['diagnostic_process_usage']={'user_seconds':after.ru_utime-before.ru_utime,'system_seconds':after.ru_stime-before.ru_stime,'voluntary_context_switches':after.ru_nvcsw-before.ru_nvcsw,'involuntary_context_switches':after.ru_nivcsw-before.ru_nivcsw};(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['seconds'],d['mibps'],d['operations'],flush=True)
 med={a:statistics.median(v) for a,v in values.items()};summary={'medians':med,'comparison':compare_performance(values['baseline'],values['high'],values['control']),'samples':18,'diagnostic_only':True,'original512MiB_failure_unchanged':True};(folder/'summary.json').write_text(json.dumps(summary,indent=2));print(summary,flush=True)
 # Same source pattern; retain only the existing small block and reconstruct the4GiB digest.
 d=json.load(open(folder/'baseline-0.json'));manifest=json.load(open(r/'fixture-patterns/manifest.json'));manifest.append({'family':'main','golden_root':str(golden),'path':'main-512.block.bin','bytes':d['bytes'],'repeat_count':4096,'block_sha256':hashlib.sha256(block).hexdigest(),'reconstructed_blake3':d['digest'],'reference':'nfs-source-long/baseline-0.json'});(r/'fixture-patterns/manifest.json').write_text(json.dumps(manifest,indent=2))
finally:
 remove="from pathlib import Path;import shutil,json;p=Path("+repr(source_root)+");assert p.parent==Path('/srv/nfs/v4/ci') and p.name=='nightly-qos-followup-20261030045923' and p.is_dir() and not p.is_symlink();shutil.rmtree(p);print(json.dumps({'owned_nfs_source_removed':not p.exists(),'scope':'only this run, no shared service change'}))"
 v=subprocess.run(ssh+['python3 -c '+shlex.quote(remove)],capture_output=True,text=True,timeout=30);assert v.returncode==0,'extra owned source cleanup failed';cleanup=json.loads(v.stdout);assert data.resolve().is_relative_to(r.resolve());shutil.rmtree(data);cleanup.update({'local_fixture_and_unused_destination_removed':not data.exists(),'payload_exit_codes':statuses,'all_payload_commands_succeeded':not any(statuses),'original_cleanup_preserved':'cleanup.before-nfs-source-long-retry.json'});(folder/'cleanup.json').write_text(json.dumps(cleanup,indent=2));existing=json.loads(initial);existing['supplemental_source_diagnostic']=cleanup;assert cleanup['owned_nfs_source_removed'] and cleanup['local_fixture_and_unused_destination_removed'];(r/'cleanup.json').write_text(json.dumps(existing,indent=2))
(folder/'complete.json').write_text(json.dumps({'samples':len(statuses),'cleanup':cleanup,'diagnostic_only':True},indent=2))
