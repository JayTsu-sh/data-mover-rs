"""Run only after all predeclared measurement blocks and explicit finish marker."""
from pathlib import Path
import json,os,subprocess,shutil,shlex,time
from urllib.parse import urlsplit,unquote
import boto3
from botocore.config import Config
r=Path.cwd();assert r.name=='nightly-qos-followup-20261030045923'
assert (r/'finish-testing').exists() and (r/'fixture-patterns/manifest.json').exists()
for folder in ['buffer-comparison','buffer-other-routes','buffer-limits','buffer-memory','buffer-local-memory','buffer-source-routes','buffer-source-limits','buffer-harness','buffer-nfs-attribution','buffer-nfs-source-only']:assert (r/folder/'complete.json').exists(),folder
cfg=json.load(open('endpoints.private.json'));run=cfg['run_id'];assert run==r.name
# Stop the dedicated RAM-backed diagnostic after verifying its empty S3 prefix.
info=json.load(open('memory-target.json'));u=urlsplit(cfg['destinations']['s3-memory']['endpoint']);bucket,host=u.hostname.split('.',1);prefix='ci/'+run+'/'
client=boto3.client('s3',endpoint_url='http://'+host+':'+str(u.port),aws_access_key_id=unquote(u.username),aws_secret_access_key=unquote(u.password),region_name='us-east-1',config=Config(proxies={},s3={'addressing_style':'path'}))
assert not client.list_objects_v2(Bucket=bucket,Prefix=prefix).get('Contents');assert not client.list_multipart_uploads(Bucket=bucket,Prefix=prefix).get('Uploads')
stop="""from pathlib import Path
import os,json,signal,time,shutil,hashlib
p=json.loads(os.environ['QOS_STOP_INFO']);root=Path(p['root']);assert str(root)=='/dev/shm/nightly-qos-followup-20261030045923';pid=p['pid'];proc=Path('/proc')/str(pid);cmd=(proc/'cmdline').read_bytes().split(bytes([0]));assert str(root).encode() in cmd and os.readlink(proc/'exe')=='/usr/local/bin/rustfs';assert os.getpgid(pid)==pid;shared=Path('/proc/816');before=(shared/'cmdline').read_bytes();shared_hash=hashlib.sha256(Path(os.readlink(shared/'exe')).read_bytes()).hexdigest();os.killpg(pid,signal.SIGTERM)
for _ in range(100):
 if not proc.exists() or (proc/'stat').read_text().split()[2]=='Z':break
 time.sleep(.1)
else:raise RuntimeError('owned diagnostic process did not stop')
shutil.rmtree(root);logs=Path('/var/lib/terrasync-ci')/root.name
for name in ['memory-server.private.log','memory-server.json']:
 path=logs/name
 if path.exists():path.unlink()
assert (shared/'cmdline').read_bytes()==before
print(json.dumps({'owned_pid':pid,'stopped':True,'ram_root_removed':not root.exists(),'shared_pid':816,'shared_process_unchanged':True,'shared_exe_sha256':shared_hash}))
"""
command='QOS_STOP_INFO='+shlex.quote(json.dumps(info))+' python3 -c '+shlex.quote(stop)
v=subprocess.run(['ssh','-i','/home/github-runner/.ssh/terrasync_lab','-o','BatchMode=yes','root@10.131.9.13',command],capture_output=True,text=True,timeout=30);assert v.returncode==0,'owned memory diagnostic cleanup failed';memory=json.loads(v.stdout);(r/'memory-cleanup.json').write_text(json.dumps(memory,indent=2))
statuses=[]
env={**os.environ,**cfg['sources']['cifs']['env'],'QOS_SOURCE':'smb:'+run};v=subprocess.run(['./qos-cleanup','--run-id',run,'--tree'],env=env,capture_output=True,text=True,timeout=120);(r/'cleanup-cifs-tree.log').write_text(v.stdout+v.stderr);statuses.append(['cifs','tree',v.returncode]);assert v.returncode==0
env['QOS_SOURCE']='smb:';v=subprocess.run(['./buffer-bin','--source','fixtures','--destination','destination','--path',run,'--chunk-bytes','2097152','--cleanup'],env=env,capture_output=True,text=True,timeout=60);(r/'cleanup-cifs-root.log').write_text(v.stdout+v.stderr);statuses.append(['cifs','run-root',v.returncode]);assert v.returncode==0
shell='set -euo pipefail; source ./common.sh; require_s3_credentials; export LAB_HDFS_LOCATION="hdfs://hdfs%2Fterrasync-runner%40HDFS.LOCAL@hdfs-ha/" LAB_HDFS_ADMIN_USER="hdfs/terrasync-runner@HDFS.LOCAL" LAB_HDFS_CONFIG_DIR="/var/lib/data-mover-lab/hadoop" LAB_HDFS_KEYTAB="/var/lib/data-mover-lab/terrasync-runner.keytab"; ./cleanup-run.sh '+run
with (r/'cleanup-standard.log').open('w') as log:v=subprocess.run(['bash','-c',shell],stdout=log,stderr=subprocess.STDOUT,timeout=240)
statuses.append(['standard','lifecycle',v.returncode]);assert v.returncode==0
for relative in ['source','destination','fixtures','fresh-fixture-smoke/fixtures','fresh-fixture-smoke/destination']:
 path=r/relative;assert path.resolve().is_relative_to(r.resolve())
 if path.exists():shutil.rmtree(path)
(r/'cleanup-status.json').write_text(json.dumps(statuses,indent=2))
# Final exact-prefix check also removes versions/delete markers if bucket versioning changes.
src=cfg['sources']['s3']['env'];host=src['S3_HOST'];host=host if '://' in host else 'http://'+host;p=urlsplit(cfg['destinations']['s3']['endpoint']);bucket,host=p.hostname.split('.',1);rows=[]
for label,endpoint,ak,sk,bucket in [('source',src['S3_HOST'] if '://' in src['S3_HOST'] else 'http://'+src['S3_HOST'],src['S3_AK'],src['S3_SK'],src['S3_BUCKET']),('destination','http://'+host+':'+str(p.port or 9000),unquote(p.username),unquote(p.password),bucket)]:
 s3=boto3.client('s3',endpoint_url=endpoint,aws_access_key_id=ak,aws_secret_access_key=sk,region_name='us-east-1',config=Config(proxies={},s3={'addressing_style':'path'}));versioning=s3.get_bucket_versioning(Bucket=bucket).get('Status','Unversioned');deleted=aborted=0
 for _ in range(100):
  uploads=s3.list_multipart_uploads(Bucket=bucket,Prefix=prefix).get('Uploads',[])
  if not uploads:break
  for upload in uploads:assert upload['Key'].startswith(prefix);s3.abort_multipart_upload(Bucket=bucket,Key=upload['Key'],UploadId=upload['UploadId']);aborted+=1
 else:raise RuntimeError('multipart cleanup did not converge')
 for _ in range(100):
  result=s3.list_object_versions(Bucket=bucket,Prefix=prefix);objects=[{'Key':v['Key'],'VersionId':v['VersionId']} for kind in ['Versions','DeleteMarkers'] for v in result.get(kind,[])]
  if not objects:break
  assert all(v['Key'].startswith(prefix) for v in objects);answer=s3.delete_objects(Bucket=bucket,Delete={'Objects':objects,'Quiet':True});assert not answer.get('Errors');deleted+=len(objects)
 else:raise RuntimeError('version cleanup did not converge')
 assert not s3.list_objects_v2(Bucket=bucket,Prefix=prefix).get('Contents');rows.append({'endpoint':label,'prefix':prefix,'versioning':versioning,'extra_versions_and_markers_deleted':deleted,'multipart_aborted':aborted,'empty':True})
remaining=[relative for relative in ['source','destination','fixtures','fresh-fixture-smoke/fixtures','fresh-fixture-smoke/destination'] if (r/relative).exists()];assert not remaining
(r/'cleanup.json').write_text(json.dumps({'lifecycle':statuses,'s3':rows,'memory':memory,'all_lifecycle_operations_succeeded':all(v[-1]==0 for v in statuses),'data_directories_remaining':remaining,'nfs40':'not used or created in this followup; no unrelated export touched','scope':'exact isolated run only; shared services/keytab unchanged'},indent=2));print('All exact-run lifecycle cleanup succeeded; two shared S3 prefixes empty; private RAM diagnostic stopped and removed.')
