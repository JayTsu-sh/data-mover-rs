"""Protect credentials and the provenance of QoS lab artifacts."""
import math
from pathlib import Path
import re
import random
import statistics
from urllib.parse import unquote, urlsplit, urlunsplit


def secret_values(environments):
    secrets = set()
    for environment in environments:
        for key, value in environment.items():
            if any(part in key.upper() for part in
                   ("PASS", "SECRET", "_AK", "_SK", "TOKEN", "ACCESS_KEY", "API_KEY")):
                secrets.add(value)
            try:
                parsed = urlsplit(value)
                if parsed.password:
                    secrets.update((parsed.password, unquote(parsed.password)))
                    if parsed.username:
                        secrets.update((parsed.username, unquote(parsed.username)))
            except ValueError:
                pass
    return sorted((value for value in secrets if value), key=len, reverse=True)


def redact(value, secrets):
    for secret in secrets:
        value = value.replace(secret, "<REDACTED>")
    return value


def verify_baseline_identity(measured, configuration_sha256, binary_sha256, repetitions, idle_ms,
                             *, performance_control=False, isolated_destinations=False):
    if measured.get("configuration_sha256") != configuration_sha256:
        raise ValueError("baseline and source/destination configuration differ")
    if measured["binary_sha256"] != binary_sha256:
        raise ValueError("baseline and candidate binary differ")
    if measured["repetitions"] != repetitions:
        raise ValueError("baseline and candidate repetition counts differ")
    if measured.get("performance_idle_ms", 0) != idle_ms:
        raise ValueError("baseline and candidate unmeasured idle differ")
    if measured.get("performance_control", False) != performance_control:
        raise ValueError("baseline and candidate A/A controls differ")
    if measured.get("isolated_destinations", False) != isolated_destinations:
        raise ValueError("baseline and candidate destination lifecycles differ")


def sample_destination(endpoint, sample_id):
    """Append an owned sample prefix without changing URL credentials or options."""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", sample_id):
        raise ValueError("a safe, single-component sample identifier is required")
    suffix = "qos-samples/" + sample_id
    if "://" in endpoint or endpoint.startswith(("smb:", "s3:", "s3@")):
        parsed = urlsplit(endpoint)
        return urlunsplit(parsed._replace(path=parsed.path.rstrip("/") + "/" + suffix))
    return str(Path(endpoint) / suffix)


def verify_isolated_destination(endpoint, run_id):
    """Reject an uncleanable destination before a timed copy can create data."""
    if (len(run_id) > 88 or ".." in run_id or
            not re.fullmatch(r"(?:nightly|release)-[A-Za-z0-9_.-]+", run_id)):
        raise ValueError("a valid isolated lab run identifier is required")
    path = urlsplit(endpoint).path if "://" in endpoint or endpoint.startswith(("smb:", "s3:", "s3@")) else endpoint
    if run_id not in path.split("/"):
        raise ValueError("destination must contain the exact isolated run path component")


def compare_performance(baseline, high, control=None):
    """Keep the raw 98% verdict; a noisy identical baseline cannot qualify it."""
    series = [baseline, high] + ([] if control is None else [control])
    if not baseline or any(len(values) != len(baseline) for values in series):
        raise ValueError("performance arms must have equal nonempty sample counts")
    if any(not math.isfinite(value) or value <= 0 for values in series for value in values):
        raise ValueError("performance samples must be positive finite rates")
    baseline_rate, high_rate = statistics.median(baseline), statistics.median(high)
    ratio = high_rate / baseline_rate
    passed = high_rate >= baseline_rate * .98
    result = dict(baseline_mibps=baseline_rate, high_mibps=high_rate, ratio=ratio, passed=passed)
    if control is not None:
        control_rate = statistics.median(control)
        control_ratio = control_rate / baseline_rate
        # Resample whole blocks: A, control-A and high share the same local load
        # history. A matching median alone can hide very noisy identical arms.
        rng = random.Random(20261030)
        control_ratios = []
        high_ratios = []
        for _ in range(4000):
            indices = rng.choices(range(len(baseline)), k=len(baseline))
            base = statistics.median(baseline[i] for i in indices)
            control_ratios.append(statistics.median(control[i] for i in indices) / base)
            high_ratios.append(statistics.median(high[i] for i in indices) / base)
        control_ratios.sort()
        high_ratios.sort()
        control_interval = [control_ratios[99], control_ratios[3900]]
        high_interval = [high_ratios[99], high_ratios[3900]]
        repeatable = control_interval[0] >= .98 and control_interval[1] <= 1 / .98
        result.update(control_mibps=control_rate, control_ratio=control_ratio,
                      control_ratio_interval_95=control_interval, high_ratio_interval_95=high_interval,
                      interval_method="paired-block percentile bootstrap, 4000 draws, seed 20261030; diagnostic precision guard",
                      control_repeatable=repeatable,
                      qualified=passed and repeatable and high_interval[0] >= .98,
                      classification=("environment_not_repeatable" if not repeatable else
                                      "insufficient_precision" if high_interval[0] < .98 <= high_interval[1] else
                                      "passed" if passed else "below_98_percent"))
    return result
