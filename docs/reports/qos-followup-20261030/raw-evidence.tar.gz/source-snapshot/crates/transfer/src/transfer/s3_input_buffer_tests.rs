//! Exercise producer backpressure through the real multipart destination.
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Duration;

use async_trait::async_trait;
use bytes::Bytes;
use futures::{FutureExt as _, StreamExt as _};
use tokio::sync::Semaphore;
use tokio_util::sync::CancellationToken;

use super::{ReadBackVerification, TransferPolicy, TransferRequest, transfer};
use crate::model::{
    BackendIdentity, BackendKind, EntryKind, IdentityStrength, SourceIdentity, StoragePath,
};
use crate::storage::backends::s3::{
    connect,
    tests::{MemoryS3, identity},
};
use crate::storage::{
    BackendCapabilities, ByteStream, CapabilityAvailability, ReadRequest, ReadSource,
    SourceDescriptor, SourceQosGroup, SourceQosPolicy, StorageBuilder, StorageRoleFailure,
    UnsupportedReason,
};

const MIB: usize = 1024 * 1024;
const SIZE: u64 = 48 * 1024 * 1024;
const NEXT_PART_READY: usize = 40 * MIB;

struct ChunkSource {
    descriptor: SourceDescriptor,
    chunk_bytes: usize,
    emitted: Arc<AtomicUsize>,
    release_uploads: Arc<Semaphore>,
}

#[async_trait]
impl ReadSource for ChunkSource {
    fn maximum_read_chunk_bytes(&self) -> usize {
        self.chunk_bytes
    }

    async fn describe(&self, _: &StoragePath) -> Result<SourceDescriptor, StorageRoleFailure> {
        Ok(self.descriptor.clone())
    }

    async fn read(&self, request: ReadRequest) -> Result<ByteStream, StorageRoleFailure> {
        let bytes = Bytes::from(vec![42; self.chunk_bytes]);
        let emitted = self.emitted.clone();
        let release = self.release_uploads.clone();
        Ok(Box::pin(
            futures::stream::iter(0..48 * MIB / self.chunk_bytes).then(move |_| {
                let bytes = bytes.clone();
                let emitted = emitted.clone();
                let release = release.clone();
                let budget = request.source_qos.clone();
                let cancel = request.cancel.clone();
                async move {
                    if let Some(budget) = budget {
                        let length =
                            u64::try_from(bytes.len()).unwrap_or_else(|error| panic!("{error}"));
                        assert_eq!(budget.admit_read(length, &cancel).await, Ok(length));
                        budget.record_read_bytes(length);
                    }
                    let before = emitted.fetch_add(bytes.len(), Ordering::SeqCst);
                    if before < NEXT_PART_READY && before + bytes.len() >= NEXT_PART_READY {
                        release.add_permits(4);
                    }
                    Ok(bytes)
                }
            }),
        ))
    }
}

#[tokio::test]
async fn multipart_window_has_a_complete_next_part_queued_for_small_source_chunks()
-> Result<(), Box<dyn std::error::Error>> {
    let mut expected = blake3::Hasher::new();
    let pattern = vec![42; MIB];
    for _ in 0..48 {
        expected.update(&pattern);
    }
    let expected = expected.finalize();
    for chunk_bytes in [MIB, 2 * MIB, 8 * MIB] {
        for shaped in [false, true] {
            let protocol = Arc::new(MemoryS3::default());
            let release = Arc::new(Semaphore::new(0));
            *protocol.upload_part_hook.lock().await = Some(Arc::new({
                let release = release.clone();
                move |number| {
                    let release = release.clone();
                    async move {
                        if number <= 4 {
                            release
                                .acquire()
                                .await
                                .unwrap_or_else(|error| panic!("{error}"))
                                .forget();
                        }
                    }
                    .boxed()
                }
            }));
            let source_id =
                BackendIdentity::new("cifs".parse::<BackendKind>()?, "multipart-input-buffer")?;
            let path = StoragePath::new(format!("buffer-{chunk_bytes}-{shaped}"))?;
            let reader = Arc::new(ChunkSource {
                descriptor: SourceDescriptor::new(
                    path.clone(),
                    EntryKind::File,
                    Some(SIZE),
                    SourceIdentity::new(
                        source_id.clone(),
                        IdentityStrength::PathScoped,
                        b"source",
                    )?,
                ),
                chunk_bytes,
                emitted: Arc::default(),
                release_uploads: release,
            });
            let unsupported =
                CapabilityAvailability::Unsupported(UnsupportedReason::new("read-only fixture")?);
            let source = StorageBuilder::new(
                source_id,
                BackendCapabilities::new(
                    CapabilityAvailability::Supported,
                    unsupported.clone(),
                    unsupported.clone(),
                    unsupported,
                ),
            )
            .read_source(reader.clone())
            .build()?;
            let destination = connect(protocol.clone(), identity(), None)?;
            let mut request =
                TransferRequest::new(source, path.clone(), destination, CancellationToken::new())
                    .with_transfer_policy(TransferPolicy::AtomicReplace)
                    .with_read_back_verification(ReadBackVerification::Disabled);
            if shaped {
                request = request.with_source_qos(SourceQosGroup::new(SourceQosPolicy::new(
                    Some((1 << 40, 1 << 40, Duration::ZERO)),
                    u64::try_from(chunk_bytes)?,
                    Some((1_000_000_000, 1_000_000_000, Duration::ZERO)),
                )?));
            }
            let outcome = tokio::time::timeout(Duration::from_secs(2), transfer(request)).await
                .map_err(|_| format!("only {} bytes delivered before the full upload window; need {NEXT_PART_READY}", reader.emitted.load(Ordering::SeqCst)))??;
            assert_eq!(outcome.transferred_bytes, SIZE);
            assert_eq!(*protocol.part_uploads.lock().await, 6);
            let objects = protocol.objects.lock().await;
            let stored = objects
                .get(path.as_str())
                .ok_or("published object missing")?;
            assert_eq!(u64::try_from(stored.len())?, SIZE);
            assert_eq!(blake3::hash(stored), expected);
            if shaped {
                assert_eq!(outcome.source_qos.client_streamed_shaped_bytes, SIZE);
                assert_eq!(
                    outcome.source_qos.source_read_operations,
                    SIZE / u64::try_from(chunk_bytes)?
                );
            }
        }
    }
    Ok(())
}
