from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact,compare_performance
from target_settle import settle_target
r=Path.cwd()
assert hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest()=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74'
while not (r/'attempt-probe/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3');base_env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'buffer-comparison';folder.mkdir();arms=['old-baseline','old-high','fixed-baseline','fixed-control','fixed-high'];rng=random.Random(202610320);order=[]
for _ in range(2):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(5)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':10,'size_mib':512,'order':order,'seed':202610320,'minimum_ratio':.98,'idle_ms':1000,'binary_sha256':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','buffer-bin']},'s3_write_inflight':4,'production_change':'byte-aware producer input capacity; preserve original upload loop; same 8MiB parts, source concurrency, quota, HTTP pools and copy profile','part_bytes':8388608,'parts_per_copy':64,'scope':'same original disk target; compare old 9b56c318 against byte-aware producer fix 0070c0b7; fresh destinations and deferred cleanup for every arm; no shared service change'},indent=2));values={a:[] for a in arms};targets=[]
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/buffer-comparison/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':'4'};targets.append((label,env))
  cmd=[str(r/('buffer-bin' if arm.startswith('fixed-') else 'qos-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'pipeline comparison failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=int(env['DATA_MOVER_S3_WRITE_INFLIGHT']);d['destination_sample']=label;(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};ratios={'old_high_to_old_baseline':med['old-high']/med['old-baseline'],'fixed_high_to_fixed_baseline':med['fixed-high']/med['fixed-baseline'],'fixed_high_to_old_high':med['fixed-high']/med['old-high'],'fixed_baseline_to_old_baseline':med['fixed-baseline']/med['old-baseline']};d={'medians':med,'checks':[{'name':k,'ratio':v,'passed':v>=.98} for k,v in ratios.items()],'fixed_aa_control':compare_performance(values['fixed-baseline'],values['fixed-high'],values['fixed-control']),'samples':50};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True)
cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':50,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
