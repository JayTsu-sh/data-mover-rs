from pathlib import Path
import json,os,subprocess,random,statistics,hashlib
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd();cfg=json.load(open('endpoints.private.json'));source=cfg['sources']['cifs']['env'];env={**os.environ,**source,'QOS_DESTINATION':cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3'),'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'reproduce';folder.mkdir();fixtures=r/'fixtures';fixtures.mkdir();(r/'destination').mkdir(exist_ok=True)
for size in [128,512]:
 with (fixtures/f'{size}.bin').open('wb') as f:
  block=(r/'fixture.block.bin').read_bytes()
  for _ in range(size):f.write(block)
 cmd=[str(r/'qos-bin'),'--source',str(fixtures),'--destination',str(r/'destination'),'--path',f'{size}.bin','--chunk-bytes','2097152','--seed'];v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'seed-{size}.stderr').write_text(redact(v.stderr,secrets));assert v.returncode==0,'seed failed';(folder/f'seed-{size}.json').write_text(redact(v.stdout,secrets))
rng=random.Random(202610306);plans={str(size):rng.sample([['baseline','high']]* (n//2)+[['high','baseline']]*(n//2),n) for size,n in [(128,4),(512,6)]};(folder/'plan.json').write_text(json.dumps({'orders':plans,'seed':202610306,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'threshold':.98,'target_readiness':'Dirty<=16MiB, Writeback=0, inflight=0; two snapshots','same_idle_ms':1000},indent=2));summary={}
for size,order in plans.items():
 values={'baseline':[],'high':[]}
 for i,pair in enumerate(order):
  for arm in pair:
   label=f'{size}-{arm}-{i}';settle_target(folder/'readiness.jsonl',label)
   cmd=[str(r/'qos-bin'),'--source',str(fixtures),'--destination',str(r/'destination/cifs-to-s3'),'--path',size+'.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
   if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
   v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'repro failed; inspect redacted stderr';d=json.loads(v.stdout);d['command']=cmd;(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
 med={a:statistics.median(v) for a,v in values.items()};ratio=med['high']/med['baseline'];summary[size]={'medians':med,'ratio':ratio,'passed':ratio>=.98,'pairs':len(order)};(folder/'summary.json').write_text(json.dumps(summary,indent=2));print('RESULT',size,summary[size],flush=True)
(folder/'complete.json').write_text(json.dumps(summary))
