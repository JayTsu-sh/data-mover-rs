from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact,compare_performance
from target_settle import settle_target
r=Path.cwd()
assert hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest()=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74'
while not (r/'buffer-harness/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','nfs41-to-s3');base_env={**os.environ,**cfg['sources']['nfs41']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'buffer-nfs-attribution';folder.mkdir();arms=['fixed-baseline','fixed-control','fixed-high'];rng=random.Random(202610325);order=[]
for _ in range(2):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':6,'size_mib':512,'order':order,'seed':202610325,'minimum_ratio':.98,'idle_ms':1000,'binary_sha256':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['buffer-bin']},'s3_write_inflight':4,'production_change':'none between arms; same candidate binary; sourceQoS flag only','part_bytes':8388608,'parts_per_copy':64,'scope':'same candidate binary across baseline/control/high arms; NFS4.1 source to original S3 disk target; diagnostic A/A precision; primary failures retained; fresh destinations and deferred cleanup; no shared service change'},indent=2));values={a:[] for a in arms};targets=[]
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/buffer-nfs-attribution/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':'4'};targets.append((label,env))
  cmd=[str(r/('buffer-bin' if arm.startswith('fixed-') else 'qos-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'pipeline comparison failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=int(env['DATA_MOVER_S3_WRITE_INFLIGHT']);d['destination_sample']=label;(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};d={'medians':med,'comparison':compare_performance(values['fixed-baseline'],values['fixed-high'],values['fixed-control']),'samples':18,'diagnostic_only':True,'scope':'same candidate NFS source and original S3 disk target; A/A precision, do not overwrite primary4-block failure'};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True)
cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':18,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
