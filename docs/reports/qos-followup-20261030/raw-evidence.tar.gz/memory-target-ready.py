import json,time,boto3
from botocore.config import Config
from pathlib import Path
cfg=json.load(open('endpoints.private.json'));from urllib.parse import urlsplit
u=urlsplit(cfg['destinations']['s3-memory']['endpoint']);client=boto3.client('s3',endpoint_url='http://'+u.hostname.split('.',1)[1]+':'+str(u.port),aws_access_key_id=u.username,aws_secret_access_key=u.password,region_name='us-east-1',config=Config(retries={'total_max_attempts':1},connect_timeout=3,read_timeout=5))
for i in range(60):
 try:client.create_bucket(Bucket='qos-followup');Path('memory-target-ready.json').write_text(json.dumps({'ready':True,'attempt':i+1}));print('Isolated S3 target ready');break
 except Exception:time.sleep(1)
else:raise RuntimeError('isolated S3 target not ready; inspect private server log')
