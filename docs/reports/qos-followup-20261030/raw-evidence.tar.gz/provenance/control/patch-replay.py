from pathlib import Path
import json,subprocess,tempfile,hashlib,tarfile
B=Path('/work/qos-followup-evidence');M=json.load(open(B/'source-manifest.json'));results=[]
for kind in ['full-working-tree','qos-followup']:
 with tempfile.TemporaryDirectory(prefix='qos-followup-replay-',dir='/work') as tmp:
  root=Path(tmp)
  with tarfile.open('docs/reports/qos-high-root-cause-20261030/raw-evidence.tar.gz') as tar:
   members={m.name:m for m in tar.getmembers()}
   for row in M['files']:
    path=row['path'];p=root/path;p.parent.mkdir(parents=True,exist_ok=True);key='source-snapshot/'+path
    if kind=='qos-followup' and key in members:data=tar.extractfile(members[key]).read()
    else:
     v=subprocess.run(['git','show',M['git_commit']+':'+path],capture_output=True);data=v.stdout if v.returncode==0 else None
    if data is not None:p.write_bytes(data)
  v=subprocess.run(['git','apply',str(B/(kind+'.patch'))],cwd=root,capture_output=True,text=True);assert v.returncode==0,v.stderr
  for row in M['files']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],(kind,row['path'])
  results.append({'patch':kind+'.patch','files':len(M['files']),'all_replayed_source_sha256_match':True})
(B/'patch-replay.json').write_text(json.dumps(results,indent=2));print('Both full HEAD replay and incremental9b replay reproduce all recorded source hashes.')
