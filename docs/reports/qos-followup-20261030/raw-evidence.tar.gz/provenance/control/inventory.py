import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
import json,hashlib
r=Path.cwd();binaries=[p for p in r.iterdir() if p.is_file() and (p.name.endswith('-bin') or p.name in ['qos-cleanup','hdfs-cleanup','source-probe'])];rows=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(binaries)];d={p['path']:p for p in rows};assert d['qos-bin']['sha256']=='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd';assert d['buffer-bin']['sha256']=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74';assert d['pipeline-bin']['sha256']=='31d779ec8558b36f6e918336b8179d15febbdd7816a794fc05d830f309a59023';(r/'binary-inventory.json').write_text(json.dumps(rows,indent=2));print('Immutable old, rejected prototype and current release hashes verified;',len(rows),'separate diagnostic/cleanup executables recorded.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;c.close()
