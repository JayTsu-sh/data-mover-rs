from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact
from cross_qos_matrix import profiles
from target_settle import settle_target
r=Path.cwd()
while not (r/'tuned-comparison/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));folder=r/'other-routes';folder.mkdir();matrix={p['name']:p for p in profiles(cfg)};targets=[];summaries={};rng=random.Random(202610311);arms=['default-baseline','default-high','tuned-baseline','tuned-high'];plans={}
for name,size in [('local-to-s3',512),('nfs41-to-s3',512),('hdfs-to-s3',128)]:
 base=arms.copy();rng.shuffle(base);order=[base[i:]+base[:i] for i in range(4)];rng.shuffle(order);plans[name]={'size_mib':size,'order':order}
(folder/'plan.json').write_text(json.dumps({'routes':plans,'seed':202610311,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'scope':'regression of all other S3-target routes; original performance sizes, same QoS and copy profile; default4 versus candidate8; full hash, deferred cleanup, physical disk serialization'},indent=2))
for name,plan in plans.items():
 p=matrix[name];env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);size=plan['size_mib'];route=folder/name;route.mkdir();seed=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path',f'{size}.bin','--chunk-bytes',str(p['chunk_bytes']),'--seed'];v=subprocess.run(seed,env=env,capture_output=True,text=True,timeout=180);(route/'seed.stderr').write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route source preparation failed';(route/'seed.json').write_text(redact(v.stdout,secrets));values={a:[] for a in arms}
 for i,block in enumerate(plan['order']):
  for arm in block:
   label=f'{arm}-{i}';settle_target(route/'readiness.jsonl',label);candidate=arm.startswith('tuned-');sample_env={**env,'QOS_DESTINATION':p['env']['QOS_DESTINATION']+'/other-routes/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':'8' if candidate else '4'};targets.append((name,label,sample_env));cmd=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path',f'{size}.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
   if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
   v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route timed copy failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=8 if candidate else 4;d['destination_sample']=name+'-'+label;(route/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(name,label,d['mibps'],flush=True)
 med={a:statistics.median(v) for a,v in values.items()};ratios={'default_high_to_default_baseline':med['default-high']/med['default-baseline'],'tuned_high_to_tuned_baseline':med['tuned-high']/med['tuned-baseline'],'tuned_high_to_default_high':med['tuned-high']/med['default-high'],'tuned_baseline_to_default_baseline':med['tuned-baseline']/med['default-baseline']};summaries[name]={'medians':med,'checks':[{'name':k,'ratio':v,'passed':v>=.98} for k,v in ratios.items()]};(route/'summary.json').write_text(json.dumps(summaries[name],indent=2));(folder/'summary.json').write_text(json.dumps(summaries,indent=2));print(name,summaries[name],flush=True)
cleanup=[]
for name,label,env in targets:
 secrets=secret_values([env]);v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/name/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':48,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
with s.file(r+'/other-routes.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 other-routes.py >other-routes.log 2>&1 </dev/null &');print('All other S3-target routes queued after primary comparison: local/NFS41 512MiB, HDFS128MiB, four balanced blocks default/candidate baseline/high; no measurement overlap');s.close();c.close()
