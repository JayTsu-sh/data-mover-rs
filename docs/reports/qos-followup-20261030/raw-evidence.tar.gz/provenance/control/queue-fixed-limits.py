from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('/work/qos-high-evidence/raw/fixed-limits-reference.json',r+'/fixed-limits-reference.json')
script='''from pathlib import Path
import json,os,subprocess,time,importlib.util
from qos_evidence import secret_values,redact
from cross_qos_matrix import profiles
from target_settle import settle_target
r=Path.cwd()
while not (r/'other-routes/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));matrix={p['name']:p for p in profiles(cfg)};refs=[p for p in json.load(open('fixed-limits-reference.json')) if p['profile'].endswith('-to-s3')];assert len(refs)==20;folder=r/'tuned-limits';folder.mkdir();spec=importlib.util.spec_from_file_location('validator','run-local-qos.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
(folder/'plan.json').write_text(json.dumps({'cases':20,'write_inflight':8,'reference':'fixed-limits-reference.json','same_finite_quotas_chunk_file_and_copy_profile':True,'lifecycle':'unique sample destinations; deferred cleanup; single physical target volume serialized','scope':'all four S3-target paths; no S3-source change; original strict failures retained as comparison'},indent=2));targets=[];checks=[]
for name in sorted({p['profile'] for p in refs}):
 p=matrix[name];env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*','DATA_MOVER_S3_WRITE_INFLIGHT':'8'};secrets=secret_values([env]);route=folder/name;route.mkdir();seed=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','128.bin','--chunk-bytes',str(p['chunk_bytes']),'--seed'];v=subprocess.run(seed,env=env,capture_output=True,text=True,timeout=180);(route/'seed.stderr').write_text(redact(v.stderr,secrets));assert v.returncode==0,'finite preparation failed';(route/'seed.json').write_text(redact(v.stdout,secrets))
 for ref in [v for v in refs if v['profile']==name]:
  case=ref['case'];settle_target(route/'readiness.jsonl',case);sample_env={**env,'QOS_DESTINATION':p['env']['QOS_DESTINATION']+'/tuned-limits/'+case};targets.append((name,case,sample_env));cmd=[part.replace('/tmp/nightly-qos-cross-20261029192047',str(r)) for part in ref['command']];cmd[0]=str(r/'qos-bin');cmd[cmd.index('--destination-cleanup')+1]='keep';v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(case+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'finite tuned copy failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=8;d['destination_sample']=name+'-'+case;(route/(case+'.json')).write_text(json.dumps(d));dual=case.endswith('dual') or case=='combined';peak=int(cmd[cmd.index('--peak-ms')+1])/1000;gates={}
  for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
   key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);t=V.validate_trace(d,resource,soft,hard,peak,dual);actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];prefix=resource+'_' if case=='combined' else '';gates[prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent')]=actual>=soft*.98
   for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):gates[prefix+gate]=t[gate]
  for old in ref['old_checks']:
   new=gates[old['name']];checks.append({'profile':name,'case':case,'name':old['name'],'old_passed':old['passed'],'passed':new,'new_failure':old['passed'] and not new})
  (folder/'checks.json').write_text(json.dumps(checks,indent=2));print(name,case,d['mibps'],sum(gates.values()),'/',len(gates),flush=True)
cleanup=[]
for name,case,env in targets:
 secrets=secret_values([env]);v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/name/(case+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
d={'samples':20,'passed':sum(c['passed'] for c in checks),'checks':len(checks),'new_failures':sum(c['new_failure'] for c in checks),'cleanup_exit_codes':cleanup};(folder/'complete.json').write_text(json.dumps(d,indent=2));assert not any(cleanup);print(d,flush=True)
'''
with s.file(r+'/tuned-limits.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 tuned-limits.py >tuned-limits.log 2>&1 </dev/null &');print('20 exact-original finite quota cases queued after all performance measurements; all four S3-target routes, source-read envelopes unchanged, serialized target disk');s.close();c.close()
