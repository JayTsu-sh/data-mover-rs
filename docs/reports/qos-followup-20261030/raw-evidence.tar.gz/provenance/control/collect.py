from pathlib import Path
import json,paramiko,hashlib,tarfile,io,importlib.util,shutil,sys
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];base=Path('/work/qos-followup-evidence');base.mkdir(exist_ok=True)
c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
# All redaction stays on the lab runner; private endpoint configs never leave it.
script='''from pathlib import Path
import json,tarfile,io,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd();cfg=json.load(open('endpoints.private.json'));secrets=secret_values([{**p.get('env',{}),'ENDPOINT':p.get('endpoint','')} for p in [*cfg['sources'].values(),*cfg['destinations'].values()]]);secrets=sorted(set(secrets+[json.dumps(v)[1:-1] for v in secrets]),key=len,reverse=True)
paths=[p for p in r.rglob('*') if p.is_file() and '.private.' not in p.name and p.name!='archive-audit.json' and (p.name=='finish-testing' or p.suffix in ['.json','.jsonl','.log','.stderr','.connect','.py','.sh'] or p.name.endswith('.block.bin'))]
manifest=[];redactions=0
with tarfile.open(r/'public-evidence.tar.gz','w:gz') as tar:
 for p in sorted(set(paths)):
  if p.name.endswith('.block.bin'):data=p.read_bytes()
  else:
   raw=p.read_text();clean=redact(raw,secrets);redactions+=raw!=clean;data=clean.encode()
  assert not any(v.encode() in data for v in secrets),'Credential remains in '+str(p.relative_to(r))
  name=str(p.relative_to(r));item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;tar.addfile(item,io.BytesIO(data));manifest.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(r/'archive-audit.json').write_text(json.dumps(dict(files=len(manifest),redacted_files=redactions,credential_scan_passed=True,manifest=manifest,archive_sha256=hashlib.sha256((r/'public-evidence.tar.gz').read_bytes()).hexdigest()),indent=2));print('Public evidence credential scan passed:',len(manifest),'files')
'''
with s.file(r+'/archive-public.py','w') as f:f.write(script)
import shlex
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 archive-public.py');output=o.read().decode();code=o.channel.recv_exit_status();assert code==0,'Public collection failed; check private logs without disclosing credentials';print(output.strip())
s.get(r+'/public-evidence.tar.gz',str(base/'remote-public-evidence.tar.gz'));s.get(r+'/archive-audit.json',str(base/'remote-archive-audit.json'));audit=json.load(open(base/'remote-archive-audit.json'));assert hashlib.sha256((base/'remote-public-evidence.tar.gz').read_bytes()).hexdigest()==audit['archive_sha256'];raw=base/'raw'
if '--fresh' in sys.argv and raw.exists():shutil.rmtree(raw)
raw.mkdir(exist_ok=True)
with tarfile.open(base/'remote-public-evidence.tar.gz') as tar:
 for item in tar.getmembers():
  assert item.isfile();path=raw/item.name;assert path.resolve().is_relative_to(raw.resolve());path.parent.mkdir(parents=True,exist_ok=True);data=tar.extractfile(item).read();path.write_bytes(data)
assert all(hashlib.sha256((raw/m['path']).read_bytes()).hexdigest()==m['sha256'] for m in audit['manifest']);print('Download and all remote manifest checksums verified')
s.close();c.close()
