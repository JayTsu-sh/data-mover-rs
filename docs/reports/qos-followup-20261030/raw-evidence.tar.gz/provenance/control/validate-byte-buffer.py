from pathlib import Path
import os,subprocess
checks=[('rust-tests',['cargo','test','--workspace','--lib','--locked','--features','qos-diagnostics']),('clippy',['cargo','clippy','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance','--example','backend_qos_cleanup','--','-D','warnings']),('test-clippy',['cargo','clippy','-p','data-mover-backend-s3','-p','data-mover-transfer','--lib','--tests','--locked','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]
env={k:v for k,v in os.environ.items() if k.lower() not in ['http_proxy','https_proxy','all_proxy']}
for name,command in checks:
 with Path('/work/qos-byte-buffer-'+name+'.log').open('w') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True);assert result.returncode==0,name
