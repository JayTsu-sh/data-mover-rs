from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,subprocess,time
r=Path.cwd()
while not (r/'memory-survey-status.json').exists():time.sleep(1)
command=json.load(open('memory-survey-plan.json'))['command'];command[command.index('--phase')+1]='final';command[command.index('--output')+1]=str(r/'memory-final');command+=['--baseline',str(r/'memory-survey')];(r/'memory-final-plan.json').write_text(json.dumps({'command':command,'scope':'finite bandwidth and IOPS attribution on same temporary S3 instance; original disk results retained'},indent=2))
with (r/'memory-final.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(r/'memory-final-status.json').write_text(json.dumps({'exit':result.returncode}));print('memory final exit',result.returncode,flush=True)
'''
with s.file(r+'/memory-final.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 memory-final.py >memory-final-driver.log 2>&1 </dev/null &');print('Five finite cases queued with exact same config/binary and imported sample binding on temporary S3 target');s.close();c.close()
