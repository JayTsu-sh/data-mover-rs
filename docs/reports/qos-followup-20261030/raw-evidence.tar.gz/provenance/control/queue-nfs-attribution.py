from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
t=Path('.scratch/qos-followup/buffer-comparison.py').read_text().replace("r/'attempt-probe/complete.json'","r/'buffer-harness/complete.json'").replace('buffer-comparison','buffer-nfs-attribution').replace("cfg['sources']['cifs']['env']","cfg['sources']['nfs41']['env']").replace("replace('{pair}','cifs-to-s3')","replace('{pair}','nfs41-to-s3')").replace("arms=['old-baseline','old-high','fixed-baseline','fixed-control','fixed-high']","arms=['fixed-baseline','fixed-control','fixed-high']").replace('range(5)','range(3)').replace("'blocks':10","'blocks':6").replace("'samples':50","'samples':18").replace('202610320','202610325')
start=t.index("med={a:");end=t.index('cleanup=[]',start)
t=t[:start]+"med={a:statistics.median(v) for a,v in values.items()};d={'medians':med,'comparison':compare_performance(values['fixed-baseline'],values['fixed-high'],values['fixed-control']),'samples':18,'diagnostic_only':True,'scope':'same candidate NFS source and original S3 disk target; A/A precision, do not overwrite primary4-block failure'};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True)\n"+t[end:]
t=t.replace("'production_change':'byte-aware producer input capacity; preserve original upload loop; same 8MiB parts, source concurrency, quota, HTTP pools and copy profile'","'production_change':'none between arms; same candidate binary; sourceQoS flag only'")
# Source-only binary has the same NFS source/QoS code and explicitly full read window.
u=s.open(r+'/source-only.py').read().decode().replace("r/'reproduce/complete.json'","r/'buffer-nfs-attribution/complete.json'").replace("cfg['sources']['cifs']['env']","cfg['sources']['nfs41']['env']").replace("r/'source-only'","r/'buffer-nfs-source-only'").replace('full CIFS read concurrency','full NFS4.1 read concurrency').replace('202610307','202610326')
for name,script in [('buffer-nfs-attribution',t),('buffer-nfs-source-only',u)]:
 Path('.scratch/qos-followup/'+name+'.py').write_text(script)
 with s.file(r+'/'+name+'.py','w') as f:f.write(script)
 _,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 '+name+'.py >'+name+'.log 2>&1 </dev/null &');o.channel.recv_exit_status()
t=s.open(r+'/cleanup.py').read().decode().replace("'buffer-harness']:assert","'buffer-harness','buffer-nfs-attribution','buffer-nfs-source-only']:assert")
with s.file(r+'/cleanup.py','w') as f:f.write(t)
print('Queued diagnostic-only NFS original-disk 6×3 balanced A/A/high copies and 4 paired full-window source reads; primary failures unchanged.');s.close();c.close()
