from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
helper="from urllib.parse import urlsplit,urlunsplit\ndef phase_endpoint(endpoint,phase,label):\n p=urlsplit(endpoint);return urlunsplit(p._replace(path=p.path.rstrip('/')+'/'+phase+'/'+label))\n"
t=s.open(r+'/buffer-source-routes.py').read().decode()
with s.file(r+'/buffer-source-routes.before-uri-fix.py','w') as f:f.write(t)
t=helper+t;t=t.replace("folder.mkdir();matrix=","folder.mkdir(exist_ok=True);matrix=").replace("route.mkdir();seed=","route.mkdir(exist_ok=True);seed=")
t=t.replace("p['env']['QOS_DESTINATION']+'/buffer-source-routes/'+label","phase_endpoint(p['env']['QOS_DESTINATION'],'buffer-source-routes',label)")
# Reuse already measured and fully verified samples in the original planned order.
a="label=f'{arm}-{i}';settle_target(route/'readiness.jsonl',label);candidate=arm.startswith('fixed-');"
b="label=f'{arm}-{i}';candidate=arm.startswith('fixed-');"
assert a in t;t=t.replace(a,b)
a="v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route timed copy failed';d=json.loads(v.stdout);"
b="""cached=route/(label+'.json')
   if cached.exists():
    d=json.load(open(cached));assert d['command']==cmd;values[arm].append(d['mibps']);continue
   settle_target(route/'readiness.jsonl',label)
   prior=route/(label+'.stderr')
   if prior.exists() and prior.stat().st_size:prior.rename(route/(label+'.mount-error.stderr'))
   v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route timed copy failed';d=json.loads(v.stdout);"""
assert a in t;t=t.replace(a,b)
# Preserve initial plan bytes; verify that the retry does not change order/size.
a="(folder/'plan.json').write_text(json.dumps("
start=t.index(a);end=t.index('\nfor name,plan in plans.items():',start)
old=t[start:end];assert old.endswith('indent=2))');expr=old[len(a):-len(',indent=2))')]
t=t[:start]+"saved_plan=json.load(open(folder/'plan.json'));assert saved_plan['routes']==plans;assert saved_plan['seed']==202610324\n"+t[end:]
Path('.scratch/qos-followup/buffer-source-routes.resumed.py').write_text(t)
with s.file(r+'/buffer-source-routes.py','w') as f:f.write(t)
# Stop only the finite driver that is still queued; no finite sample exists yet.
stop='''from pathlib import Path
import os,signal,json
r=Path.cwd();assert not (r/'buffer-source-limits').exists();matches=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if b'buffer-source-limits.py' in (p/'cmdline').read_bytes().split(bytes([0])) and (p/'cwd').resolve()==r:matches.append(int(p.name))
 except (OSError,RuntimeError):pass
assert len(matches)==1;os.kill(matches[0],signal.SIGTERM)
(r/'source-uri-preparation-error.json').write_text(json.dumps({'stage':'S3-to-NFS destination connect before payload transfer','error':'phase suffix was concatenated after NFS query parameters','fix':'parse URL, append only to path, preserve query/auth; all source/destination identity and options unchanged','retained_completed_samples':48,'failed_payload_samples':0,'error_log':'buffer-source-routes/s3-to-nfs41/old-baseline-0.mount-error.stderr','primary_regression_verdicts_unchanged':True},indent=2))
p=r/'buffer-local-memory.capacity-abort.json';d=json.load(open(p));d['disposition']='waited for natural capacity recovery, retained original guard and plan; no server restart or shared service mutation';d['initial_capacity_values_recorded']=False;d['garbage_collection_cause']='inference, not uniquely measured';p.write_text(json.dumps(d,indent=2))
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(stop));assert o.channel.recv_exit_status()==0
u=s.open(r+'/buffer-source-limits.py').read().decode()
with s.file(r+'/buffer-source-limits.before-uri-fix.py','w') as f:f.write(u)
u=helper+u;u=u.replace("p['env']['QOS_DESTINATION']+'/buffer-source-limits/'+case","phase_endpoint(p['env']['QOS_DESTINATION'],'buffer-source-limits',case)")
Path('.scratch/qos-followup/buffer-source-limits.uri-fixed.py').write_text(u)
with s.file(r+'/buffer-source-limits.py','w') as f:f.write(u)
for name in ['buffer-source-routes','buffer-source-limits']:
 _,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 '+name+'.py >>'+name+'.log 2>&1 </dev/null &');o.channel.recv_exit_status()
print('Resumed exactly original source-route plan, reusing48 immutable successes; URL path/query fixed; original preparation error preserved.');s.close();c.close()
