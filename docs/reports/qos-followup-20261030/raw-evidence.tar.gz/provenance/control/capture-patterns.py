import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,hashlib
r=Path.cwd();folder=r/'fixture-patterns';folder.mkdir(exist_ok=True);rows=[]
for family,size,reference in [('main',128,'pipeline-limits/cifs-to-s3/bandwidth-strict.json'),('main',512,'source-only/baseline-0.json'),('fresh',512,'fresh-fixture-smoke/survey/fresh-cifs-to-s3/baseline-0.json')]:
 golden=r/('fixtures' if family=='main' else 'fresh-fixture-smoke/fixtures');path=golden/f'{size}.bin';assert path.stat().st_size==size*1048576
 with path.open('rb') as f:block=f.read(1048576)
 name=f'{family}-{size}.block.bin';(folder/name).write_bytes(block);d=json.load(open(r/reference));assert d['bytes']==size*1048576;rows.append({'family':family,'golden_root':str(golden),'path':name,'bytes':d['bytes'],'repeat_count':size,'block_sha256':hashlib.sha256(block).hexdigest(),'reconstructed_blake3':d['digest'],'reference':reference})
(folder/'manifest.json').write_text(json.dumps(rows,indent=2));print('Saved main128/main512 and independent fresh512 fixture patterns; credential-free, full hashes reconstructable.')
'''
with s.file(r+'/capture-patterns.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 capture-patterns.py');print(o.read().decode());assert o.channel.recv_exit_status()==0;s.close();c.close()
