from pathlib import Path
import json,math,statistics,hashlib,importlib.util,collections,csv,re,subprocess,sys
B=Path('/work/qos-followup-evidence');R=B/'raw';pending='--pending' in sys.argv

def read(p):return json.load(open(p))
def close(a,b):assert math.isclose(a,b,rel_tol=1e-12),(a,b)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
Q=module('evidence','tests/lab/qos_evidence.py');V=module('validator','tests/lab/run-local-qos.py')
manifest=read(B/'remote-archive-audit.json');assert all(hashlib.sha256((R/m['path']).read_bytes()).hexdigest()==m['sha256'] for m in manifest['manifest'])
measurements=[];groups=collections.defaultdict(set)
for p in sorted(R.rglob('*.json')):
 d=read(p)
 if not isinstance(d,dict) or not all(k in d for k in ['bytes','seconds','digest','mibps','operations']) or not d['bytes']:continue
 cmd=d.get('command',[]);assert '--source' in cmd,str(p);golden=cmd[cmd.index('--source')+1];family='fresh' if '/fresh-fixture-smoke/fixtures' in golden else 'main';assert golden.endswith('/fixtures'),golden
 groups[(family,d['bytes'])].add(d['digest']);close(d['mibps'],d['bytes']/d['seconds']/1048576);close(d['iops'],d['operations']/d['seconds'])
 assert d['digest'] and len(d['digest'])==64
 if d['admissions']:
  assert len(d['admissions'])==d['operations'];assert sum(e['bytes'] for e in d['admissions'])==d['bytes']
 row={k:d.get(k) for k in ['bytes','operations','seconds','mibps','iops','digest','effective_read_bytes','verification_seconds','transfer_profile']};row.update(path=str(p.relative_to(R)),fixture_family=family,mode='copy' if '--copy' in cmd else 'source-only',binary=Path(cmd[0]).name,admissions=len(d['admissions']));measurements.append(row)
assert all(len(ds)==1 for ds in groups.values()),groups
reconstructed=[]
if (R/'fixture-patterns/manifest.json').exists():
 for m in read(R/'fixture-patterns/manifest.json'):
  p=R/'fixture-patterns'/m['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==m['block_sha256'];h=subprocess.check_output(['/work/qos-cross-hash-pattern',str(p),str(m['repeat_count'])],text=True).strip();assert groups[(m['family'],m['bytes'])]=={h}=={m['reconstructed_blake3']};reconstructed.append({'family':m['family'],'bytes':m['bytes'],'digest':h})
if not pending:assert len(reconstructed)==len(groups)==4
with (B/'measurements.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(measurements[0]));w.writeheader();w.writerows(measurements)
comparisons=[]
for p in sorted(R.rglob('summary.json')):
 s=read(p)
 if not isinstance(s,dict) or 'medians' not in s:continue
 folder=p.parent;med={};series={}
 for arm,expected in s['medians'].items():
  glob='depth-'+arm+'-*.json' if folder.name=='depth-sweep' else arm+'-*.json';ds=[read(f) for f in sorted(folder.glob(glob),key=lambda p:int(p.stem.rsplit('-',1)[1]))];assert ds,(p,arm)
  vals=[d['mibps'] for d in ds];med[arm]=statistics.median(vals);series[arm]=vals;close(med[arm],expected)
 ratios={a.replace('-','_')+'_to_'+b.replace('-','_'):av/bv for a,av in med.items() for b,bv in med.items()}
 for g in s.get('checks',[]):
  close(g['ratio'],ratios[g['name']]);assert g['passed']==(g['ratio']>=.98)
 entry={'experiment':str(folder.relative_to(R)),'medians':med,'checks':s.get('checks',[])}
 for prefix in ['fixed','tuned']:
  key=prefix+'_aa_control'
  if key in s:
   q=Q.compare_performance(series[prefix+'-baseline'],series[prefix+'-high'],series[prefix+'-control']);assert q==s[key];entry['precision']=q
 if folder.name=='isolated-control':
  close(med['high']/med['baseline-a'],s['high_to_baseline_a']);close(med['baseline-b']/med['baseline-a'],s['aa_ratio']);assert s['high_passed']==(s['high_to_baseline_a']>=.98);entry['precision']=Q.compare_performance(series['baseline-a'],series['high'],series['baseline-b']);entry['original_aa_repeatable_is_point_only']=True
 if folder.name=='local-absolute':
  q=Q.compare_performance(series['old-high-a'],series['fixed-high'],series['old-high-b']);assert q==s['comparison'];close(med['fixed-high']/med['old-high-b'],s['fixed_to_old_b']);entry['precision']=q
 if folder.name.endswith('source-only'):close(med['high']/med['baseline'],s['ratio']);assert s['passed']==(s['ratio']>=.98)
 if folder.name in ['buffer-nfs-attribution','nfs-source-long']:
  q=Q.compare_performance(series['fixed-baseline'],series['fixed-high'],series['fixed-control']) if folder.name=='buffer-nfs-attribution' else Q.compare_performance(series['baseline'],series['high'],series['control']);assert q==s['comparison'];entry['precision']=q
 comparisons.append(entry)

def finite_gates(d,case,profile):
 cmd=d['command'];peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';gates={}
 for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
  key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);t=V.validate_trace(d,resource,soft,hard,peak,dual);actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];prefix=resource+'_' if case=='combined' else ''
  gates[prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent')]=actual>=soft*.98
  for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):gates[prefix+gate]=t[gate]
 if profile.startswith('s3-to-') and (case.startswith('bandwidth') or case=='combined'):
  assert d['effective_read_bytes']==8388608 and d['operations']==math.ceil(d['bytes']/8388608),(profile,case,'S3 GET pressure regression')
  gates['s3_payload_requests_no_inflation']=True
 return gates
finite=[]
for folder,reference in [('tuned-limits','fixed-limits-reference.json'),('pipeline-limits','pipeline-fixed-limits-reference.json'),('buffer-limits','pipeline-fixed-limits-reference.json'),('buffer-source-limits','pipeline-fixed-limits-reference.json')]:
 if not (R/folder/'complete.json').exists():
  assert pending,folder;continue
 refs=read(R/reference);checks=read(R/folder/'checks.json');computed={}
 if reference=='pipeline-fixed-limits-reference.json':
  prior={(g['profile'],g['case'],g['name']):g['passed'] for g in read(Path('/work/qos-high-evidence/raw/fixed-limits/checks.json'))}
  for ref in refs:
   if ref['old_checks']:
    assert ref['reference_binary_sha256']=='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd'
    assert all(prior[(ref['profile'],ref['case'],g['name'])]==g['passed'] for g in ref['old_checks'])
 for ref in refs:
  name,case=ref['profile'],ref['case'];path=R/folder/name/(case+'.json')
  if not path.exists():continue
  d=read(path);assert d['bytes']==128*1048576;cmd=d['command'].copy();original=ref['command'].copy();cmd[0]=original[0];cmd=[v.replace('/tmp/nightly-qos-followup-20261030045923','/tmp/nightly-qos-cross-20261029192047') for v in cmd];
  if '--destination-cleanup' in original:cmd[cmd.index('--destination-cleanup')+1]=original[original.index('--destination-cleanup')+1]
  else:
   index=cmd.index('--destination-cleanup');assert cmd[index+1]=='keep';del cmd[index:index+2]
  assert cmd==original,(folder,name,case,'changed finite command')
  gates=finite_gates(d,case,name)
  for old in ref['old_checks'] or [{'name':k,'passed':None} for k in gates]:computed[(name,case,old['name'])]=(old['passed'],gates[old['name']])
 assert len(checks)==len(computed)
 for g in checks:
  old,new=computed[(g['profile'],g['case'],g['name'])];assert (g['old_passed'],g['passed'],g['new_failure'])==(old,new,old is True and not new)
 done=read(R/folder/'complete.json');assert done['passed']==sum(g['passed'] for g in checks) and done['checks']==len(checks) and done['new_failures']==sum(g['new_failure'] for g in checks)
 finite.append({'experiment':folder,'samples':done['samples'],'passed':done['passed'],'checks':len(checks),'new_failures':done['new_failures'],'failed':[g for g in checks if not g['passed']]})
# Public runner result: recompute finite trace gates and performance gates from actual samples.
runner=[]
for name in ['memory-survey','memory-final','fresh-fixture-smoke/survey','buffer-harness/survey','buffer-harness/final']:
 folder=R/name
 if not (folder/'summary.json').exists():
  assert pending,name;continue
 summ=read(folder/'summary.json');checks=read(folder/'checks.json');expected={}
 for profile,s in summ.items():
  f=folder/profile;arms={a:[read(p)['mibps'] for p in sorted(f.glob(a+'-*.json'))] for a in ['baseline','control','high']};base,high=[statistics.median(arms[a]) for a in ['baseline','high']];close(base,s['baseline_mibps']);close(high,s['high_mibps']);close(high/base,s['high_ratio']);expected[(profile,'high','matches_baseline_98_percent')]=high>=base*.98
  if arms['control']:
   q=Q.compare_performance(arms['baseline'],arms['high'],arms['control']);assert q==s['performance_comparison'];expected[(profile,'high','baseline_repeatable_98_percent')]=q['control_repeatable'];expected[(profile,'high','high_ratio_precision_98_percent')]=q['high_ratio_interval_95'][0]>=.98
  expected[(profile,'capacity','bandwidth_headroom')]=base*1048576>=s['soft_bytes']*2*1.25
  expected[(profile,'capacity','iops_headroom')]=statistics.median(read(p)['iops'] for p in f.glob('baseline-*.json'))>=s['soft_iops']*2*1.25
  for case in s.get('cases',{}):
   gates=finite_gates(read(f/(case+'.json')),case,profile)
   for key,value in gates.items():expected[(profile,case,key)]=value
 for g in checks:
  if g['name']=='isolated_destination_removed':assert g['passed'];continue
  assert g['passed']==expected[(g['profile'],g['case'],g['name'])],g
 runner.append({'experiment':name,'passed':sum(g['passed'] for g in checks),'checks':len(checks)})
# SDK diagnostics are separate binaries and never performance qualifications.
attempts=[]
for folder in ['attempt-probe','pipeline-attempt-probe']:
 for row in read(R/folder/'summary.json'):
  text=(R/folder/(row['label']+'.stderr')).read_text();parts=[int(v) for v in re.findall(r'send_part=(\d+) method=PUT',text)];statuses=collections.Counter(re.findall(r'\[FOLLOWUP-ATTEMPT\] status=(\d+)',text));assert sorted(parts)==list(range(1,65)) and dict(statuses)==row['statuses'] and len(parts)==row['part_attempts'];attempts.append({'experiment':folder,'label':row['label'],'parts':64,'repeated_parts':0,'statuses':dict(statuses)})
cleanup=[]
for p in sorted(R.rglob('complete.json')):
 d=read(p)
 if 'cleanup_exit_codes' in d:assert not any(d['cleanup_exit_codes']);cleanup.append({'experiment':str(p.parent.relative_to(R)),'removed':len(d['cleanup_exit_codes'])})
# Actual measurements behind the original unmodified-binary reproduction.
for size,s in read(R/'reproduce/summary.json').items():
 vals={a:[read(p)['mibps'] for p in (R/'reproduce').glob(size+'-'+a+'-*.json')] for a in ['baseline','high']};med={a:statistics.median(v) for a,v in vals.items()};assert med==s['medians'];close(med['high']/med['baseline'],s['ratio']);assert s['passed']==(s['ratio']>=.98)
# Candidate experiment must retain release binary identity, part sizes and default cap.
candidate='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74';bindings=[]
for folder in ['buffer-comparison','buffer-other-routes','buffer-memory','buffer-local-memory','buffer-source-routes']:
 p=R/folder/'plan.json'
 if not (R/folder/'complete.json').exists():assert pending,folder;continue
 plan=read(p);binaries=plan.get('binary_sha256',plan.get('binaries'));assert binaries['buffer-bin']==candidate and binaries['qos-bin']=='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd';samples=[m for m in measurements if m['path'].startswith(folder+'/') and m['binary']=='buffer-bin'];assert samples
 for m in samples:
  d=read(R/m['path']);assert d['s3_write_inflight']==4;cmd=d['command'];assert '--copy' in cmd and cmd[cmd.index('--destination-cleanup')+1]=='keep'
  if folder not in ['buffer-source-routes'] and m['bytes']==512*1048576:assert '--idle-ms' in cmd and cmd[cmd.index('--idle-ms')+1]=='1000'
 bindings.append({'experiment':folder,'verified_candidate_samples':len(samples),'old_and_candidate_release_sha256_bound':True})
readiness=[]
for p in sorted(R.rglob('readiness.jsonl')):
 g=collections.defaultdict(list)
 segments=[]
 for line in p.read_text().splitlines():
  d=json.loads(line);g[d['label']].append(d)
  if not segments or segments[-1][0]!=d['label']:segments.append((d['label'],[]))
  segments[-1][1].append(d)
 for label,ds in segments:
  if pending and len(ds)<2:continue
  assert len(ds)>=2 and all(d['Dirty']<=16384 and d['Writeback']==0 and d['inflight']==0 for d in ds[-2:]),(str(p),label)
 readiness.append({'experiment':str(p.parent.relative_to(R)),'labels':len(g),'all_last_two_idle_samples_passed':True})
out={'all_remote_file_checksums_verified':True,'all_measurement_arithmetic_and_full_digests_checked':True,'fixture_groups':reconstructed,'measurement_records':len(measurements),'unique_measurement_records':len({(m['binary'],m['digest'],m['seconds']) for m in measurements}),'comparison_experiments':comparisons,'finite_limits':finite,'public_runner_checks':runner,'actual_sdk_attempt_counts':attempts,'deferred_cleanup_results':cleanup,'candidate_bindings':bindings,'physical_target_readiness':readiness,'pending':pending}
(B/'evidence-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['comparison_experiments','actual_sdk_attempt_counts','deferred_cleanup_results','finite_limits']},indent=2));print('Finite results:',[(v['experiment'],v['passed'],v['checks'],v['new_failures']) for v in finite])
