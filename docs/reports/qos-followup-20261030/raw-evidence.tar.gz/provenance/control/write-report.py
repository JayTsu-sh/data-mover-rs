from pathlib import Path
import json,datetime
B=Path('/work/qos-followup-evidence');R=B/'raw';O=Path('docs/reports/qos-followup-20261030');O.mkdir(parents=True,exist_ok=True)
read=lambda p:json.load(open(p))
for folder in ['buffer-comparison','buffer-other-routes','buffer-limits','buffer-memory','buffer-local-memory','buffer-source-routes','buffer-source-limits','buffer-harness','buffer-nfs-attribution','buffer-nfs-source-only','nfs-source-long']:assert (R/folder/'complete.json').exists(),folder
A=read(B/'evidence-audit.json');assert A['pending'] is False;S=read(B/'candidate-source-manifest.json');T=read(B/'retained-source-manifest.json');TV=read(B/'retained-validation.json');NS=read(R/'buffer-nfs-source-only/summary.json');NA=read(R/'buffer-nfs-attribution/summary.json')['comparison'];NL=read(R/'nfs-source-long/summary.json')['comparison'];C=read(R/'cleanup.json');assert C['all_lifecycle_operations_succeeded']
rows=[('cifs-to-s3',read(R/'buffer-comparison/summary.json'))]
for folder in ['buffer-other-routes','buffer-source-routes']:rows.extend(read(R/folder/'summary.json').items())
def pct(v):return f'{100*v:.3f}%'
def verdict(v):return pct(v)+(' ✓' if v>=.98 else ' **失败**')
table=['| 路径 | 新无 QoS MiB/s | 新高 QoS MiB/s | 高 / 无 QoS | 新高 / 旧高 | 新无 / 旧无 |','|---|---:|---:|---:|---:|---:|']
current_failures=[]
for name,s in rows:
 m=s['medians'];g={v['name']:v['ratio'] for v in s['checks']};table.append(f"| {name} | {m['fixed-baseline']:.3f} | {m['fixed-high']:.3f} | {verdict(g['fixed_high_to_fixed_baseline'])} | {verdict(g['fixed_high_to_old_high'])} | {verdict(g['fixed_baseline_to_old_baseline'])} |")
 for key in ['fixed_high_to_fixed_baseline','fixed_high_to_old_high','fixed_baseline_to_old_baseline']:
  if g[key]<.98:current_failures.append({'profile':name,'gate':key,'ratio':g[key]})
fasttable=['| 诊断路径 | 新高 / 新无 | 新高 / 旧高 | 新无 / 旧无 |','|---|---:|---:|---:|']
for name,folder in [('CIFS→RAM S3','buffer-memory'),('Local→RAM S3','buffer-local-memory')]:
 fs=read(R/folder/'summary.json');fg={g['name']:g['ratio'] for g in fs['checks']};fasttable.append(f"| {name} | {verdict(fg['fixed_high_to_fixed_baseline'])} | {verdict(fg['fixed_high_to_old_high'])} | {verdict(fg['fixed_baseline_to_old_baseline'])} |")
finite=[v for v in A['finite_limits'] if v['experiment'].startswith('buffer-')];npassed=sum(v['passed'] for v in finite);nchecks=sum(v['checks'] for v in finite);nnew=sum(v['new_failures'] for v in finite);nf=sum(v['samples'] for v in finite)
finite_fail=[dict(experiment=v['experiment'],**g) for v in finite for g in v['failed']]
failuretable=['| 路径 / 场景 | 端到端利用率 | 源 admission 活跃段漂移 ms | 最后 admission 后尾部 ms | 98% 额外时间预算 ms |','|---|---:|---:|---:|---:|']
for row in read(B/'failure-analysis.json'):
 phase=row['phases'][0];failuretable.append(f"| {row['profile']} / {row['case']} | {pct(phase['end_to_end_ratio'])} | {phase['active_admission_drift_seconds']*1000:.1f} | {phase['post_last_admission_tail_seconds']*1000:.1f} | {phase['extra_time_allowed_for_98_percent_seconds']*1000:.1f} |")
perf=read(R/'buffer-comparison/summary.json')['fixed_aa_control'];public=read(R/'buffer-harness/final/summary.json')['cifs-to-s3-buffer-memory'];quality=public['performance_comparison'];harness=read(R/'buffer-harness/complete.json');validation=read(B/'validation.json')
status='严格全绿验收未通过' if current_failures or npassed<nchecks or not perf['qualified'] else '原始判定通过，仍须按精度门槛解释'
text=f'''# 高 QoS 根因修复、跨后端回归与原始证据（续测）

- 报告生成：{datetime.datetime.now(datetime.timezone.utc).isoformat()}。
- 真实实验运行：`nightly-qos-followup-20261030045923`，控制机 `.11`、源 `.12`、目标 `.13`；CIFS 使用现有真实共享，HDFS 使用现有 Kerberos 集群。
- 当前结论：**{status}**。实验扩容候选已完整保存证据并从生产源码撤回；当前保留版本的 Rust/Cargo 与此前已接受的 9b 逐字节一致，release SHA 也相同。接受的本轮改动仅为测量工具正确性和诊断能力。所有失败及环境不可重复性均保留；本报告不宣称所有 backend 均达到 98%。
- 原有 [首次高 QoS 根因报告](../qos-high-root-cause-20261030/REPORT.md)、[原始跨后端矩阵](../qos98-cross-backends-20261030/REPORT.md) 保持不变。本轮是追加证据，没有覆盖原始失败。

## 修复和根因边界

**S3 源端：保留已验证的 HTTP 连接池修复。** SDK 默认运行时创建的 HTTP client 不一定出现在 `SdkConfig.http_client()` 中。仅克隆配置再造禁重试 GET client，可能产生第二个连接池。现有修复在实际发送请求时捕获并复用 SDK runtime 的 `SharedHttpClient`，同时保留 GET 禁自动重试与逐请求 QoS 计费。前一报告的真实 TCP 对照为旧版 baseline/high 2/3 次建连、修复后 2/2；本轮所有正常二进制都保留这项修复。不能把历史 S3→HDFS 的全部约 5% 差异唯一归因于连接池：此前 15 对主轮 97.969% 的失败仍在，独立 30 对确认为 99.928%。本轮重新实测 S3→HDFS，并列出相对和绝对对照。

**CIFS/NFS→S3：可复现的缓冲不足，吞吐收益仍须实测确认。** 原队列固定 4 块；CIFS/NFS 实际最大读块约 1 MiB，只有 4 MiB 队列，S3 MPU 分片却是 8 MiB。4 个分片上传占满窗口时，下一完整分片无法提前进入队列，源预读和目标上传之间出现额外背压。已撤回的实验候选由 staged destination 提供当前 stage 的写入单位提示，transfer engine 据源最大块大小调整队列。CIFS 此路径由 4 槽增至 8 槽，实际 NFS 最大块为 1 MiB−4 KiB 时增至 9 槽，分别多约 4/5 MiB 载荷；提示最多按 8 MiB 计算、最多 64 槽，原本缓冲足够的 Local/HDFS/S3 保留 4 槽，其他目标默认提示 0。S3 上传循环、4 路上传、8 MiB MPU 分片、源读并发和源请求粒度均保留。

该问题的真实 engine→S3 destination 回归测试先执行 RED：上传窗口占满后生产者停在 37 MiB，达不到下一完整分片需要的 40 MiB，2 秒超时。修复后 1/2/8 MiB 源块、无 QoS/高 QoS 六种组合均通过，同时检查完整 BLAKE3、6 个 MPU 分片、真实源计费字节和操作数。完整 debug fixture 的 GREEN 约 40 秒，测试内超时针对阻塞检测，不是整组测试耗时承诺。测试在归档的 `source-snapshot/crates/transfer/src/transfer/s3_input_buffer_tests.rs`，已随候选撤回；红绿日志也在归档。该测试证明了一个完整分片能否提前排队，不单独证明 98% 吞吐问题已经修复，也没有证明它是每一次历史磁盘低分的唯一原因。

**目标服务/磁盘是另一个测量变量。** 原目标 RustFS 使用 `/data/rustfs0`（设备 2049，和 NFS v4 目标同盘）；单独建立同一个 RustFS 可执行文件、独立端口和随机凭据的 `/dev/shm` 目标（设备 26）作为诊断对照。其作用是隔离磁盘变量，不能替代原磁盘验收。源端 CIFS 512 MiB 独立读对照 99.239%；高 QoS admission 累计仅约 0.35–0.38 ms。逐分片探针中，低分轮目标 RPC 累积耗时约 67.23 s，对照约 51.98 s；异步读跨度还包含未被轮询的背压，不能当成纯网络 RPC 延迟。SDK 实际 HTTP 探针中，每次 512 MiB 拷贝 64 个 UploadPart 各一次，未发现重传或 5xx。控制机 cgroup 没有 CPU throttling。以上是边界证据，不是对共享 RustFS 内部机制的唯一归因。

## 原存储目标的新旧版本对照

本节“新”一律指已撤回的 `0070c0b7` 实验候选；最终保留生产版本是 `9b56c318`，不把候选数据冒充保留版本的新验收结果。全部都是完整实际传输和目标重读 BLAKE3；校验在计时区间外。固定此前复测的文件大小、配额、chunk、copy profile；每个样本使用新目标前缀，整组测量完成才删除，避免覆盖/删除周期交错。开始前要求目标连续两次 Dirty≤16 MiB、Writeback=0、块设备 inflight=0，另保留原 1 秒 idle。没有清系统缓存、修改共享服务参数或增加 S3 上传并发。

- CIFS→S3：10 个预先排定、轮换顺序的 5 臂块，共 50 次 512 MiB；旧无/高、新无/控制无/高。
- 其他原 S3 目标路径与新增 S3→S3：各 4 个平衡的 4 臂块。Local/NFS/S3 使用 512 MiB，HDFS→S3 保留 128 MiB。
- 原 S3 源路径：各 4 个平衡的 4 臂块；S3→HDFS 512 MiB，其他保留 128 MiB。目标为 Local 的 profile 保留 default，网络目标保留 cross/AtomicReplace。
- 表中均为各臂 MiB/s 中位数之比，门槛固定 0.98；没有按结果更换分母或去掉样本。

{chr(10).join(table)}

原磁盘 CIFS 组的 A/A 控制比为 {pct(perf['control_ratio'])}，95% 诊断区间 `{perf['control_ratio_interval_95']}`；高/无 QoS 区间 `{perf['high_ratio_interval_95']}`，`qualified={perf['qualified']}`。相同无 QoS 的两组也不能将差异限制在 2% 内，因此即使高 QoS 中位数过线，也不能据此认证 2% 精度。表中 **{len(current_failures)} 项实验候选原始门槛失败** 全部列入 `summary.json`，没有因 A/A 失败而改写成通过。

## 软硬配额、98% 利用率与请求压力

实验候选在原磁盘共复测 {nf} 个有限配额场景：带宽 strict、带宽 soft/hard、IOPS strict、IOPS soft/hard、combined。IOPS 的现有口径是源 payload read，不包含元数据请求和目标写请求。使用旧已接受 `9b56c318` 的原始有限配额和命令参照；新增 S3→S3 使用单独记录的配置，历史结果为 null。生命周期由覆盖/即时删除改为唯一前缀/整组后清理，这项差异明确记录。本轮 512 MiB 与此前 512 MiB 使用同一 pattern；本轮 128 MiB 由该 pattern 重复生成，与此前报告 128 MiB 的随机内容不同。文件大小/配额/粒度/模式相同，但跨报告参照并非字节一致的原始数据复跑；同轮新旧二进制对照则使用完全相同输入。

- 原始判定 **{npassed}/{nchecks}**，相对已接受参照的新增失败 **{nnew}**；完整失败项在 `checks.json` 和 `summary.json`。
- hard/soft 的判定作用于**源请求 admission**：任意区间满足 `hard×时间 + 一个有界实际请求`；soft 允许有限 burst，并验证 peak 后 steady ceiling/98% 利用率。离散请求不能要求任意无限短时间窗的瞬时速率都不超过数值限额。
- 端到端 98% 另计：包含准备、读写尾部、发布等；不能用 source admission 的通过替代端到端通过。严格 IOPS 的小文件/短预算容易受固定 RPC 尾部影响，所有相关失败保留。
- S3 带宽限制接受一个完整 GET 的量化误差，维持 8 MiB GET，128/512 MiB 分别为 16/64 个源 payload 请求；严格 IOPS 用例有独立受控请求大小。没有通过拆细带宽 GET 提高分数。S3→S3 为跨实例的 client-streamed 传输，确实计费完整源字节，不走未受限的 native copy。

对严格配额，设理想读源时间为 `N/Q`，正的上传/提交尾部为 `L`，端到端利用率至多约 `1/(1+L/(N/Q))`。16 次请求、1 IOPS 的 128 MiB 用例仅允许约 0.327 秒额外尾部才能达到 98%；此前实际 S3→S3 尾部约 0.550 秒，因此端到端失败与源调度正确可以同时成立。没有以提前免费发放一次 I/O 的方式更改原限速语义。

本轮实际失败项的阶段分析如下。尾部包含剩余源读取、目标写入和发布，不能进一步无证据地等同为单个提交 RPC；各项的 source admission 活跃段漂移都远小于尾部，且源约束判定通过。

{chr(10).join(failuretable)}

另对先前预取原型的 NFS 带宽 strict 单项失败做过原配额 5 对确认：旧/原型端到端中位数 97.817%/98.001%，原失败 97.852% 的主要差额落在最后一次 source admission 后约 0.49 s 的发布尾部；源调度段只漂移约 23 ms。该对照只能说明该单项没有稳定复现为新增 source 限速缺陷，原失败仍计入原型结果。

## 独立快速 S3 目标的四场景对照

使用已撤回的实验候选版本、最新公开 runner，3 个平衡的 baseline/control/high 块，512 MiB 高 QoS；有限配额保留 128 MiB、8 MiB/s，默认上传并发 4。survey/final 退出码 `{harness['phase_exit_codes']}`。高/无 QoS 为 **{pct(quality['ratio'])}**，A/A 95% 区间 `{quality['control_ratio_interval_95']}`，高/无 QoS 95% 区间 `{quality['high_ratio_interval_95']}`，`qualified={quality['qualified']}`。完整五项有限配额及清理判定都随原始输出保留。

Local 快速目标对照首次在拷贝前触发既有容量保护，测量样本为 0。等待容量自然恢复后（初次未记录容量数值，异步回收只是推断），空间恢复至约 8.38 GB、MemAvailable 约 14.9 GB，按原门槛及原计划重新开始；首个容量失败日志保留，没有丢弃性能样本，没有重启服务或降低容量门槛。

旧/新 Local→快速 S3、CIFS→快速 S3 的绝对性能对照如下；它们是诊断目标，不能抹去上表原磁盘结果。

{chr(10).join(fasttable)}

## 已否决的优化，避免带回回退

1. **仅将上传并发从 4 调至 8**：CIFS 绝对性能上升约 34%–41%，但目标 A/A 不可重复；Local 高/无仅 94.911%，HDFS 83.076%。未改默认值，也没有增加正式 preset。
2. **S3 consumer 内预取下一分片**：原型 SHA `31d779ec…` 在 CIFS 主组高/无为 104.255%，但 Local 新高/旧高为 96.268%；独立 12 个三臂块确认相对两组旧高分别只有 92.315%/93.030%。因此已撤回，原 S3 `staged/parts.rs` 与 9b 逐字节一致。原型源快照、红绿测试和全部真实失败仍归档，不能把原型通过当成当前版本通过。
3. **byte-aware producer 候选（已撤回）**：只改变小读块进入目标写入单位的队列容量，保留原 S3 writer。虽然减少了改动范围，原磁盘门槛及 Local 快速目标门槛仍有失败，不能按无回退接受。因此已撤回全部 8 个 Rust 文件变更；新测试及候选源代码完整保存在归档，保留版本不引入该接口或队列变更。拒绝候选不等于已经证明每个低分都由其代码引起；它表示证据不足以满足用户的无回退验收。

## NFS 追加根因对照（不覆盖主轮失败）

在相同候选、原磁盘目标上追加预先固定的 6 个三臂块，共 18 次 512 MiB：A/A 的 95% 区间 `{NA['control_ratio_interval_95']}`，高/无 QoS 为 {pct(NA['ratio'])}，`qualified={NA['qualified']}`。使用同一 idle/完整哈希/新目标前缀/整组后清理，没有替换上表 NFS 主轮判定。

独立 NFS4.1 读源使用专用、明确开启完整读窗口的 source-only 探针（NFS/QoS 代码与 9b/实验候选相同），4 对原 512 MiB，baseline/high 分别 {NS['medians']['baseline']:.3f}/{NS['medians']['high']:.3f} MiB/s，比值 {pct(NS['ratio'])}。它不包含目标上传，属于诊断，不能当作端到端通过。该 512 MiB 诊断**失败**，不能隐藏：单次 baseline 0.228–0.282 s、high 0.265–0.288 s，都是 515 次请求、每次最大 1,044,480 字节，未发生请求膨胀。追加的高/无比值区间为 `[0.79465,0.98128]`，未具备 2% 认证精度，也不能仅凭它把 NFS 源侧排除。

因此在初次清理后，仅重新创建本 run 的 NFS 源数据，使用同一个 1 MiB pattern 增加**独立 4 GiB 纯读诊断**，6 个预先固定的 A/A/high 平衡块。该试验不替换原 512 MiB 和端到端失败。4 GiB 高/无为 {pct(NL['ratio'])}，A/A 95% 区间 `{NL['control_ratio_interval_95']}`，高/无 95% 区间 `{NL['high_ratio_interval_95']}`，`qualified={NL['qualified']}`。同时记录每个子进程 CPU 与上下文切换；采样后在 finally 中删除重新创建的 NFS 源目录和本地 4 GiB fixture，清理结果追加到原记录，初次记录独立保留。4 GiB 的子进程 user CPU 中位数 baseline/high 约 2.452/2.448 s、system CPU 约 3.000/2.729 s，包含本地预读 hash 和连接准备，不能当作仅计时区间的 CPU。未观察到稳定的每字节 CPU 增量，但 A/A 仍不可重复，不能认证 2% 差异，也不能以长测覆盖 512 MiB 失败。追加组首次还在未使用的 Local 根目录连接阶段被拦截，0 个计时源读取样本；创建该空目录后按原计划重试，原错误和首次清理结果均保留。

## Runner 和证据可靠性修复

公开 `run-backend-qos.py`、cross-backend runner 新增可选 `--performance-control --isolated-destinations --cleanup-binary ...`。原有 median 98% 门槛保留；另用预先固定的 paired-block percentile bootstrap（4,000 次，seed 20261030）检查 A/A 区间在 `[0.98,1/0.98]`、高/无区间下界≥0.98。它是诊断精度门槛，不是对未来每次传输的统计保证。

每个样本使用独有前缀，最后统一清理；run ID 必须是确切的受控路径组件。已有 `finally` 覆盖异常及 KeyboardInterrupt 的栈展开；SIGKILL/进程树被终止仍须外层 always 清理。导入 baseline 同时绑定配置/二进制/repeats/idle、A/A 选项、目标生命周期和继承的后端并发环境，不能把运行参数不一致的结果合并。

修复另一项真实 harness 缺陷：新建 fixtures 原先遗漏 profile 自己配置的 `performance_size_mib=512`，导致干净目录 seed 失败。先有失败测试，再修复生成集合；干净目录中真实 CIFS seed + 两次 512 MiB→S3 拷贝、全量哈希与清理全部成功。该 smoke 有独立随机 fixture family，审计按 `(golden root family, size)` 分组；没有把不同输入的 hash 强行当作相同。

S3→NFS 追加组另有一次测试脚本 URI 拼接错误：路径被接到了查询参数后，目标连接在 payload 传输前被拒绝。错误日志和修正前脚本均保留；修正后复用已完成且 hash 校验成功的 48 个样本，仅执行原计划中未完成的 NFS 样本，没有重跑或筛掉已有性能结果；48+10 个复用样本在最终收集后逐文件 SHA 仍完全相同。公开 runner 的 URI helper 已有参数保留测试；这里修的是独立补测脚本。有限配额补测还修正了历史 Local 命令省略可选 cleanup 参数的兼容处理，保留并复用前 10 个已完成样本；错误发生在 Local payload 执行前，未改变 copy 模式、配额或原计划。

## 校验、版本与清理

- 已撤回候选的 Rust workspace/lib：**{validation['rust_passed']} passed、{validation['rust_failed']} failed、{validation['rust_ignored']} ignored，{validation['rust_suites']} suites**。Python：**{validation['python_passed']} passed**。release examples Clippy、S3+transfer lib/tests Clippy `-D warnings`、format、架构依赖检查通过；现有 binrw future-incompat 警告没有新增依赖。
- 最终保留版本重新验证：**{TV['rust_passed']} passed、{TV['rust_failed']} failed、{TV['rust_ignored']} ignored**，Clippy、format、架构检查通过，release SHA 与 9b 相同。所有生产 Rust/Cargo 与 9b 相同，未将失败的性能优化留在工作区。
- HEAD `{S['git_commit']}` + 既有 QoS 工作区改动；本轮没有提交、推送或改 Cargo.lock。实验候选源快照 {len(S['files'])} 个文件，保留源码快照 {len(T['files'])} 个文件；`full-working-tree.patch` 可从记录的 HEAD 还原，`qos-followup.patch` 明确仅为候选相对前一已接受 9b 状态的差异；`retained-working-tree.patch` 另从 HEAD 重放并验证保留的源码状态。
- 旧二进制 `{S['reference_9b_binary_sha256']}`；已撤回候选 `{S['candidate_binary_sha256']}`；最终保留 `{T['retained_binary_sha256']}`。探针另用单独二进制，结果不计入正常性能验收。
- 独立审计重新计算中位数/比值/门槛、有限配额源 trace、实际 SDK 分片请求数、目标 idle 前提、原配额命令及 release SHA 绑定；{A['measurement_records']} 条测量记录（含 baseline 导入副本），{A['unique_measurement_records']} 个不同二进制/摘要/耗时记录。保留可重建全部四组输入 hash 的小型 1 MiB fixture block，排除 128/512 MiB/4 GiB 大型数据体和凭据。
- 所有样本目标清理返回码及最后生命周期清理已检查：CIFS 整个本 run（含 smoke source）、NFS3/v4.1、S3 两个确切 run 前缀、HDFS 本 run 及本地 fixtures 均已移除；S3 同时检查版本/删除标记/未完成 MPU。未使用的 NFSv4.0 导出未触碰。临时 RAM S3 实例已停止并移除，原共享 RustFS PID 816 保持运行且命令行一致，共享 keytab/服务设置未修改。

## 可下载证据

- [机器摘要](summary.json)、[当前有限配额完整判定](checks.json)、[失败阶段分解](failure-analysis.json)、[逐次测量](measurements.csv)。
- [完整原始证据和源快照](raw-evidence.tar.gz)、[逐文件 SHA256 与凭据扫描](archive-audit.json)、[独立审计](evidence-audit.json)。
- [最终保留源码指纹](retained-source-manifest.json)、[候选撤回记录](candidate-rejection.json)。
- [数据/服务清理结果](cleanup.json)、[私有配置和票据清理](private-cleanup.json)、[附件 SHA256](SHA256SUMS)。

复核应先验附件 SHA，再验 archive manifest；保留最初失败轮、原始顺序和门槛。当前阻止严格全绿验收的是已列出的实际失败，以及原磁盘目标不足以认证 2% 差异的 A/A 精度。快速目标通过不赋予原共享磁盘目标通过资格。
'''
(O/'REPORT.md').write_text(text)
summary={'status':status,'retained_state':T,'candidate_rejection':read(B/'candidate-rejection.json'),'candidate_binary_sha256':S['candidate_binary_sha256'],'performance_original_target':dict(rows),'current_raw_performance_failures':current_failures,'original_target_finite_limits':finite,'original_target_precision':perf,'diagnostic_fast_target':public,'validation':validation,'measurement_records':A['measurement_records'],'nfs_source_diagnostics':{'original512MiB':NS,'long4GiB':read(R/'nfs-source-long/summary.json')},'no_production_performance_optimization_accepted':True,'cleanup':C}
(O/'summary.json').write_text(json.dumps(summary,indent=2));(O/'checks.json').write_text(json.dumps(finite_fail,indent=2))
# Preserve every finite verdict, not only failures, in the attachment.
allchecks=[]
for name in ['buffer-limits','buffer-source-limits']:
 allchecks.extend(dict(experiment=name,**v) for v in read(R/name/'checks.json'))
(O/'checks.json').write_text(json.dumps(allchecks,indent=2))
for name,source in [('measurements.csv',B/'measurements.csv'),('evidence-audit.json',B/'evidence-audit.json'),('cleanup.json',R/'cleanup.json'),('failure-analysis.json',B/'failure-analysis.json'),('retained-source-manifest.json',B/'retained-source-manifest.json'),('candidate-rejection.json',B/'candidate-rejection.json')]: (O/name).write_bytes(source.read_bytes())
print(status,'raw performance failures',len(current_failures),'finite',npassed,'/',nchecks,'new',nnew)
