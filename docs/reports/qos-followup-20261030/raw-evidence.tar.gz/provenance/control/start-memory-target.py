from pathlib import Path
import json,paramiko,shlex,secrets,base64
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();cfg=json.load(s.open(r+'/endpoints.private.json'));ak='qos-'+secrets.token_hex(8);sk=secrets.token_urlsafe(32)
payload={'run_id':x['run_id'],'ak':ak,'sk':sk}
# Private stdin carries credentials; neither argv nor public logs contain them.
script='''from pathlib import Path
import json,sys,os,socket,subprocess
p=json.load(sys.stdin);run=p['run_id'];assert run.startswith('nightly-qos-followup-') and '/' not in run
root=Path('/dev/shm')/run;assert not root.exists();v=os.statvfs('/dev/shm');assert v.f_bavail*v.f_frsize>6*1024**3,'insufficient isolated tmpfs space'
mem={l.split(':')[0]:int(l.split(':')[1].split()[0]) for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')};assert mem['MemAvailable']>10*1024**2,'insufficient available RAM'
for port in range(19030,19050):
 try:
  sock=socket.socket();sock.bind(('10.10.1.13',port));sock.close();break
 except OSError:continue
else:raise RuntimeError('no private test port available')
root.mkdir(mode=0o700);logs=Path('/var/lib/terrasync-ci')/run;logs.mkdir(exist_ok=True);log=logs/'memory-server.private.log';handle=log.open('w');os.chmod(log,0o600)
env={**os.environ,'RUSTFS_ACCESS_KEY':p['ak'],'RUSTFS_SECRET_KEY':p['sk'],'RUSTFS_CONSOLE_ENABLE':'false','RUSTFS_OBS_ENDPOINT':'','RUSTFS_REGION':'us-east-1'}
child=subprocess.Popen(['/usr/local/bin/rustfs','server','--address',f'10.10.1.13:{port}',str(root)],env=env,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True);handle.close();info={'pid':child.pid,'port':port,'root':str(root),'exe':'/usr/local/bin/rustfs','scope':'isolated tmpfs diagnostic; shared rustfs service unchanged'};(logs/'memory-server.json').write_text(json.dumps(info));print(json.dumps(info))
'''
cmd='ssh -i /home/github-runner/.ssh/terrasync_lab -o BatchMode=yes -o ConnectTimeout=5 root@10.131.9.13 '+shlex.quote('python3 -c '+shlex.quote(script));i,o,e=c.exec_command(cmd,timeout=10);i.write(json.dumps(payload));i.channel.shutdown_write();out=o.read().decode();code=o.channel.recv_exit_status();assert code==0,'isolated memory target startup failed; inspect private status without credentials';info=json.loads(out);cfg['destinations']['s3-memory']={'endpoint':f's3://{ak}:{sk}@qos-followup.10.10.1.13:{info["port"]}/ci/{x["run_id"]}/destination/{{pair}}'}
with s.file(r+'/endpoints.private.json','w') as f:f.write(json.dumps(cfg))
s.chmod(r+'/endpoints.private.json',0o600)
with s.file(r+'/memory-target.json','w') as f:f.write(json.dumps(info,indent=2))
ready='''import json,time,boto3
from botocore.config import Config
from pathlib import Path
cfg=json.load(open('endpoints.private.json'));from urllib.parse import urlsplit
u=urlsplit(cfg['destinations']['s3-memory']['endpoint']);client=boto3.client('s3',endpoint_url='http://'+u.hostname.split('.',1)[1]+':'+str(u.port),aws_access_key_id=u.username,aws_secret_access_key=u.password,region_name='us-east-1',config=Config(retries={'total_max_attempts':1},connect_timeout=3,read_timeout=5))
for i in range(60):
 try:client.create_bucket(Bucket='qos-followup');Path('memory-target-ready.json').write_text(json.dumps({'ready':True,'attempt':i+1}));print('Isolated S3 target ready');break
 except Exception:time.sleep(1)
else:raise RuntimeError('isolated S3 target not ready; inspect private server log')
'''
with s.file(r+'/memory-target-ready.py','w') as f:f.write(ready)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 memory-target-ready.py',timeout=90);out=o.read().decode();assert o.channel.recv_exit_status()==0,'memory S3 startup failed';print(out.strip(),json.dumps(info));s.close();c.close()
