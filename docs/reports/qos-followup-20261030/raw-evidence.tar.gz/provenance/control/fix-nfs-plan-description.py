from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
stop='''from pathlib import Path
import os,signal
r=Path.cwd();assert not (r/'buffer-nfs-attribution').exists();matches=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if b'buffer-nfs-attribution.py' in (p/'cmdline').read_bytes().split(bytes([0])) and (p/'cwd').resolve()==r:matches.append(int(p.name))
 except (OSError,RuntimeError):pass
assert len(matches)==1;os.kill(matches[0],signal.SIGTERM)
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(stop));assert o.channel.recv_exit_status()==0
t=s.open(r+'/buffer-nfs-attribution.py').read().decode();t=t.replace("for b in ['qos-bin','buffer-bin']","for b in ['buffer-bin']").replace('same original disk target; compare old 9b56c318 against byte-aware producer fix 0070c0b7; fresh destinations and deferred cleanup for every arm; no shared service change','same candidate binary across baseline/control/high arms; NFS4.1 source to original S3 disk target; diagnostic A/A precision; primary failures retained; fresh destinations and deferred cleanup; no shared service change')
Path('.scratch/qos-followup/buffer-nfs-attribution.py').write_text(t)
with s.file(r+'/buffer-nfs-attribution.py','w') as f:f.write(t)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 buffer-nfs-attribution.py >buffer-nfs-attribution.log 2>&1 </dev/null &');o.channel.recv_exit_status();print('Corrected unstarted diagnostic plan description and binary list; no sample or planned arm changed.');s.close();c.close()
