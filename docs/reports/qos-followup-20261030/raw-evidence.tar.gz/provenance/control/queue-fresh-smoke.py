from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
try:s.mkdir(r+'/final-harness',mode=0o700)
except OSError:pass
for name in ['run-backend-qos.py','run-local-qos.py','qos_evidence.py']:s.put('tests/lab/'+name,r+'/final-harness/'+name)
cfg=json.load(s.open(r+'/endpoints.private.json'));p={'run_id':x['run_id'],'profiles':[{'name':'fresh-cifs-to-s3','source_kind':'cifs','destination_kind':'s3','env':{**cfg['sources']['cifs']['env'],'QOS_SOURCE':'smb:'+x['run_id']+'/smoke-source','QOS_DESTINATION':cfg['destinations']['s3-memory']['endpoint'].replace('{pair}','fresh-fixture-smoke'),'DATA_MOVER_S3_WRITE_INFLIGHT':'4'},'transfer_profile':'cross','size_mib':128,'performance_size_mib':512,'chunk_bytes':2097152,'soft_mibps':8}]}
with s.file(r+'/fresh-fixture-smoke-profile.private.json','w') as f:f.write(json.dumps(p))
s.chmod(r+'/fresh-fixture-smoke-profile.private.json',0o600)
script='''from pathlib import Path
import json,time,subprocess
r=Path.cwd()
while not (r/'pipeline-attempt-probe/complete.json').exists():time.sleep(1)
root=r/'fresh-fixture-smoke';assert not root.exists();command=['python3',str(r/'final-harness/run-backend-qos.py'),'--config',str(r/'fresh-fixture-smoke-profile.private.json'),'--root',str(root),'--binary',str(r/'pipeline-bin'),'--phase','survey','--repeats','1','--isolated-destinations','--cleanup-binary',str(r/'qos-cleanup'),'--retain-source','--performance-idle-ms','1000'];(r/'fresh-fixture-smoke-plan.json').write_text(json.dumps({'command':command,'scope':'fresh fixture generation and real seeding, not a new performance qualification cohort; configured128MiB finite/512MiB performance, no precreated golden fixture','expected_measured_copies':2},indent=2))
with (r/'fresh-fixture-smoke.log').open('w') as log:v=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
checks=json.load(open(root/'survey/checks.json'));executed=not any(c['case']=='execution' and not c['passed'] for c in checks);complete=all((root/'survey/fresh-cifs-to-s3'/f'{arm}-0.json').exists() for arm in ['baseline','high']);d={'exit':v.returncode,'configured_512_fixture_created':(root/'fixtures/512.bin').stat().st_size==512*1048576,'all_copies_completed_and_verified':executed and complete,'cleanup_passed':all(c['passed'] for c in checks if c['name']=='isolated_destination_removed')};(r/'fresh-fixture-smoke-status.json').write_text(json.dumps(d,indent=2));print(d,flush=True)
'''
with s.file(r+'/fresh-fixture-smoke.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 fresh-fixture-smoke.py >fresh-fixture-smoke-driver.log 2>&1 </dev/null &');print('Final-harness fresh512MiB fixture/seeding smoke queued after all performance/attempt controls; independent golden namespace, real CIFS→RAM S3, owned source and deferred destination cleanup');s.close();c.close()
