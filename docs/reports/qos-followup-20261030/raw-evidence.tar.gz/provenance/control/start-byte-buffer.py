from pathlib import Path
import json,paramiko,shlex,hashlib
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();binary=Path('/work/cargo-target/release/examples/backend_qos_acceptance');digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74';s.put(str(binary),r+'/buffer-bin');s.chmod(r+'/buffer-bin',0o700)
for old,new in [('pipeline-comparison','buffer-comparison'),('pipeline-other-routes','buffer-other-routes'),('pipeline-limits','buffer-limits'),('pipeline-memory','buffer-memory'),('local-memory','buffer-local-memory')]:
 t=Path('.scratch/qos-followup/'+old+'.py').read_text().replace('pipeline-bin','buffer-bin').replace(old,new).replace('prefill one next part while the upload window is full','byte-aware producer input capacity; preserve original upload loop').replace('prefill next part is the only production change','only producer capacity for smaller source chunks changes').replace('pipeline fix 31d779ec','byte-aware producer fix '+digest[:8])
 t=t.replace("r/'pipeline-comparison/complete.json'","r/'buffer-comparison/complete.json'").replace("r/'pipeline-other-routes/complete.json'","r/'buffer-other-routes/complete.json'").replace("r/'pipeline-limits/complete.json'","r/'buffer-limits/complete.json'")
 if old=='local-memory':t=t.replace("r/'nfs-strict-confirmation/complete.json'","r/'buffer-memory/complete.json'")
 t=t.replace('202610312','202610320').replace('202610313','202610321').replace('202610314','202610322').replace('202610317','202610323')
 # Fail before measuring if a binary was changed after upload.
 t=t.replace('r=Path.cwd()',"r=Path.cwd()\nassert hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest()=="+repr(digest)) if 'import json,os,subprocess,time,random,statistics,hashlib' in t else t
 Path('.scratch/qos-followup/'+new+'.py').write_text(t)
 with s.file(r+'/'+new+'.py','w') as f:f.write(t)
 _,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 '+new+'.py >'+new+'.log 2>&1 </dev/null &');o.channel.recv_exit_status()
print('Deployed candidate',digest,'and queued 50+64+25+12+12 real copies with default S3 write cap 4, serial original disk, bounded RAM controls.');s.close();c.close()
