from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd()
while not (r/'memory-final-status.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3');base_env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'depth-sweep';folder.mkdir();rng=random.Random(202610309);order=[]
for _ in range(3):
 depths=[1,2,4,8];rng.shuffle(depths);order.append(depths)
(folder/'plan.json').write_text(json.dumps({'order':order,'seed':202610309,'size_mib':128,'repetitions':3,'scope':'diagnostic disk-target write concurrency sweep, QoS absent; fixed 8MiB MPU parts and source concurrency; no global service changes','binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest()},indent=2));values={n:[] for n in [1,2,4,8]};targets=[]
for i,depths in enumerate(order):
 for depth in depths:
  label=f'depth-{depth}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/depth-sweep/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':str(depth)};targets.append(env)
  cmd=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','128.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000'];v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'depth sweep failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=depth;d['destination_sample']=label;(folder/(label+'.json')).write_text(json.dumps(d));values[depth].append(d['mibps']);print(label,d['mibps'],flush=True)
med={n:statistics.median(v) for n,v in values.items()};d={'medians':med,'ratios_to_default_four':{n:v/med[4] for n,v in med.items()},'diagnostic_only':True};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True)
cleanup=[]
for i,env in enumerate(targets):
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/f'cleanup-{i}.stderr').write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':12,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
with s.file(r+'/depth-sweep.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 depth-sweep.py >depth-sweep.log 2>&1 </dev/null &');print('Predeclared write-depth 1/2/4/8 sweep queued after all RAM finite cases; unchanged 8MiB parts and no shared service mutation');s.close();c.close()
