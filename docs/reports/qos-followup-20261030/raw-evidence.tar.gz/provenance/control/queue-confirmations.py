from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
local='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib,resource
from qos_evidence import secret_values,redact,compare_performance
from target_settle import settle_target
r=Path.cwd()
while not (r/'pipeline-memory/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','local-to-s3');base_env={**os.environ,**cfg['sources']['local']['env'],'NO_PROXY':'*','no_proxy':'*','DATA_MOVER_S3_WRITE_INFLIGHT':'4'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'local-absolute';folder.mkdir();arms=['old-high-a','old-high-b','fixed-high'];rng=random.Random(202610315);order=[]
for _ in range(4):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':12,'order':order,'seed':202610315,'size_mib':512,'scope':'direct absolute high-QoS regression confirmation with identical old/old AA control; initial 96.268% result retained','binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','pipeline-bin']}},indent=2));values={a:[] for a in arms};targets=[]
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/local-absolute/'+label};targets.append((label,env));cmd=[str(r/('pipeline-bin' if arm=='fixed-high' else 'qos-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000','--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled'];before=resource.getrusage(resource.RUSAGE_CHILDREN);v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);after=resource.getrusage(resource.RUSAGE_CHILDREN);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'absolute Local regression execution failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;d['process_cpu_seconds']=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime);(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],d['process_cpu_seconds'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};comparison=compare_performance(values['old-high-a'],values['fixed-high'],values['old-high-b']);d={'medians':med,'fixed_to_old_a':med['fixed-high']/med['old-high-a'],'fixed_to_old_b':med['fixed-high']/med['old-high-b'],'comparison':comparison,'blocks':12};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True);cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':36,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
nfs='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib,resource
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd()
while not (r/'local-absolute/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','nfs41-to-s3');base_env={**os.environ,**cfg['sources']['nfs41']['env'],'NO_PROXY':'*','no_proxy':'*','DATA_MOVER_S3_WRITE_INFLIGHT':'4'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'nfs-strict-confirmation';folder.mkdir();ref=next(p for p in json.load(open('pipeline-fixed-limits-reference.json')) if p['profile']=='nfs41-to-s3' and p['case']=='bandwidth-strict');rng=random.Random(202610316);order=[['old','fixed']]*3+[['fixed','old']]*2;rng.shuffle(order);(folder/'plan.json').write_text(json.dumps({'pairs':5,'order':order,'seed':202610316,'reference':ref,'scope':'exact original finite quota/128MiB direct old/new confirmation; initial 97.852% failure retained; same lifecycle in both arms'},indent=2));values={a:[] for a in ['old','fixed']};phase={a:[] for a in values};targets=[]
for i,pair in enumerate(order):
 for arm in pair:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/nfs-strict-confirmation/'+label};targets.append((label,env));cmd=[v.replace('/tmp/nightly-qos-cross-20261029192047',str(r)) for v in ref['command']];cmd[0]=str(r/('pipeline-bin' if arm=='fixed' else 'qos-bin'));cmd[cmd.index('--destination-cleanup')+1]='keep';v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'NFS strict confirmation execution failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;(folder/(label+'.json')).write_text(json.dumps(d));soft=int(cmd[cmd.index('--soft-bytes')+1]);ratio=d['bytes']/d['seconds']/soft;values[arm].append(ratio);a=d['admissions'];phase[arm].append({'first_admission':a[0]['seconds'],'last_admission':a[-1]['seconds'],'tail_seconds':d['seconds']-a[-1]['seconds']});print(label,ratio,phase[arm][-1],flush=True)
med={a:statistics.median(v) for a,v in values.items()};d={'end_to_end_ratio_medians':med,'fixed_to_old':med['fixed']/med['old'],'absolute_non_regression_passed':med['fixed']/med['old']>=.98,'e2e_98_percent':{a:v>=.98 for a,v in med.items()},'phase_medians':{a:{k:statistics.median(v[k] for v in rows) for k in rows[0]} for a,rows in phase.items()},'pairs':5};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True);cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':10,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
for name,script in [('local-absolute',local),('nfs-strict-confirmation',nfs)]:
 with s.file(r+'/'+name+'.py','w') as f:f.write(script)
 _,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 '+name+'.py >'+name+'.log 2>&1 </dev/null &')
print('Independent confirmations queued serially:36 Local high-QoS copies with old/old AA control, then10 exact-original NFS strict quota copies; no failed samples removed');s.close();c.close()
