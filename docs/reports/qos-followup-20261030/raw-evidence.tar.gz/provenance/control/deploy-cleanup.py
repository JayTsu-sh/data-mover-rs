import json,paramiko
from pathlib import Path
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
for src,name in [('/work/cargo-target/release/examples/backend_qos_cleanup','qos-cleanup'),('/work/cargo-target/release/deps/hdfs_native_contract-2b754414f99cc3a6','hdfs-cleanup')]:s.put(src,r+'/'+name);s.chmod(r+'/'+name,0o700)
t=Path('tests/lab/cleanup-run.sh').read_text();old='cargo test --test hdfs_native_contract nightly_lab_cleanup_confined_run_root -- \\\n  --ignored --exact --test-threads=1';assert old in t;t=t.replace(old,'"$(dirname "$0")/hdfs-cleanup" nightly_lab_cleanup_confined_run_root -- \\\n  --ignored --exact --test-threads=1')
for name,text in [('cleanup-run.sh',t),('cleanup.py',Path('.scratch/qos-followup/cleanup-remote.py').read_text())]:
 with s.file(r+'/'+name,'w') as f:f.write(text)
 s.chmod(r+'/'+name,0o700)
print('Exact-owned cleanup deployed; not started and cannot run without explicit finish marker and all seven completion files.');s.close();c.close()
