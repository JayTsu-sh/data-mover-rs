from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
import json,hashlib
r=Path.cwd();assert r.name=='nightly-qos-followup-20261030045923';assert (r/'cleanup.json').exists();private=list(r.rglob('*.private.json'));tickets=[p for p in r.rglob('*') if p.is_file() and (p.name.startswith('krb5cc') or p.name.endswith('.ccache'))]
for p in private+tickets:assert p.resolve().is_relative_to(r.resolve());p.unlink()
removed_binaries=[]
for row in json.load(open(r/'binary-inventory.json')):
 name=row['path'];assert Path(name).name==name and (name.endswith('-bin') or name in ['source-probe','qos-cleanup','hdfs-cleanup']);p=r/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink();removed_binaries.append(name)
remaining=list(r.rglob('*.private.json'))+[p for p in r.rglob('*') if p.is_file() and (p.name.startswith('krb5cc') or p.name.endswith('.ccache'))];assert not remaining
data={'private_configs_removed':len(private),'ticket_caches_removed':len(tickets),'remaining_private_configs_or_ticket_caches':0,'binary_files_removed':removed_binaries,'scope':'only this isolated run; shared keytab/services unchanged','data_fixture_directories_remaining':[str(p.relative_to(r)) for p in [r/'fixtures',r/'source',r/'destination',r/'fresh-fixture-smoke/fixtures',r/'fresh-fixture-smoke/destination'] if p.exists()]};assert not data['data_fixture_directories_remaining'];(r/'private-cleanup.json').write_text(json.dumps(data,indent=2));print(json.dumps(data))
'''
_,o,e=c.exec_command('cd '+shlex.quote(x['root'])+' && python3 -c '+shlex.quote(script));out=o.read().decode();assert o.channel.recv_exit_status()==0,'private cleanup failed';d=json.loads(out)
for p in [Path('/work/qos-followup-evidence/private-cleanup.json'),Path('docs/reports/qos-followup-20261030/private-cleanup.json')]:p.write_text(json.dumps(d,indent=2))
print('Private configs and own ticket caches removed:',d['private_configs_removed'],d['ticket_caches_removed']);c.close()
