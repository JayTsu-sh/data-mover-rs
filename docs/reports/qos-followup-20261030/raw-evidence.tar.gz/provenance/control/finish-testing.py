import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
import json,subprocess
r=Path.cwd();names=['buffer-comparison','buffer-other-routes','buffer-limits','buffer-memory','buffer-local-memory','buffer-source-routes','buffer-source-limits','buffer-harness','buffer-nfs-attribution','buffer-nfs-source-only']
assert all((r/name/'complete.json').exists() for name in names),'some planned phases incomplete';assert (r/'fixture-patterns/manifest.json').exists();assert not (r/'finish-testing').exists();(r/'finish-testing').write_text(json.dumps({'all_planned_phases_complete':names,'candidate_status':'rejected; retained production release9b; all measured outcomes preserved','patterns_captured_before_cleanup':True},indent=2));subprocess.Popen(['python3','cleanup.py'],stdout=(r/'cleanup.log').open('w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True);print('All planned phases complete; exact-owned cleanup started.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;c.close()
