from pathlib import Path
import hashlib,subprocess,shutil,json
paths=['crates/backend-cifs/src/backend/read_pipeline.rs','crates/backend-s3/src/backend/client/role_protocol.rs'];original={p:Path(p).read_bytes() for p in paths};written={}
try:
 p=paths[0];s=original[p].decode();s=s.replace('    let depth = request.read_inflight;', '''    #[derive(Default)]
    struct Followup { active: std::sync::atomic::AtomicU64, maximum: std::sync::atomic::AtomicU64, reads: std::sync::atomic::AtomicU64, read_ns: std::sync::atomic::AtomicU64, qos_ns: std::sync::atomic::AtomicU64 }
    use std::sync::atomic::Ordering::Relaxed;
    let followup = std::sync::Arc::new(Followup::default());
    let mut followup_send_ns = 0u128;
    let depth = request.read_inflight;''')
 s=s.replace('            let future = async move {','            let followup_task = followup.clone();\n            let future = async move {')
 s=s.replace('                    if let Some(qos) = &request.source_qos {','                    let followup_qos = std::time::Instant::now();\n                    if let Some(qos) = &request.source_qos {')
 a='''                    state
                        .cursor
                        .read_at(offset, wire_count)
                        .await
                        .map_err(|e| classify(&request.path, Operation::Read, &e))'''
 b='''                    followup_task.qos_ns.fetch_add(followup_qos.elapsed().as_nanos() as u64, Relaxed);
                    let active = followup_task.active.fetch_add(1, Relaxed) + 1;
                    followup_task.maximum.fetch_max(active, Relaxed);
                    let followup_read = std::time::Instant::now();
                    let result = state.cursor.read_at(offset, wire_count).await.map_err(|e| classify(&request.path, Operation::Read, &e));
                    followup_task.read_ns.fetch_add(followup_read.elapsed().as_nanos() as u64, Relaxed);
                    followup_task.reads.fetch_add(1, Relaxed);
                    followup_task.active.fetch_sub(1, Relaxed);
                    result'''
 assert s.count(a)==1;s=s.replace(a,b)
 s=s.replace('''        let Some((offset, count, result, admission)) = value else {
            return Ok(());''','''        let Some((offset, count, result, admission)) = value else {
            eprintln!("[FOLLOWUP-PROBE] cifs qos={} depth={} reads={} active_max={} read_ns={} admission_ns={} send_ns={}", request.source_qos.is_some(),depth,followup.reads.load(Relaxed),followup.maximum.load(Relaxed),followup.read_ns.load(Relaxed),followup.qos_ns.load(Relaxed),followup_send_ns);
            return Ok(());''')
 a='''        tokio::select! {
            () = request.cancel.cancelled() => return Err(failed(FailureClass::Cancelled)),
            result = tx.send''';assert s.count(a)==1;s=s.replace(a,'''        let followup_send = std::time::Instant::now();
        tokio::select! {
            () = request.cancel.cancelled() => return Err(failed(FailureClass::Cancelled)),
            result = tx.send''');a='''            result = tx.send(Ok(PositionedChunk { offset, data: bytes })) => if result.is_err() { return Ok(()) },
        }
''';assert s.count(a)==1;s=s.replace(a,a+'        followup_send_ns += followup_send.elapsed().as_nanos();\n');Path(p).write_text(s);written[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 p=paths[1];s=original[p].decode();a='''        self.role_upload_part(key, upload_id, part_number, bytes, content_md5_base64)
            .await''';b='''        let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
        let started = std::time::Instant::now();
        let length = bytes.len();
        let result = self.role_upload_part(key, upload_id, part_number, bytes, content_md5_base64).await;
        eprintln!("[FOLLOWUP-PROBE] part={} bytes={} start={} ns={} ok={}",part_number,length,stamp,started.elapsed().as_nanos(),result.is_ok());
        result''';assert s.count(a)==1;s=s.replace(a,b)
 a='''        self.role_complete_multipart(key, upload_id, parts).await''';assert s.count(a)==1;s=s.replace(a,'''        let started = std::time::Instant::now();
        let result = self.role_complete_multipart(key, upload_id, parts).await;
        eprintln!("[FOLLOWUP-PROBE] complete ns={} ok={}",started.elapsed().as_nanos(),result.is_ok());
        result''');Path(p).write_text(s);written[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 with open('/work/qos-followup-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-followup-probe')
finally:
 for p in written:
  assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==written[p];Path(p).write_bytes(original[p])
Path('.scratch/qos-followup/probe-source-sha.json').write_text(json.dumps({p:hashlib.sha256(v).hexdigest() for p,v in original.items()},indent=2))
print('Separate diagnostic probe built; source files restored exactly')
