import json,paramiko,shlex
from pathlib import Path
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
import json,subprocess
r=Path.cwd();folder=r/'buffer-local-memory';assert folder.exists() and not list(folder.iterdir()),'measurements already exist; do not discard';folder.rmdir();log=r/'buffer-local-memory.log';assert 'insufficient isolated RAM target capacity' in log.read_text();log.rename(r/'buffer-local-memory.capacity-abort.log');(r/'buffer-local-memory.capacity-abort.json').write_text(json.dumps({'stage':'pre-measurement capacity guard','measured_samples':0,'disposition':'waited for owned RAM instance garbage collection, retained original guard and plan, retried before any copy; no server restart or shared service mutation','raw_log':'buffer-local-memory.capacity-abort.log'},indent=2))
subprocess.Popen(['python3','buffer-local-memory.py'],stdout=(r/'buffer-local-memory.log').open('w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True);print('Resumed original Local RAM plan after natural capacity recovery; zero discarded samples; capacity failure retained.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;c.close()
