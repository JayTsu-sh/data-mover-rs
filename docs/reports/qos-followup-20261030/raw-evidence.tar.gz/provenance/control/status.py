import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
r=Path.cwd()
for n in ['buffer-comparison','buffer-other-routes','buffer-limits','buffer-memory','buffer-local-memory','buffer-source-routes','buffer-source-limits','buffer-harness','buffer-nfs-attribution','buffer-nfs-source-only','nfs-source-long']:
 if (r/n/'complete.json').exists():print(n,'COMPLETE')
 elif (r/n).exists():
  print(n,'RUNNING')
  print('\\n'.join(line[:240] for line in (r/(n+'.log')).read_text().splitlines()[-2:]))
 else:print(n,'QUEUED')
'''
_,o,e=c.exec_command('cd '+shlex.quote(x['root'])+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;c.close()
