from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd()
while not (r/'pipeline-probe/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));base_env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};target=cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3');secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'isolated-control';folder.mkdir();arms=['baseline-a','baseline-b','high'];rng=random.Random(202610308);order=[]
for _ in range(2):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':6,'size_mib':512,'order':order,'seed':202610308,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'minimum_ratio':.98,'idle_ms':1000,'destination_lifecycle':'fresh destination subprefix per sample; keep all published objects until complete; no per-sample deletes or replacement','scope':'AA repeatability control plus unchanged-binary high QoS comparison; original reproduction retained'},indent=2));values={a:[] for a in arms}
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/isolated-control/'+label}
  cmd=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination/cifs-to-s3/isolated-control'/label),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'isolated control failed';d=json.loads(v.stdout);d['command']=cmd;d['destination_sample']=label;d['destination_cleanup']='deferred';(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};ratio=med['high']/med['baseline-a'];aa=med['baseline-b']/med['baseline-a'];d={'medians':med,'high_to_baseline_a':ratio,'high_to_baseline_b':med['high']/med['baseline-b'],'high_passed':ratio>=.98,'aa_ratio':aa,'aa_repeatable':.98<=aa<=1/.98,'blocks':6,'production_code_unchanged':True};(folder/'summary.json').write_text(json.dumps(d,indent=2));(folder/'complete.json').write_text(json.dumps(d));print(d,flush=True)
'''
with s.file(r+'/isolated-control.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 isolated-control.py >isolated-control.log 2>&1 </dev/null &');print('Predeclared 6 balanced baseline A / identical baseline B / high-QoS blocks queued; each uses unique destination and defers all deletion');s.close();c.close()
