from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();t=s.open(r+'/buffer-source-limits.py').read().decode()
with s.file(r+'/buffer-source-limits.before-option-fix.py','w') as f:f.write(t)
t=t.replace("folder.mkdir();spec=","folder.mkdir(exist_ok=True);spec=").replace("route.mkdir();seed=","route.mkdir(exist_ok=True);seed=")
a="cmd[0]=str(r/'buffer-bin');cmd[cmd.index('--destination-cleanup')+1]='keep';v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(case+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'finite tuned copy failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;d['destination_sample']=name+'-'+case;(route/(case+'.json')).write_text(json.dumps(d));dual="
b="""cmd[0]=str(r/'buffer-bin')
  if '--destination-cleanup' in cmd:cmd[cmd.index('--destination-cleanup')+1]='keep'
  else:cmd+=['--destination-cleanup','keep']
  cached=route/(case+'.json')
  if cached.exists():
   d=json.load(open(cached));assert d['command']==cmd
  else:
   v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(case+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'finite tuned copy failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;d['destination_sample']=name+'-'+case;cached.write_text(json.dumps(d))
  dual="""
assert a in t;t=t.replace(a,b)
Path('.scratch/qos-followup/buffer-source-limits.resumed.py').write_text(t)
with s.file(r+'/buffer-source-limits.py','w') as f:f.write(t)
script='''from pathlib import Path
import json,subprocess
r=Path.cwd();folder=r/'buffer-source-limits';assert len([p for p in folder.rglob('*.json') if p.parent.name in ['s3-to-cifs','s3-to-hdfs'] and p.name!='seed.json'])==10
(r/'finite-option-preparation-error.json').write_text(json.dumps({'stage':'before first Local finite command execution','error':'legacy Local command has --copy but omits optional --destination-cleanup; scratch driver assumed it was present','fix':'set keep if present, append optional keep flag otherwise; source, file, quotas, chunk and copy profile unchanged','retained_completed_samples':10,'failed_payload_samples':0,'raw_log':'buffer-source-limits.log','before_fix_source':'buffer-source-limits.before-option-fix.py'},indent=2))
with (r/'buffer-source-limits.log').open('a') as log:subprocess.Popen(['python3','buffer-source-limits.py'],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
print('Resumed fixed original finite plan; retained10 completed samples; optional cleanup flag normalized without changing copy mode or quotas.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;s.close();c.close()
