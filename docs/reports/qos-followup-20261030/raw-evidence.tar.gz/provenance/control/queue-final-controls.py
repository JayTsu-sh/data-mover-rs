from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script=s.open(r+'/pipeline-memory.py').read().decode().replace("r/'pipeline-limits/complete.json'","r/'nfs-strict-confirmation/complete.json'").replace('pipeline-memory','local-memory').replace("cfg['sources']['cifs']['env']","cfg['sources']['local']['env']").replace('202610314','202610317').replace('fast-target regression and source-overhead control','fast-target Local regression and source-overhead control')
with s.file(r+'/local-memory.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 local-memory.py >local-memory.log 2>&1 </dev/null &')
s.put('/work/qos-followup-pipeline-attempt-probe',r+'/pipeline-attempt-probe-bin');s.chmod(r+'/pipeline-attempt-probe-bin',0o700)
script=s.open(r+'/attempt-probe.py').read().decode().replace("r/'tuned-limits/complete.json'","r/'local-memory/complete.json'").replace('attempt-probe','pipeline-attempt-probe')
a="order=[('default-baseline',4,False),('tuned-high',8,True),('tuned-baseline',8,False),('default-high',4,True)]";assert a in script;script=script.replace(a,"order=[('fixed-baseline',4,False),('fixed-high',4,True)]").replace("'samples':4","'samples':2")
with s.file(r+'/pipeline-attempt-probe.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 pipeline-attempt-probe.py >pipeline-attempt-probe.log 2>&1 </dev/null &');print('Final controls queued after confirmations:12 Local→RAM old/new copies, then2 instrumented SDK-attempt copies of final pipeline; default cap4 and8MiB parts throughout');s.close();c.close()
