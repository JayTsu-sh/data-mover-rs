from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('/work/qos-followup-attempt-probe',r+'/attempt-probe');s.chmod(r+'/attempt-probe',0o700)
script='''from pathlib import Path
import json,os,subprocess,time,hashlib,collections,re
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd()
while not (r/'tuned-limits/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3');base_env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'attempt-probe';folder.mkdir();order=[('default-baseline',4,False),('tuned-high',8,True),('tuned-baseline',8,False),('default-high',4,True)];(folder/'plan.json').write_text(json.dumps({'order':order,'binary_sha256':hashlib.sha256((r/'attempt-probe-bin').read_bytes()).hexdigest(),'scope':'HTTP SDK attempt count diagnostic only; no credentials or URLs logged; not performance acceptance'},indent=2));rows=[];targets=[]
for label,depth,limited in order:
 settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/attempt-probe/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':str(depth)};targets.append((label,env));cmd=[str(r/'attempt-probe-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
 if limited:cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
 v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'attempt diagnostic failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=depth;(folder/(label+'.json')).write_text(json.dumps(d));part_counts=collections.Counter(int(n) for n in re.findall(r'\\[FOLLOWUP-ATTEMPT\\] send_part=(\\d+)',v.stderr));statuses=collections.Counter(re.findall(r'\\[FOLLOWUP-ATTEMPT\\] status=(\\d+)',v.stderr));rows.append({'label':label,'part_attempts':sum(part_counts.values()),'distinct_parts':len(part_counts),'repeated_parts':sum(n-1 for n in part_counts.values()),'statuses':dict(statuses),'all_64_parts_once':part_counts=={i:1 for i in range(1,65)},'diagnostic_only':True});print(rows[-1],flush=True)
cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'summary.json').write_text(json.dumps(rows,indent=2));(folder/'complete.json').write_text(json.dumps({'samples':4,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
# The executable and result directory must have different names.
s.rename(r+'/attempt-probe',r+'/attempt-probe-bin')
with s.file(r+'/attempt-probe.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 attempt-probe.py >attempt-probe.log 2>&1 </dev/null &');print('Four SDK HTTP-attempt diagnostics queued strictly after all formal performance and quota cases');s.close();c.close()
