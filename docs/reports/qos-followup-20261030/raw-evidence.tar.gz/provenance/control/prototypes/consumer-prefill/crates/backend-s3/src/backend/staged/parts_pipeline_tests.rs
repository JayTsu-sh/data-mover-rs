//! A bounded upload window must overlap the next part's input with current RPCs.
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::Duration;

use bytes::Bytes;
use futures::{FutureExt as _, StreamExt as _, stream};
use tokio::sync::Notify;

use super::parts::PartTarget;
use super::*;
use crate::storage::backends::s3::tests::{MemoryS3, identity};

type TestResult = Result<(), Box<dyn std::error::Error>>;

#[tokio::test]
async fn full_upload_window_prefills_exactly_one_next_part() -> TestResult {
    let protocol = Arc::new(MemoryS3::default());
    let release = Arc::new(Notify::new());
    *protocol.upload_part_hook.lock().await = Some(Arc::new({
        let release = release.clone();
        move |number| {
            let release = release.clone();
            async move {
                if number == 1 {
                    release.notified().await;
                }
            }
            .boxed()
        }
    }));
    let destination = S3StagedDestination::new(protocol.clone(), identity());
    let path = StoragePath::new("file")?;
    let upload = protocol
        .begin_multipart("file")
        .await
        .map_err(|error| format!("{error:?}"))?;
    let target = PartTarget {
        stage: None,
        path: &path,
        key: "file",
        upload_id: &upload,
        part_size: 4,
        max_inflight: 1,
        checkpoint: None,
    };
    let read_ahead = Arc::new(Notify::new());
    let reads = Arc::new(AtomicUsize::new(0));
    let may_read_more = Arc::new(AtomicBool::new(false));
    let input: ByteStream = Box::pin(
        stream::iter([b"abcd".as_slice(), b"efgh".as_slice(), b"ij".as_slice()]).map({
            let read_ahead = read_ahead.clone();
            let reads = reads.clone();
            let may_read_more = may_read_more.clone();
            move |bytes| {
                let index = reads.fetch_add(1, Ordering::SeqCst);
                assert!(index < 2 || may_read_more.load(Ordering::SeqCst));
                if index == 1 {
                    read_ahead.notify_one();
                }
                Ok(Bytes::from_static(bytes))
            }
        }),
    );
    let uploading = destination.upload_parts(&target, Vec::new(), input);
    tokio::pin!(uploading);
    tokio::time::timeout(Duration::from_secs(1), async {
        tokio::select! {
            _ = uploading.as_mut() => panic!("upload ended before overlapping its input"),
            () = read_ahead.notified() => {},
        }
    })
    .await
    .map_err(|_| "full upload window stopped reading the next part")?;
    assert_eq!(reads.load(Ordering::SeqCst), 2);
    assert!(futures::poll!(uploading.as_mut()).is_pending());
    may_read_more.store(true, Ordering::SeqCst);
    release.notify_one();
    let uploaded = uploading.await?;
    assert_eq!(uploaded.bytes, 10);
    assert_eq!(uploaded.parts.len(), 3);
    let mut parts = protocol.uploads.lock().await[&upload].1.clone();
    parts.sort_by_key(|part| part.0);
    let bytes: Vec<_> = parts.into_iter().flat_map(|part| part.1).collect();
    assert_eq!(bytes, b"abcdefghij");
    Ok(())
}

#[tokio::test]
async fn full_and_partial_parts_preserve_the_configured_rpc_limit() -> TestResult {
    for maximum in [1, 2, 4] {
        let protocol = Arc::new(MemoryS3::default());
        let active = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        *protocol.upload_part_hook.lock().await = Some(Arc::new({
            let active = active.clone();
            let peak = peak.clone();
            move |_| {
                let active = active.clone();
                let peak = peak.clone();
                async move {
                    let count = active.fetch_add(1, Ordering::SeqCst) + 1;
                    peak.fetch_max(count, Ordering::SeqCst);
                    tokio::time::sleep(Duration::from_millis(20)).await;
                    active.fetch_sub(1, Ordering::SeqCst);
                }
                .boxed()
            }
        }));
        let destination = S3StagedDestination::new(protocol.clone(), identity());
        let path = StoragePath::new("file")?;
        let upload = protocol
            .begin_multipart("file")
            .await
            .map_err(|error| format!("{error:?}"))?;
        let target = PartTarget {
            stage: None,
            path: &path,
            key: "file",
            upload_id: &upload,
            part_size: 4,
            max_inflight: maximum,
            checkpoint: None,
        };
        let input: ByteStream =
            Box::pin(stream::iter([Ok(Bytes::from_static(b"abcdefghijklmnopq"))]));
        let uploaded = destination.upload_parts(&target, Vec::new(), input).await?;
        assert_eq!(uploaded.parts.len(), 5);
        assert_eq!(uploaded.bytes, 17);
        assert_eq!(*protocol.part_uploads.lock().await, 5);
        assert!(peak.load(Ordering::SeqCst) <= maximum);
        assert_eq!(active.load(Ordering::SeqCst), 0);
    }
    Ok(())
}
