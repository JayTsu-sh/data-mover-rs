from pathlib import Path
import json,collections
B=Path('/work/qos-followup-evidence');R=B/'raw';rows=[]
for folder in ['buffer-limits','buffer-source-limits']:
 p=R/folder/'checks.json'
 if not p.exists():continue
 checks=json.load(open(p));bycase=collections.defaultdict(list)
 for g in checks:
  if not g['passed']:bycase[(g['profile'],g['case'])].append(g)
 for (profile,case),failed in bycase.items():
  d=json.load(open(R/folder/profile/(case+'.json')));cmd=d['command'];admissions=d['admissions'];first,last=admissions[0]['seconds'],admissions[-1]['seconds'];phases=[]
  for resource in ['bytes','iops']:
   flag='--soft-'+resource
   if flag not in cmd:continue
   rate=int(cmd[cmd.index(flag)+1]);n=d['bytes'] if resource=='bytes' else d['operations'];initial=admissions[0]['bytes'] if resource=='bytes' else 1;ideal=n/rate;active_ideal=(n-initial)/rate;active_drift=last-first-active_ideal;tail=d['seconds']-last
   phases.append({'resource':resource,'soft_rate':rate,'ideal_total_seconds':ideal,'end_to_end_ratio':ideal/d['seconds'],'first_admission_seconds':first,'last_admission_seconds':last,'ideal_active_admission_span_seconds':active_ideal,'active_admission_drift_seconds':active_drift,'post_last_admission_tail_seconds':tail,'extra_time_allowed_for_98_percent_seconds':ideal*(1/.98-1),'source_schedule_timing_consistent_with_quota':abs(active_drift)<=max(.05,ideal*.002),'explanation':'read admission schedule matches quota within measured drift; startup and positive data/commit tail reduce end-to-end utilization' if abs(active_drift)<=max(.05,ideal*.002) else 'source admission span also has measurable backpressure/drift; retain raw trace, do not attribute exclusively to commit tail'})
  rows.append({'experiment':folder,'profile':profile,'case':case,'failed_gates':failed,'operations':d['operations'],'bytes':d['bytes'],'seconds':d['seconds'],'source_envelope_and_steady_gates_all_passed':all(g['passed'] for g in checks if g['profile']==profile and g['case']==case and not g['name'].startswith('end_to_end') and 'end_to_end' not in g['name']),'phases':phases,'diagnostic_only':True})
(B/'failure-analysis.json').write_text(json.dumps(rows,indent=2));print('Failure phase analysis',len(rows),'cases; original verdicts unchanged.')
