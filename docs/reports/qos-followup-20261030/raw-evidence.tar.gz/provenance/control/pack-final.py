from pathlib import Path
import json,tarfile,hashlib,io,importlib.util,paramiko
B=Path('/work/qos-followup-evidence');O=Path('docs/reports/qos-followup-20261030');O.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('qos_evidence','tests/lab/qos_evidence.py');Q=importlib.util.module_from_spec(spec);spec.loader.exec_module(Q)
x=json.load(open('.scratch/qos-followup/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();cfg=json.load(s.open(x['root']+'/endpoints.private.json'));secrets=Q.secret_values([{**p.get('env',{}),'ENDPOINT':p.get('endpoint','')} for p in [*cfg['sources'].values(),*cfg['destinations'].values()]]);s.close();c.close();secrets=sorted(set(secrets+[json.dumps(v)[1:-1] for v in secrets]),key=len,reverse=True)
additions=[]
for row in json.load(open(B/'source-manifest.json'))['files']:
 data=(B/'candidate-source-snapshot'/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];additions.append(('source-snapshot/'+row['path'],data))
for row in json.load(open(B/'retained-source-manifest.json'))['files']:
 data=(B/'retained-source-snapshot'/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'];additions.append(('retained-source-snapshot/'+row['path'],data))
for p in sorted(Path('.scratch/qos-followup').rglob('*')):
 if p.is_file() and '.private.' not in p.name and p.suffix in ['.py','.rs','.patch','.json']:additions.append(('provenance/control/'+str(p.relative_to('.scratch/qos-followup')),p.read_bytes()))
for pattern in ['qos-followup-*.log','qos-byte-buffer-*.log','qos-retained-*.log']:
 for p in sorted(Path('/work').glob(pattern)):additions.append(('validation-logs/'+p.name,p.read_bytes()))
for name in ['source-manifest.json','qos-followup.patch','full-working-tree.patch','remote-archive-audit.json','validation.json','evidence-audit.json','audit.log','patch-replay.json','failure-analysis.json','retained-source-manifest.json','retained-working-tree.patch','retained-validation.json','candidate-rejection.json','cached-sample-preservation.json']:additions.append(('provenance/'+name,(B/name).read_bytes()))
manifest=[]
with tarfile.open(O/'raw-evidence.tar.gz','w:gz') as dst:
 def put(name,data):
  assert not name.startswith('/') and '..' not in Path(name).parts
  assert not any(secret.encode() in data for secret in secrets),'Credential match in '+name
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;dst.addfile(item,io.BytesIO(data));manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 with tarfile.open(B/'remote-public-evidence.tar.gz') as src:
  for member in src.getmembers():assert member.isfile();put(member.name,src.extractfile(member).read())
 for name,data in additions:put(name,data)
assert len({m['path'] for m in manifest})==len(manifest)
with tarfile.open(O/'raw-evidence.tar.gz') as t:
 assert len(t.getmembers())==len(manifest)
 for item,m in zip(t.getmembers(),manifest):assert item.name==m['path'] and hashlib.sha256(t.extractfile(item).read()).hexdigest()==m['sha256']
audit={'credential_scan_passed':True,'scan_covers_env_credentials_and_endpoint_url_credentials':True,'files':len(manifest),'all_files_sha256':manifest,'archive_sha256':hashlib.sha256((O/'raw-evidence.tar.gz').read_bytes()).hexdigest(),'remote_manifest_preserved':'provenance/remote-archive-audit.json','large_fixtures_and_credentials_excluded':True};(O/'archive-audit.json').write_text(json.dumps(audit,indent=2));print('Final archive',len(manifest),'files,',(O/'raw-evidence.tar.gz').stat().st_size,'bytes; credential scan and every member SHA verified.')
