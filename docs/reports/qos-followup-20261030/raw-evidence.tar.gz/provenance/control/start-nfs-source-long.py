from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
with s.file(r+'/nfs-source-long.py','w') as f:f.write(Path('.scratch/qos-followup/nfs-source-long.py').read_text())
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 nfs-source-long.py >nfs-source-long.log 2>&1 </dev/null &');o.channel.recv_exit_status();print('Started diagnostic-only4GiB NFS reads:6 balanced A/A/high blocks, same source-probe and1MiB-4KiB requests; old failures unchanged; owned data cleanup in finally.');s.close();c.close()
