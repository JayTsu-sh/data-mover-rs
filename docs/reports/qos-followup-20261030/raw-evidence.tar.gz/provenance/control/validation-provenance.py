from pathlib import Path
import json,re,subprocess,hashlib
B=Path('/work/qos-followup-evidence');text=Path('/work/qos-byte-buffer-rust-tests.log').read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text);p=Path('/work/qos-byte-buffer-python.log').read_text();assert 'OK' in p
with Path('/work/qos-byte-buffer-architecture.log').open('w') as f:v=subprocess.run(['python3','tests/validate_architecture_dependencies.py','.'],stdout=f,stderr=subprocess.STDOUT)
assert v.returncode==0
out={'rust_passed':sum(int(r[0]) for r in rows),'rust_failed':sum(int(r[1]) for r in rows),'rust_ignored':sum(int(r[2]) for r in rows),'rust_suites':len(rows),'python_passed':int(re.search(r'Ran (\d+) tests',p).group(1)),'checks':Path('/work/qos-byte-buffer-validation.log').read_text().splitlines(),'architecture_exit_code':v.returncode,'architecture_passed':True,'candidate_binary_sha256':hashlib.sha256(Path('/work/cargo-target/release/examples/backend_qos_acceptance').read_bytes()).hexdigest()}
assert out['rust_failed']==0 and len(rows)==14 and out['checks']==['rust-tests 0','clippy 0','test-clippy 0','format 0'];assert out['candidate_binary_sha256']=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74';(B/'validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
