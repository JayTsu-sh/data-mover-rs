from pathlib import Path
import json,hashlib,subprocess,difflib,re,tempfile
B=Path('/work/qos-followup-evidence');M=json.load(open(B/'candidate-source-manifest.json'));rows=[];patch=[];root=B/'retained-source-snapshot';root.mkdir(exist_ok=True)
for row in M['files']:
 path=row['path'];p=Path(path)
 if not p.exists():assert path=='crates/transfer/src/transfer/s3_input_buffer_tests.rs';continue
 data=p.read_bytes();digest=hashlib.sha256(data).hexdigest()
 if path.endswith('.rs') or path in ['Cargo.toml','Cargo.lock','crates/storage-core/Cargo.toml','crates/backend-s3/Cargo.toml']:assert digest==row['baseline_9b_sha256'],path
 dst=root/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);rows.append({'path':path,'sha256':digest})
 v=subprocess.run(['git','show',M['git_commit']+':'+path],capture_output=True);before=v.stdout if v.returncode==0 else b''
 if before!=data:patch.append('diff --git a/'+path+' b/'+path+'\n'+('new file mode 100644\n' if not before else '')+''.join(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+path if before else '/dev/null',tofile='b/'+path)))
release=hashlib.sha256(Path('/work/cargo-target/release/examples/backend_qos_acceptance').read_bytes()).hexdigest();assert release==M['reference_9b_binary_sha256'];(B/'retained-working-tree.patch').write_text(''.join(patch))
# Independently replay retained tree from repository HEAD.
with tempfile.TemporaryDirectory(prefix='qos-retained-replay-',dir='/work') as tmp:
 for row in rows:
  path=row['path'];v=subprocess.run(['git','show',M['git_commit']+':'+path],capture_output=True)
  if v.returncode==0:p=Path(tmp)/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v.stdout)
 v=subprocess.run(['git','apply',str(B/'retained-working-tree.patch')],cwd=tmp,capture_output=True,text=True);assert v.returncode==0,v.stderr
 for row in rows:assert hashlib.sha256((Path(tmp)/row['path']).read_bytes()).hexdigest()==row['sha256']
manifest={'git_commit':M['git_commit'],'retained_binary_sha256':release,'rejected_candidate_binary_sha256':M['candidate_binary_sha256'],'production_Rust_and_Cargo_files_identical_to_accepted_9b':True,'head_patch_replay_all_source_sha256_verified':True,'accepted_changes_since_9b':'Python acceptance correctness and diagnostics plus lab README only; no new production Rust performance change','files':rows};(B/'retained-source-manifest.json').write_text(json.dumps(manifest,indent=2))
log=Path('/work/qos-retained-rust-tests.log').read_text();testrows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log);assert len(testrows)==14
with Path('/work/qos-retained-architecture.log').open('w') as f:v=subprocess.run(['python3','tests/validate_architecture_dependencies.py','.'],stdout=f,stderr=subprocess.STDOUT)
assert v.returncode==0;checks=Path('/work/qos-retained-validation.log').read_text().splitlines();assert checks==['rust-tests 0','clippy 0','test-clippy 0','format 0']
validation={'rust_passed':sum(int(r[0]) for r in testrows),'rust_failed':sum(int(r[1]) for r in testrows),'rust_ignored':sum(int(r[2]) for r in testrows),'rust_suites':len(testrows),'checks':checks,'architecture_exit_code':0,'release_sha256_matches_9b':True,'production_Rust_and_Cargo_unchanged_since_9b':True};assert validation['rust_failed']==0;(B/'retained-validation.json').write_text(json.dumps(validation,indent=2));print('Retained production release is exactly9b; all38 source snapshots replay from HEAD; retained tests',validation['rust_passed'],'passed.')
