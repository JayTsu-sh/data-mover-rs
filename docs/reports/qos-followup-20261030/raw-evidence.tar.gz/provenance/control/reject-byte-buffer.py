from pathlib import Path
import json,hashlib,subprocess,tarfile
B=Path('/work/qos-followup-evidence');M=json.load(open(B/'candidate-source-manifest.json'));rows=[]
with tarfile.open('docs/reports/qos-high-root-cause-20261030/raw-evidence.tar.gz') as tar:
 members={m.name:m for m in tar.getmembers()}
 for row in M['files']:
  path=row['path']
  if not path.endswith('.rs') or not row['changed_from_9b']:continue
  p=Path(path);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert (B/'candidate-source-snapshot'/path).read_bytes()==data;name='source-snapshot/'+path
  if name in members:before=tar.extractfile(members[name]).read()
  else:
   v=subprocess.run(['git','show',M['git_commit']+':'+path],capture_output=True);before=v.stdout if v.returncode==0 else None
  assert (hashlib.sha256(before).hexdigest() if before else None)==row['baseline_9b_sha256']
  if before is None:p.unlink()
  else:p.write_bytes(before)
  rows.append({'path':path,'restored_9b_sha256':row['baseline_9b_sha256']})
(B/'candidate-rejection.json').write_text(json.dumps({'candidate_sha256':M['candidate_binary_sha256'],'status':'rejected and all production Rust changes rolled back to9b; no new performance optimization accepted','reason':'original-target raw regression gates and Local fast-target raw regression gates below98%; preserve failures and uncertainty; user requires no regression','preserved_source_snapshot':'candidate-source-snapshot','restored_files':rows,'remaining_changes':'acceptance tooling correctness, paired controls, isolation/lifecycle and report only; existing HTTP pool fix retained'},indent=2));print('Rolled back',len(rows),'candidate Rust files after verifying all current and frozen hashes; existing QoS/HTTP pool fixes untouched.')
