from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact,compare_performance
from target_settle import settle_target
r=Path.cwd()
while not (r/'depth-sweep/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3');base_env={**os.environ,**cfg['sources']['cifs']['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'tuned-comparison';folder.mkdir();arms=['default-baseline','default-high','tuned-baseline','tuned-control','tuned-high'];rng=random.Random(202610310);order=[]
for _ in range(2):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(5)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':10,'size_mib':512,'order':order,'seed':202610310,'minimum_ratio':.98,'idle_ms':1000,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'only_runtime_configuration_change':{'default':{'DATA_MOVER_S3_WRITE_INFLIGHT':'4'},'tuned':{'DATA_MOVER_S3_WRITE_INFLIGHT':'8'}},'part_bytes':8388608,'parts_per_copy':64,'scope':'same original disk target and unchanged production binary; fresh destinations and deferred cleanup for every arm; no shared service change'},indent=2));values={a:[] for a in arms};targets=[]
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/tuned-comparison/'+label,'DATA_MOVER_S3_WRITE_INFLIGHT':'8' if arm.startswith('tuned-') else '4'};targets.append((label,env))
  cmd=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'tuned comparison failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=int(env['DATA_MOVER_S3_WRITE_INFLIGHT']);d['destination_sample']=label;(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};ratios={'default_high_to_default_baseline':med['default-high']/med['default-baseline'],'tuned_high_to_tuned_baseline':med['tuned-high']/med['tuned-baseline'],'tuned_high_to_default_high':med['tuned-high']/med['default-high'],'tuned_baseline_to_default_baseline':med['tuned-baseline']/med['default-baseline']};d={'medians':med,'checks':[{'name':k,'ratio':v,'passed':v>=.98} for k,v in ratios.items()],'tuned_aa_control':compare_performance(values['tuned-baseline'],values['tuned-high'],values['tuned-control']),'samples':50};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True)
cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':50,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
'''
with s.file(r+'/tuned-comparison.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 tuned-comparison.py >tuned-comparison.log 2>&1 </dev/null &');print('50-copy predeclared 10-block comparison started: default4 baseline/high versus tuned8 baseline/control/high, same original 512MiB/disk, balanced arm positions, all outcomes retained');s.close();c.close()
