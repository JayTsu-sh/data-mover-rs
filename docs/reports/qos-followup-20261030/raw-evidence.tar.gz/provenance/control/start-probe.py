from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('/work/qos-followup-probe',r+'/probe-bin');s.chmod(r+'/probe-bin',0o700)
script='''from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib,re
from qos_evidence import secret_values,redact
from target_settle import settle_target
r=Path.cwd()
while not (r/'source-only/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));env={**os.environ,**cfg['sources']['cifs']['env'],'QOS_DESTINATION':cfg['destinations']['s3']['endpoint'].replace('{pair}','cifs-to-s3'),'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'pipeline-probe';folder.mkdir();order=[['baseline','high'],['high','baseline']];(folder/'plan.json').write_text(json.dumps({'pairs':2,'order':order,'size_mib':512,'binary_sha256':hashlib.sha256((r/'probe-bin').read_bytes()).hexdigest(),'scope':'diagnostic only; actual CIFS inflight/admission/read waits and S3 per-part RPC timings'},indent=2));rows=[]
for i,pair in enumerate(order):
 for arm in pair:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label)
  cmd=[str(r/'probe-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination/cifs-to-s3'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'pipeline probe failed';d=json.loads(v.stdout);d['command']=cmd;(folder/(label+'.json')).write_text(json.dumps(d));rows.append({'label':label,'mibps':d['mibps'],'probes':[l for l in v.stderr.splitlines() if '[FOLLOWUP-PROBE]' in l]});print(label,d['mibps'],rows[-1]['probes'][-2:],flush=True)
(folder/'summary.json').write_text(json.dumps(rows,indent=2));(folder/'complete.json').write_text(json.dumps({'diagnostic_only':True,'samples':4}))
'''
with s.file(r+'/pipeline-probe.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 pipeline-probe.py >pipeline-probe.log 2>&1 </dev/null &');print('Four diagnostic copies queued after source-only; target part timings and actual CIFS concurrency recorded, no production source change');s.close();c.close()
