from pathlib import Path
import hashlib,subprocess,shutil,json
p=Path('crates/backend-s3/src/backend/client/qos_client.rs');original=p.read_bytes();written=None
try:
 s=original.decode().replace('        _: &BeforeTransmitInterceptorContextRef', '        context: &BeforeTransmitInterceptorContextRef')
 a='''        Ok(())
    }
}
''';assert s.count(a)==1;s=s.replace(a,'''        let uri = context.request().uri();
        if let Some(number) = uri.split('?').nth(1).and_then(|q| q.split('&').find_map(|v| v.strip_prefix("partNumber="))).and_then(|v| v.parse::<u32>().ok()) {
            eprintln!("[FOLLOWUP-ATTEMPT] send_part={} method={}",number,context.request().method());
        }
        Ok(())
    }

    fn read_after_attempt(
        &self,
        context: &aws_smithy_runtime_api::client::interceptors::context::FinalizerInterceptorContextRef<'_>,
        _: &RuntimeComponents,
        _: &mut ConfigBag,
    ) -> Result<(), BoxError> {
        let status = context.response().map_or(0, |r| r.status().as_u16());
        eprintln!("[FOLLOWUP-ATTEMPT] status={}",status);
        Ok(())
    }
}
''');p.write_text(s);written=hashlib.sha256(p.read_bytes()).hexdigest()
 with open('/work/qos-followup-attempt-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-followup-attempt-probe')
finally:
 if written is not None:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==written;p.write_bytes(original)
print('Attempt-count diagnostic built; production capture interceptor restored exactly')
with open('/work/qos-followup-normal-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance','--example','backend_qos_cleanup'],stdout=f,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(Path('/work/cargo-target/release/examples/backend_qos_acceptance').read_bytes()).hexdigest()=='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd'
print('Normal acceptance binary restored to exact accepted 9b56c318 hash')
