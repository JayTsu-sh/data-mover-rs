from pathlib import Path
import json,paramiko,shlex,collections
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();refs=json.load(open('/work/qos-high-evidence/raw/fixed-limits-reference.json'));latest=collections.defaultdict(list)
for g in json.load(open('/work/qos-high-evidence/raw/fixed-limits/checks.json')):latest[g['profile'],g['case']].append({'name':g['name'],'passed':g['passed']})
for ref in refs:ref['historical_old_checks']=ref['old_checks'];ref['old_checks']=latest[ref['profile'],ref['case']];ref['reference_binary_sha256']='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd'
# Additional real cross-instance S3 source, preserving 8MiB GETs.
root_old='/tmp/nightly-qos-cross-20261029192047'
for case in ['bandwidth-strict','bandwidth-dual','iops-strict','iops-dual','combined']:
 cmd=[root_old+'/qos-bin','--source',root_old+'/fixtures','--destination',root_old+'/destination/s3-to-s3','--path','128.bin','--chunk-bytes','8388608','--copy','--transfer-profile','cross','--destination-cleanup','delete'];dual=case.endswith('dual') or case=='combined'
 if case.startswith('bandwidth') or case=='combined':cmd+=['--soft-bytes','8388608','--hard-bytes',str(8388608*(2 if dual else 1))]
 if case.startswith('iops') or case=='combined':cmd+=['--soft-iops','1','--hard-iops',str(2 if dual else 1)]
 cmd+=['--peak-ms','2000','--idle-ms','2100' if dual else '0'];refs.append({'profile':'s3-to-s3','case':case,'command':cmd,'old_checks':[],'scope':'new cross-instance coverage; no historical verdict'})
with s.file(r+'/pipeline-fixed-limits-reference.json','w') as f:f.write(json.dumps(refs,indent=2))
script=s.open(r+'/tuned-limits.py').read().decode().replace("r/'other-routes/complete.json'","r/'pipeline-other-routes/complete.json'").replace("r/'tuned-limits'","r/'pipeline-limits'").replace("+'/tuned-limits/'","+'/pipeline-limits/'").replace("open('fixed-limits-reference.json')","open('pipeline-fixed-limits-reference.json')").replace('assert len(refs)==20','assert len(refs)==25').replace("'cases':20,'write_inflight':8","'cases':25,'write_inflight':4").replace("'reference':'fixed-limits-reference.json'","'reference':'pipeline-fixed-limits-reference.json'").replace("'DATA_MOVER_S3_WRITE_INFLIGHT':'8'","'DATA_MOVER_S3_WRITE_INFLIGHT':'4'").replace("str(r/'qos-bin')","str(r/'pipeline-bin')").replace("d['s3_write_inflight']=8","d['s3_write_inflight']=4").replace("'samples':20","'samples':25")
a="matrix={p['name']:p for p in profiles(cfg)};";assert a in script;script=script.replace(a,a+"matrix['s3-to-s3']={'name':'s3-to-s3','source_kind':'s3','destination_kind':'s3','env':{**cfg['sources']['s3']['env'],'QOS_DESTINATION':cfg['destinations']['s3']['endpoint'].replace('{pair}','s3-to-s3')},'chunk_bytes':8388608};")
script=script.replace("  for old in ref['old_checks']:","  if name=='s3-to-s3' and (case.startswith('bandwidth') or case=='combined'):gates['s3_payload_requests_no_inflation']=d['operations']==16\n  for old in ref['old_checks'] or [{'name':key,'passed':None} for key in gates]:")
script=script.replace("'new_failure':old['passed'] and not new","'new_failure':old['passed'] is True and not new")
with s.file(r+'/pipeline-limits.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 pipeline-limits.py >pipeline-limits.log 2>&1 </dev/null &');print('25 pipeline-fix quota cases queued: original four routes bound to latest9b fixed-quota verdicts; five new S3 cross-instance cases preserve8MiB GETs; no limit relaxation');s.close();c.close()
