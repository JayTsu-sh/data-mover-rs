from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();t=s.open(r+'/nfs-source-long.py').read().decode()
with s.file(r+'/nfs-source-long.before-destination-setup.py','w') as f:f.write(t)
t=t.replace("folder.mkdir();cfg=","folder.mkdir(exist_ok=True);cfg=").replace("golden.mkdir(parents=True);source_root=","golden.mkdir(parents=True);destination.mkdir(parents=True);source_root=")
t=t.replace("(r/'cleanup.before-nfs-source-long.json').write_bytes(initial)","(r/'cleanup.before-nfs-source-long-retry.json').write_bytes(initial)")
t=t.replace("'original_cleanup_preserved':'cleanup.before-nfs-source-long.json'","'original_cleanup_preserved':'cleanup.before-nfs-source-long-retry.json'")
Path('.scratch/qos-followup/nfs-source-long.retry.py').write_text(t)
with s.file(r+'/nfs-source-long.py','w') as f:f.write(t)
script='''from pathlib import Path
import json,subprocess
r=Path.cwd();folder=r/'nfs-source-long';assert not [p for p in folder.glob('*.json') if isinstance(json.load(open(p)),dict) and 'mibps' in json.load(open(p))];p=folder/'control-0.stderr';assert 'kind: Local' in p.read_text() and 'No such file' in p.read_text();p.rename(folder/'control-0.destination-setup-error.stderr');(folder/'cleanup.json').rename(folder/'cleanup.preparation-failure.json');(folder/'preparation-error.json').write_text(json.dumps({'stage':'unused Local destination connect, before measured source reads','error':'scratch direct caller did not create Local root directory; source-probe connects it even for source-only mode','measured_payload_samples':0,'fix':'create empty owned Local destination before invoking CLI; same plan, data, quotas, source code and full read concurrency','original_error_log':'control-0.destination-setup-error.stderr','source4GiB_fixture_was_cleaned_before_retry':True},indent=2));subprocess.Popen(['python3','nfs-source-long.py'],stdout=(r/'nfs-source-long.log').open('a'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True);print('Retried original4GiB plan after creating unused Local root; zero discarded source-read samples; first setup failure and cleanup retained.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(script));print(o.read().decode());assert o.channel.recv_exit_status()==0;s.close();c.close()
