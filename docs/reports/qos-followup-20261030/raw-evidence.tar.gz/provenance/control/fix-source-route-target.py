from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
stop='''from pathlib import Path
import os,signal
r=Path.cwd();names=['buffer-source-routes','buffer-source-limits'];stopped=[]
for name in names:
 assert not (r/name).exists(),'measurement already started'
 matches=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   argv=(p/'cmdline').read_bytes().split(bytes([0]))
   if (name+'.py').encode() in argv and (p/'cwd').resolve()==r:matches.append(int(p.name))
  except (OSError,RuntimeError):pass
 assert len(matches)==1,(name,matches)
 os.kill(matches[0],signal.SIGTERM);stopped.append(name)
print('Restarted only two queued, unstarted source-route drivers to support explicit Local destinations.')
'''
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && python3 -c '+shlex.quote(stop));out=o.read().decode();assert o.channel.recv_exit_status()==0;print(out.strip())
for name in ['buffer-source-routes','buffer-source-limits']:
 p=Path('.scratch/qos-followup/'+name+'.py');t=p.read_text();a="p=matrix[name];env=";assert a in t;t=t.replace(a,"p=matrix[name];p['env'].setdefault('QOS_DESTINATION',cfg['destinations']['local']['endpoint'].replace('{pair}',name));env=");p.write_text(t)
 with s.file(r+'/'+name+'.py','w') as f:f.write(t)
 _,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 '+name+'.py >'+name+'.log 2>&1 </dev/null &');o.channel.recv_exit_status()
s.close();c.close()
