from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();cfg=json.load(s.open(r+'/memory-profile.private.json'));p=cfg['profiles'][0];p['name']='cifs-to-s3-buffer-memory';p['env']['QOS_DESTINATION']=p['env']['QOS_DESTINATION'].replace('cifs-to-s3-memory','cifs-to-s3-buffer-memory');p['env']['DATA_MOVER_S3_WRITE_INFLIGHT']='4'
with s.file(r+'/buffer-harness-profile.private.json','w') as f:f.write(json.dumps(cfg))
s.chmod(r+'/buffer-harness-profile.private.json',0o600)
script='''from pathlib import Path
import json,time,subprocess,hashlib
r=Path.cwd()
while not (r/'buffer-source-limits/complete.json').exists():time.sleep(1)
folder=r/'buffer-harness';folder.mkdir();command=['python3',str(r/'final-harness/run-backend-qos.py'),'--config',str(r/'buffer-harness-profile.private.json'),'--root',str(r),'--binary',str(r/'buffer-bin'),'--phase','survey','--repeats','3','--performance-control','--isolated-destinations','--cleanup-binary',str(r/'qos-cleanup'),'--reuse-fixtures','--retain-source','--performance-idle-ms','1000','--output',str(folder/'survey')];(folder/'plan.json').write_text(json.dumps({'command':command,'binary_sha256':hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest(),'scope':'current binary all four scenarios on isolated RAM S3; diagnostic environment, original disk results separately retained','default_write_cap':4,'performance_size_mib':512,'finite_size_mib':128,'soft_mibps':8},indent=2))
statuses=[]
for phase in ['survey','final']:
 command[command.index('--phase')+1]=phase;command[command.index('--output')+1]=str(folder/phase)
 if phase=='final':command+=['--baseline',str(folder/'survey')]
 with (folder/(phase+'.log')).open('w') as log:v=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 statuses.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'phase_exit_codes':statuses,'survey_checks':json.load(open(folder/'survey/checks.json')),'final_checks':json.load(open(folder/'final/checks.json'))},indent=2));print('Candidate public-harness phases',statuses,flush=True)
'''
Path('.scratch/qos-followup/buffer-harness.py').write_text(script)
with s.file(r+'/buffer-harness.py','w') as f:f.write(script)
# Extend cleanup preconditions before any finish marker can be written.
t=s.open(r+'/cleanup.py').read().decode().replace("'buffer-source-limits']:assert","'buffer-source-limits','buffer-harness']:assert")
with s.file(r+'/cleanup.py','w') as f:f.write(t)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 buffer-harness.py >buffer-harness.log 2>&1 </dev/null &');o.channel.recv_exit_status();print('Queued latest public runner with candidate binary: 3 balanced A/A/high blocks plus 5 finite cases at unchanged8MiB/s, defaultwrite4.');s.close();c.close()
