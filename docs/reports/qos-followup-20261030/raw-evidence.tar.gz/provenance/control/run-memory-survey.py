from pathlib import Path
import json,paramiko,shlex
x=json.load(open('.scratch/qos-followup/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
for name in ['run-backend-qos.py','run-local-qos.py','qos_evidence.py']:s.put('tests/lab/'+name,r+'/'+name)
s.put('/work/cargo-target/release/examples/backend_qos_cleanup',r+'/qos-cleanup');s.chmod(r+'/qos-cleanup',0o700)
cfg=json.load(s.open(r+'/endpoints.private.json'));p={'run_id':x['run_id'],'profiles':[{'name':'cifs-to-s3-memory','source_kind':'cifs','destination_kind':'s3','env':{**cfg['sources']['cifs']['env'],'QOS_DESTINATION':cfg['destinations']['s3-memory']['endpoint'].replace('{pair}','cifs-to-s3-memory')},'transfer_profile':'cross','size_mib':128,'performance_size_mib':512,'chunk_bytes':2097152,'soft_mibps':8}]}
with s.file(r+'/memory-profile.private.json','w') as f:f.write(json.dumps(p))
s.chmod(r+'/memory-profile.private.json',0o600)
script='''from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();command=['python3','run-backend-qos.py','--config','memory-profile.private.json','--root',str(r),'--binary',str(r/'qos-bin'),'--phase','survey','--repeats','3','--performance-control','--isolated-destinations','--cleanup-binary',str(r/'qos-cleanup'),'--reuse-fixtures','--retain-source','--performance-idle-ms','1000','--output',str(r/'memory-survey')];(r/'memory-survey-plan.json').write_text(json.dumps({'command':command,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'scope':'diagnostic tmpfs target; same RustFS executable, no shared server modifications; original disk failures retained','sample_count':9,'size_mib':512},indent=2))
with (r/'memory-survey.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(r/'memory-survey-status.json').write_text(json.dumps({'exit':result.returncode}));print('memory survey exit',result.returncode,flush=True)
'''
with s.file(r+'/memory-survey.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+shlex.quote(r)+' && nohup python3 memory-survey.py >memory-survey-driver.log 2>&1 </dev/null &');print('Actual updated acceptance runner started: original 512MiB, 3 balanced baseline/control/high blocks, isolated RAM-backed RustFS target, deferred tree cleanup');s.close();c.close()
