from urllib.parse import urlsplit,urlunsplit
def phase_endpoint(endpoint,phase,label):
 p=urlsplit(endpoint);return urlunsplit(p._replace(path=p.path.rstrip('/')+'/'+phase+'/'+label))
from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib
from qos_evidence import secret_values,redact
from cross_qos_matrix import profiles
from target_settle import settle_target
r=Path.cwd()
assert hashlib.sha256((r/'buffer-bin').read_bytes()).hexdigest()=='0070c0b704ae2c22fd1af5635c76d878f45c8ca9e6963e47ef6087dbcb792a74'
while not (r/'buffer-local-memory/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));folder=r/'buffer-source-routes';folder.mkdir(exist_ok=True);matrix={p['name']:p for p in profiles(cfg)};matrix['s3-to-s3']={'name':'s3-to-s3','source_kind':'s3','destination_kind':'s3','env':{**cfg['sources']['s3']['env'],'QOS_DESTINATION':cfg['destinations']['s3']['endpoint'].replace('{pair}','s3-to-s3')},'chunk_bytes':8388608};targets=[];summaries={};rng=random.Random(202610324);arms=['old-baseline','old-high','fixed-baseline','fixed-high'];plans={}
for name,size in [('s3-to-hdfs',512),('s3-to-local',128),('s3-to-cifs',128),('s3-to-nfs41',128)]:
 base=arms.copy();rng.shuffle(base);order=[base[i:]+base[:i] for i in range(4)];rng.shuffle(order);plans[name]={'size_mib':size,'order':order}
saved_plan=json.load(open(folder/'plan.json'));assert saved_plan['routes']==plans;assert saved_plan['seed']==202610324

for name,plan in plans.items():
 p=matrix[name];p['env'].setdefault('QOS_DESTINATION',cfg['destinations']['local']['endpoint'].replace('{pair}',name));env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);size=plan['size_mib'];route=folder/name;route.mkdir(exist_ok=True);seed=[str(r/'qos-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path',f'{size}.bin','--chunk-bytes',str(p['chunk_bytes']),'--seed'];v=subprocess.run(seed,env=env,capture_output=True,text=True,timeout=180);(route/'seed.stderr').write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route source preparation failed';(route/'seed.json').write_text(redact(v.stdout,secrets));values={a:[] for a in arms}
 for i,block in enumerate(plan['order']):
  for arm in block:
   label=f'{arm}-{i}';candidate=arm.startswith('fixed-');sample_env={**env,'QOS_DESTINATION':phase_endpoint(p['env']['QOS_DESTINATION'],'buffer-source-routes',label),'DATA_MOVER_S3_WRITE_INFLIGHT':'4'};targets.append((name,label,sample_env));cmd=[str(r/('buffer-bin' if candidate else 'qos-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path',f'{size}.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile',p.get('transfer_profile','cross'),'--destination-cleanup','keep','--idle-ms','1000']
   if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
   cached=route/(label+'.json')
   if cached.exists():
    d=json.load(open(cached));assert d['command']==cmd;values[arm].append(d['mibps']);continue
   settle_target(route/'readiness.jsonl',label)
   prior=route/(label+'.stderr')
   if prior.exists() and prior.stat().st_size:prior.rename(route/(label+'.mount-error.stderr'))
   v=subprocess.run(cmd,env=sample_env,capture_output=True,text=True,timeout=180);(route/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'other-route timed copy failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;d['destination_sample']=name+'-'+label;(route/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(name,label,d['mibps'],flush=True)
 med={a:statistics.median(v) for a,v in values.items()};ratios={'old_high_to_old_baseline':med['old-high']/med['old-baseline'],'fixed_high_to_fixed_baseline':med['fixed-high']/med['fixed-baseline'],'fixed_high_to_old_high':med['fixed-high']/med['old-high'],'fixed_baseline_to_old_baseline':med['fixed-baseline']/med['old-baseline']};summaries[name]={'medians':med,'checks':[{'name':k,'ratio':v,'passed':v>=.98} for k,v in ratios.items()]};(route/'summary.json').write_text(json.dumps(summaries[name],indent=2));(folder/'summary.json').write_text(json.dumps(summaries,indent=2));print(name,summaries[name],flush=True)
cleanup=[]
for name,label,env in targets:
 secrets=secret_values([env]);v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/name/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':64,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
