from pathlib import Path
import json,os,subprocess,time,random,statistics,hashlib,resource
from qos_evidence import secret_values,redact,compare_performance
from target_settle import settle_target
r=Path.cwd()
while not (r/'pipeline-memory/complete.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));target=cfg['destinations']['s3']['endpoint'].replace('{pair}','local-to-s3');base_env={**os.environ,**cfg['sources']['local']['env'],'NO_PROXY':'*','no_proxy':'*','DATA_MOVER_S3_WRITE_INFLIGHT':'4'};secrets=secret_values([{**base_env,'QOS_DESTINATION':target}]);folder=r/'local-absolute';folder.mkdir();arms=['old-high-a','old-high-b','fixed-high'];rng=random.Random(202610315);order=[]
for _ in range(4):
 base=arms.copy();rng.shuffle(base);cycle=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle);order.extend(cycle)
(folder/'plan.json').write_text(json.dumps({'blocks':12,'order':order,'seed':202610315,'size_mib':512,'scope':'direct absolute high-QoS regression confirmation with identical old/old AA control; initial 96.268% result retained','binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','pipeline-bin']}},indent=2));values={a:[] for a in arms};targets=[]
for i,block in enumerate(order):
 for arm in block:
  label=f'{arm}-{i}';settle_target(folder/'readiness.jsonl',label);env={**base_env,'QOS_DESTINATION':target+'/local-absolute/'+label};targets.append((label,env));cmd=[str(r/('pipeline-bin' if arm=='fixed-high' else 'qos-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'),'--path','512.bin','--chunk-bytes','2097152','--copy','--transfer-profile','cross','--destination-cleanup','keep','--idle-ms','1000','--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled'];before=resource.getrusage(resource.RUSAGE_CHILDREN);v=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);after=resource.getrusage(resource.RUSAGE_CHILDREN);(folder/(label+'.stderr')).write_text(redact(v.stderr,secrets));assert v.returncode==0,'absolute Local regression execution failed';d=json.loads(v.stdout);d['command']=cmd;d['s3_write_inflight']=4;d['process_cpu_seconds']=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime);(folder/(label+'.json')).write_text(json.dumps(d));values[arm].append(d['mibps']);print(label,d['mibps'],d['process_cpu_seconds'],flush=True)
med={a:statistics.median(v) for a,v in values.items()};comparison=compare_performance(values['old-high-a'],values['fixed-high'],values['old-high-b']);d={'medians':med,'fixed_to_old_a':med['fixed-high']/med['old-high-a'],'fixed_to_old_b':med['fixed-high']/med['old-high-b'],'comparison':comparison,'blocks':12};(folder/'summary.json').write_text(json.dumps(d,indent=2));print(d,flush=True);cleanup=[]
for label,env in targets:
 v=subprocess.run([str(r/'qos-cleanup'),'--run-id',cfg['run_id'],'--tree'],env={**env,'QOS_SOURCE':env['QOS_DESTINATION']},capture_output=True,text=True,timeout=120);(folder/(label+'.cleanup.stderr')).write_text(redact(v.stderr,secrets));cleanup.append(v.returncode)
(folder/'complete.json').write_text(json.dumps({'samples':36,'cleanup_exit_codes':cleanup}));assert not any(cleanup)
