//! The S3 destination (ADR-0006): every stage writes the final key. Up to the single-PUT
//! threshold an object is one `PutObject` (a native copy up to 64 MiB one `CopyObject`); a larger
//! one is a multipart upload on the final key, resumable through the `.upload` pointer beside it;
//! a `Direct` write completes inside `write`. On a bucket without multipart uploads (an ONTAP NAS
//! bucket, P7 §14.2) an object over the threshold is one streamed `PutObject` holding its last
//! byte until publication ([`streaming`]). A directory object (`p/d/`, P7 F5) is always one
//! request, up to 5 GiB, never resumed ([`directory_object`], P7 D13). Nothing is recorded where
//! data-mover runs, and no temp key is written (the `.data-mover-stage/` temp-key path was removed
//! in C19).

use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use bytes::Bytes;

use crate::model::{BackendIdentity, FailureClass, Operation, StoragePath, Transience};
use crate::storage::{
    ByteStream, CheckpointObservation, DestinationPrepareRequest, Metadata, MetadataMutation,
    PositionedByteStream, PrepareRequest, PreparedStage, PublicationEvidence, PublicationFailure,
    PublishRequest, ReadBackMethod, StagedDestination, StorageRoleFailure, UnpinnedReadReason,
    UploadDigest, UploadDigestGap, VerificationEvidence, VerificationPoint, VerifyRequest,
    WriteEvidence,
};

use super::source::{classified_entry, entry, role_failure};

mod at_destination;
mod checkpoint_cleanup;
mod checkpoint_record;
mod checkpointed_parts;
mod completion;
mod delete_marker;
mod direct;
mod directory_object;
#[cfg(test)]
mod directory_object_tests;
mod final_upload;
mod hash_checkpoint;
#[cfg(test)]
mod hash_checkpoint_tests;
mod limits;
#[cfg(test)]
mod nas_tests;
mod native;
mod native_final;
#[cfg(test)]
mod native_final_tests;
mod parts;
mod published_recovery;
mod settle;
mod single;
mod single_prepare;
#[cfg(test)]
mod single_tests;
#[cfg(test)]
mod sizing_tests;
mod streaming;
mod upload_discovery;
mod upload_pointer;
use super::{S3Protocol, S3ProtocolFailure};
use native_final::NativeSizing;
pub use single::single_put_threshold;
#[cfg(any(test, feature = "test-support"))]
pub use single::{
    DEFAULT_SINGLE_PUT_THRESHOLD, MAX_SINGLE_PUT_THRESHOLD, MIN_SINGLE_PUT_THRESHOLD,
};

const PART_SIZE: usize = 8 * 1024 * 1024;
const MIN_MULTIPART_PART_SIZE: u64 = 5 * 1024 * 1024;

fn planned_part_size(size: Option<u64>, path: &StoragePath) -> Result<usize, StorageRoleFailure> {
    part_size_at_least(size, PART_SIZE as u64, path)
}

/// The part size for `size` bytes in at most 10 000 parts, and at least `minimum`; parts over
/// 5 GiB are refused.
fn part_size_at_least(
    size: Option<u64>,
    minimum: u64,
    path: &StoragePath,
) -> Result<usize, StorageRoleFailure> {
    let size = size.unwrap_or(0);
    let part = size.div_ceil(10_000).max(minimum);
    if part > 5 * 1024 * 1024 * 1024 {
        return Err(entry(
            path,
            Operation::Prepare,
            "S3 multipart capacity exceeded",
        ));
    }
    usize::try_from(part)
        .map_err(|_| entry(path, Operation::Prepare, "S3 part cannot fit address space"))
}

pub struct S3StagedDestination<P> {
    protocol: Arc<P>,
    identity: BackendIdentity,
    metadata: Option<Arc<dyn Metadata>>,
    /// Sources of at most this many bytes go as one `PutObject` (ADR-0006 C14b); `None` sends
    /// every object through a multipart upload.
    single_put_threshold: Option<u64>,
    tags_supported: bool,
    /// The automatic checkpoint interval: where a checkpointed upload writes its pointer.
    checkpoint_interval: u64,
    /// How a native copy to the final key is split (ADR-0006 C18).
    native: NativeSizing,
    /// How long a streamed `PutObject` holds its last byte for publication.
    hold_limit: Duration,
    /// How long settling a lost reply waits before trusting that the final key is unchanged.
    settle_grace: Duration,
}

impl<P> S3StagedDestination<P> {
    pub fn new(protocol: Arc<P>, identity: BackendIdentity) -> Self {
        Self {
            protocol,
            identity,
            metadata: None,
            single_put_threshold: Some(single::DEFAULT_SINGLE_PUT_THRESHOLD),
            tags_supported: true,
            // Named in full: the architecture guard refuses imports between backend modules.
            checkpoint_interval: crate::storage::backends::DEFAULT_CHECKPOINT_INTERVAL_BYTES,
            native: NativeSizing::default(),
            hold_limit: streaming::HOLD_LIMIT,
            settle_grace: settle::SETTLE_GRACE,
        }
    }

    /// A shorter hold limit for the last byte of a streamed `PutObject`, and settling grace, for
    /// tests.
    #[cfg(any(test, feature = "test-support"))]
    pub const fn with_hold_limit(mut self, limit: Duration, grace: Duration) -> Self {
        self.hold_limit = limit;
        self.settle_grace = grace;
        self
    }

    /// Smaller native copy sizes, so engine tests need not copy 64 MiB objects.
    #[cfg(any(test, feature = "test-support"))]
    pub fn with_native_sizing(mut self, single_max: u64, part_size: u64) -> Self {
        self.native = NativeSizing {
            single_max,
            part_size,
        };
        self
    }

    /// A shorter automatic checkpoint interval, so engine tests need not move 64 MiB.
    #[cfg(any(test, feature = "test-support"))]
    pub fn with_checkpoint_interval(mut self, interval: u64) -> Self {
        self.checkpoint_interval = interval;
        self
    }

    /// Sends sources of at most `threshold` bytes as one `PutObject`; `None` sends every object
    /// through a multipart upload. A configured value is validated by `single_put_threshold`.
    pub fn with_single_put_threshold(mut self, threshold: Option<u64>) -> Self {
        self.single_put_threshold = threshold;
        self
    }

    pub fn with_tag_support(mut self, supported: bool) -> Self {
        self.tags_supported = supported;
        self
    }

    pub fn with_metadata(mut self, metadata: Arc<dyn Metadata>) -> Self {
        self.metadata = Some(metadata);
        self
    }

    fn key(stage: &PreparedStage) -> Result<String, StorageRoleFailure> {
        let (key, _) = Self::decode_token(stage.token()).map_err(|()| {
            entry(
                stage.final_destination().path(),
                Operation::Prepare,
                "invalid S3 stage identity",
            )
        })?;
        Ok(key)
    }

    fn encode_token(key: &str, upload_id: &str) -> Bytes {
        let mut token = Vec::with_capacity(key.len() + upload_id.len() + 1);
        token.extend_from_slice(key.as_bytes());
        token.push(0);
        token.extend_from_slice(upload_id.as_bytes());
        Bytes::from(token)
    }

    fn decode_token(token: &Bytes) -> Result<(String, String), ()> {
        let split = token.iter().position(|byte| *byte == 0).ok_or(())?;
        let key = String::from_utf8(token[..split].to_vec()).map_err(|_| ())?;
        let upload_id = String::from_utf8(token[split + 1..].to_vec()).map_err(|_| ())?;
        if key.is_empty() || upload_id.is_empty() {
            return Err(());
        }
        Ok((key, upload_id))
    }

    fn validate(&self, stage: &PreparedStage) -> Result<String, StorageRoleFailure> {
        stage.validate_owner(&self.identity).map_err(|_| {
            entry(
                stage.final_destination().path(),
                Operation::Prepare,
                "S3 stage belongs to another backend",
            )
        })?;
        Self::key(stage)
    }
}

fn cleanup_result(
    path: &StoragePath,
    result: super::S3Result<()>,
) -> Result<(), StorageRoleFailure> {
    match result {
        Ok(())
        | Err(S3ProtocolFailure::Entry {
            class: FailureClass::NotFound,
            ..
        }) => Ok(()),
        Err(failure) => Err(role_failure(path, Operation::Namespace, failure)),
    }
}

#[async_trait]
impl<P: S3Protocol + 'static> StagedDestination for S3StagedDestination<P> {
    /// Objects store tags when the bucket supports them. File timestamps, owner, mode, ACL and
    /// extended attributes are unavailable and reported as skipped.
    fn copied_metadata_target(&self) -> Option<crate::storage::CopiedMetadataTarget> {
        Some(crate::storage::CopiedMetadataTarget {
            timestamps: crate::storage::CopiedTimestampTarget::NotStored,
            ownership: crate::storage::CopiedOwnershipTarget::Unsupported,
            acl: crate::storage::CopiedAclTarget::Unsupported,
            xattrs: crate::storage::CopiedValueTarget::Unsupported,
            tags: if self.tags_supported {
                crate::storage::CopiedValueTarget::Supported
            } else {
                crate::storage::CopiedValueTarget::Unsupported
            },
        })
    }

    /// `Direct` writes the object at its final key (ADR-0006 C14c).
    fn supports_direct(&self) -> bool {
        true
    }

    /// The 64 MiB interval (D3: a checkpointed object up to it never writes a pointer); none on a
    /// bucket that keeps no progress.
    fn automatic_checkpoint_interval_bytes(&self) -> Option<u64> {
        self.protocol
            .bucket_capabilities()
            .resumable
            .then_some(self.checkpoint_interval)
    }

    /// `false` on a bucket without multipart uploads (an ONTAP NAS bucket, P7 §14.2).
    fn resumable_at_destination(&self) -> bool {
        self.protocol.bucket_capabilities().resumable
    }

    fn supports_hash_checkpoint(&self) -> bool {
        self.protocol.bucket_capabilities().resumable
    }

    fn stage_supports_hash_checkpoint(&self, stage: &PreparedStage) -> bool {
        self.supports_hash_checkpoint() && !stage.direct() && at_destination::of(stage).is_some()
    }

    fn requires_hash_intent(&self) -> bool {
        true
    }

    async fn persist_hash_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<(), StorageRoleFailure> {
        self.validate(stage)?;
        let upload = at_destination::of(stage)
            .filter(|_| stage.checkpoint_enabled() && !stage.direct())
            .ok_or_else(|| {
                classified_entry(
                    stage.final_destination().path(),
                    Operation::Write,
                    FailureClass::Unsupported,
                    Transience::Permanent,
                    "S3 hash checkpoints require a recoverable multipart stage",
                )
            })?;
        // H-only persistence must never promote acknowledged payload into D.
        self.write_pointer(stage, upload, false).await
    }

    /// Armed v2 roots return cleanup failures, including Object Lock that leaves the root
    /// discoverable. Legacy stages never enter this release path and retain warning-only cleanup.
    async fn release_hash_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<(), StorageRoleFailure> {
        self.validate(stage)?;
        if !stage.checkpoint_enabled() {
            return Ok(());
        }
        let upload =
            at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Namespace))?;
        self.release_upload_checkpoint(stage, upload).await
    }

    async fn write_checkpointed(
        &self,
        stage: &PreparedStage,
        input: PositionedByteStream,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        self.validate(stage)?;
        let upload = at_destination::of(stage)
            .filter(|_| stage.checkpoint_enabled() && !stage.direct())
            .ok_or_else(|| foreign(stage, Operation::Write))?;
        self.write_checkpointed_parts(stage, upload, input).await
    }

    /// The bucket's own limits ([`limits`]): an ONTAP NAS bucket refuses objects over 5 GiB and
    /// keys it would store under another name.
    fn final_refusal(&self, path: &StoragePath, size: Option<u64>) -> Option<String> {
        limits::refusal(self.protocol.bucket_capabilities(), path, size)
    }

    /// 5 GiB: a directory object is one `PutObject` or `CopyObject` (P7 D13).
    fn directory_object_limit(&self) -> Option<u64> {
        Some(directory_object::MAX_DIRECTORY_OBJECT_BYTES)
    }

    async fn prepare_at_destination(
        &self,
        request: DestinationPrepareRequest,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        self.prepare_at_destination_stage(request).await
    }

    async fn prepare_direct(
        &self,
        request: PrepareRequest,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        self.prepare_direct_stage(request, &cancel).await
    }

    async fn write_single(
        &self,
        stage: &PreparedStage,
        data: Bytes,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        self.validate(stage)?;
        match single::of(stage) {
            Some(single) if !stage.direct() => single::write_single(stage, single, data),
            _ => {
                self.write(
                    stage,
                    Box::pin(futures::stream::once(async move { Ok(data) })),
                )
                .await
            }
        }
    }

    async fn write(
        &self,
        stage: &PreparedStage,
        input: ByteStream,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        self.validate(stage)?;
        if stage.direct() {
            return self.write_direct(stage, input).await;
        }
        if let Some(streamed) = streaming::of(stage) {
            return streaming::write(self, stage, streamed, input).await;
        }
        if let Some(single) = single::of(stage) {
            return single::write(stage, single, input).await;
        }
        let upload = at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Write))?;
        self.write_final_upload(stage, upload, input).await
    }

    async fn observe_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<CheckpointObservation, StorageRoleFailure> {
        self.validate(stage)?;
        if stage.direct() {
            return Ok(CheckpointObservation {
                durable_prefix: Self::direct_durable_bytes(stage),
            });
        }
        if let Some(single) = single::of(stage) {
            return Ok(CheckpointObservation {
                durable_prefix: single.written_len(),
            });
        }
        if let Some(streamed) = streaming::of(stage) {
            return Ok(CheckpointObservation {
                durable_prefix: streamed.written_len(),
            });
        }
        let upload = at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Prepare))?;
        self.observe_final_upload(stage, upload).await
    }

    async fn verify(
        &self,
        stage: &PreparedStage,
        request: VerifyRequest,
    ) -> Result<VerificationEvidence, StorageRoleFailure> {
        if stage.direct() {
            return self.verify_direct(stage, &request).await;
        }
        if let Some(single) = single::of(stage) {
            return single::verify(self, stage, single, &request).await;
        }
        if let Some(streamed) = streaming::of(stage) {
            return streaming::verify(self, stage, streamed, &request).await;
        }
        let upload = at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Verify))?;
        self.verify_final_upload(stage, upload, &request).await
    }

    async fn apply_metadata(
        &self,
        stage: &PreparedStage,
        mutation: MetadataMutation,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        self.validate(stage)?;
        if stage.direct() {
            // The object is already at its final key.
            let metadata = self
                .metadata
                .as_ref()
                .ok_or_else(|| metadata_unavailable(stage))?;
            return metadata
                .apply(stage.final_destination().path(), mutation, cancel)
                .await;
        }
        if let Some(single) = single::of(stage) {
            if self.metadata.is_none() {
                return Err(metadata_unavailable(stage));
            }
            return single::apply_metadata(stage, single, self.tags_supported, mutation, &cancel);
        }
        if let Some(streamed) = streaming::of(stage) {
            if self.metadata.is_none() {
                return Err(metadata_unavailable(stage));
            }
            return streaming::apply_metadata(
                stage,
                streamed,
                self.tags_supported,
                mutation,
                &cancel,
            );
        }
        let upload =
            at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Metadata))?;
        if stage.recovered_publication().is_some() {
            return self
                .validate_recovered_upload_metadata(stage, upload, vec![mutation], &cancel)
                .await;
        }
        self.apply_final_upload_metadata(stage, upload, mutation, &cancel)
    }

    async fn validate_recovered_metadata(
        &self,
        stage: &PreparedStage,
        mutations: Vec<MetadataMutation>,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        self.validate(stage)?;
        let upload =
            at_destination::of(stage).ok_or_else(|| foreign(stage, Operation::Metadata))?;
        self.validate_recovered_upload_metadata(stage, upload, mutations, &cancel)
            .await
    }

    async fn publish(
        &self,
        stage: &PreparedStage,
        request: PublishRequest,
    ) -> Result<PublicationEvidence, PublicationFailure> {
        if stage.direct() {
            return self.publish_direct(stage);
        }
        if let Some(single) = single::of(stage) {
            return single::publish(self, stage, single, &request).await;
        }
        if let Some(streamed) = streaming::of(stage) {
            return streaming::publish(self, stage, streamed, &request).await;
        }
        let upload = at_destination::of(stage).ok_or_else(|| PublicationFailure {
            error: foreign(stage, Operation::Publish),
            final_destination_changed: false,
        })?;
        self.publish_final_upload(stage, upload, &request).await
    }

    async fn discard(&self, stage: PreparedStage) -> Result<(), StorageRoleFailure> {
        self.validate(&stage)?;
        if stage.direct() {
            return self.discard_direct(&stage).await;
        }
        if single::of(&stage).is_some() {
            // Nothing was sent before publication, and a published object is never deleted.
            return Ok(());
        }
        if let Some(streamed) = streaming::of(&stage) {
            // The request still holds its last byte: aborting it commits nothing.
            streamed.abandon();
            return Ok(());
        }
        let upload =
            at_destination::of(&stage).ok_or_else(|| foreign(&stage, Operation::Namespace))?;
        self.discard_final_upload(&stage, upload).await
    }

    /// Every S3 stage writes the final key itself — a single PUT or `CopyObject`, a `Direct`
    /// write, an upload on the final key — so it is read back only after publication.
    fn verification_point(&self, _stage: &PreparedStage) -> VerificationPoint {
        VerificationPoint::AfterPublish
    }

    /// Pinned by version or `If-Match`; bracketed by `ETag` on a bucket without conditional reads
    /// (an ONTAP NAS bucket, P7 §14.2 N4).
    fn read_back_method(&self, _stage: &PreparedStage) -> ReadBackMethod {
        if self.protocol.bucket_capabilities().conditional_reads {
            ReadBackMethod::Pinned
        } else {
            ReadBackMethod::EtagBracketed {
                reason: UnpinnedReadReason::ConditionalReadsUnsupported,
            }
        }
    }

    /// `Matched` where the store checked a `Content-MD5` on every request that sent bytes (a
    /// buffered `PutObject`, each part of a streamed multipart upload) or a streamed `PutObject`'s
    /// reply `ETag` equalled our MD5; a server-side copy sent none; a resumed upload's bytes were
    /// sent by an earlier attempt.
    fn upload_digest(&self, stage: &PreparedStage) -> UploadDigest {
        if let Some(streamed) = streaming::of(stage) {
            return streamed.upload_digest();
        }
        if let Some(single) = single::of(stage) {
            return if single.is_native() {
                UploadDigest::Unchecked(UploadDigestGap::NativeCopy)
            } else {
                UploadDigest::Matched
            };
        }
        match at_destination::of(stage) {
            Some(upload) => {
                let current = upload.lock();
                final_upload_digest(current.native, current.md5_etags)
            }
            // A `Direct` multipart upload: every part carried its `Content-MD5`.
            None => UploadDigest::Matched,
        }
    }

    /// `GetBucketVersioning` now: `Enabled` keeps every record (P7 H1).
    async fn keeps_history(&self) -> Result<bool, StorageRoleFailure> {
        self.versioning_enabled_now(&StoragePath::root()).await
    }

    /// A delete marker on the final key, only while the bucket's versioning is `Enabled` (P7 H1,
    /// [`delete_marker`]).
    async fn write_delete_marker(
        &self,
        path: &StoragePath,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<crate::storage::DeleteMarkerOutcome, StorageRoleFailure> {
        self.delete_marker(path, &cancel).await
    }
}

/// What an upload on the final key confirmed: a native fill copied server-side; an attempt that
/// sent no part (it resumed every one) reports none; otherwise every part this attempt sent
/// carried a `Content-MD5` the store checked — whatever the part `ETag`s look like (SSE-KMS).
fn final_upload_digest(native: bool, md5_etags: Option<bool>) -> UploadDigest {
    match (native, md5_etags) {
        (true, _) => UploadDigest::Unchecked(UploadDigestGap::NativeCopy),
        (false, None) => UploadDigest::Unchecked(UploadDigestGap::PriorAttempt),
        (false, Some(_)) => UploadDigest::Matched,
    }
}

fn metadata_unavailable(stage: &PreparedStage) -> StorageRoleFailure {
    classified_entry(
        stage.final_destination().path(),
        Operation::Metadata,
        FailureClass::Unsupported,
        Transience::Permanent,
        "staged S3 metadata is unavailable",
    )
}

/// A stage this adapter did not prepare at the destination, nor as `Direct` (another adapter's
/// stage): refused before anything is touched.
fn foreign(stage: &PreparedStage, operation: Operation) -> StorageRoleFailure {
    classified_entry(
        stage.final_destination().path(),
        operation,
        FailureClass::Conflict,
        Transience::Permanent,
        "S3 stage was not prepared at the destination",
    )
}

#[cfg(any(test, feature = "test-support"))]
mod digest_tests {
    use super::{UploadDigest, UploadDigestGap, final_upload_digest};

    /// A streamed upload is `Matched` even when its part `ETag`s are not MD5s (each part's
    /// `Content-MD5` was checked); a native fill is `NativeCopy`; an attempt that sent nothing is
    /// `PriorAttempt`.
    #[test]
    fn an_upload_on_the_final_key_reports_what_it_sent() {
        assert_eq!(
            final_upload_digest(false, Some(true)),
            UploadDigest::Matched
        );
        assert_eq!(
            final_upload_digest(false, Some(false)),
            UploadDigest::Matched
        );
        assert_eq!(
            final_upload_digest(true, Some(false)),
            UploadDigest::Unchecked(UploadDigestGap::NativeCopy)
        );
        assert_eq!(
            final_upload_digest(false, None),
            UploadDigest::Unchecked(UploadDigestGap::PriorAttempt)
        );
    }
}
