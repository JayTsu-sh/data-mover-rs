from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();command=['python3','run-backend-qos.py','--config','memory-profile.private.json','--root',str(r),'--binary',str(r/'qos-bin'),'--phase','survey','--repeats','3','--performance-control','--isolated-destinations','--cleanup-binary',str(r/'qos-cleanup'),'--reuse-fixtures','--retain-source','--performance-idle-ms','1000','--output',str(r/'memory-survey')];(r/'memory-survey-plan.json').write_text(json.dumps({'command':command,'binary_sha256':hashlib.sha256((r/'qos-bin').read_bytes()).hexdigest(),'scope':'diagnostic tmpfs target; same RustFS executable, no shared server modifications; original disk failures retained','sample_count':9,'size_mib':512},indent=2))
with (r/'memory-survey.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(r/'memory-survey-status.json').write_text(json.dumps({'exit':result.returncode}));print('memory survey exit',result.returncode,flush=True)
