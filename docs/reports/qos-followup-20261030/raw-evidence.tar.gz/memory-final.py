from pathlib import Path
import json,subprocess,time
r=Path.cwd()
while not (r/'memory-survey-status.json').exists():time.sleep(1)
command=json.load(open('memory-survey-plan.json'))['command'];command[command.index('--phase')+1]='final';command[command.index('--output')+1]=str(r/'memory-final');command+=['--baseline',str(r/'memory-survey')];(r/'memory-final-plan.json').write_text(json.dumps({'command':command,'scope':'finite bandwidth and IOPS attribution on same temporary S3 instance; original disk results retained'},indent=2))
with (r/'memory-final.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(r/'memory-final-status.json').write_text(json.dumps({'exit':result.returncode}));print('memory final exit',result.returncode,flush=True)
