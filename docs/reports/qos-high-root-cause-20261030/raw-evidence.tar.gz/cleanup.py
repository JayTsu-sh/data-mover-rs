import pathlib,time,json,subprocess,os,shutil
root=pathlib.Path.cwd()
while not (root/"finish-testing").exists():time.sleep(2)
config=json.load(open("endpoints.private.json"));run=config["run_id"];statuses=[]
with open("cleanup-extra.log","w") as log:
 for kind in ["nfs40","cifs"]:
  env={**os.environ,**config["sources"][kind]["env"]}
  if kind=="cifs":env["QOS_SOURCE"]="smb:"+run
  result=subprocess.run(["./qos-cleanup","--run-id",run,"--tree"],env=env,capture_output=True,text=True,timeout=120);log.write(kind+"/tree exit="+str(result.returncode)+"\n"+result.stdout+result.stderr);statuses.append([kind,"tree",result.returncode])
  env["QOS_SOURCE"]="smb:" if kind=="cifs" else "nfs://10.131.7.201/jay_nfs?version=4.0&noresvport=true&uid=0&gid=0"
  result=subprocess.run(["./capture-bin","--source","fixtures","--destination","warm-destination","--path",run,"--chunk-bytes","2097152","--cleanup"],env=env,capture_output=True,text=True,timeout=60);log.write(kind+"/run-root exit="+str(result.returncode)+"\n"+result.stdout+result.stderr);statuses.append([kind,"run-root",result.returncode])
try:
 shell='set -euo pipefail; source ./common.sh; require_s3_credentials; export LAB_HDFS_LOCATION="hdfs://hdfs%2Fterrasync-runner%40HDFS.LOCAL@hdfs-ha/" LAB_HDFS_ADMIN_USER="hdfs/terrasync-runner@HDFS.LOCAL" LAB_HDFS_CONFIG_DIR="/var/lib/data-mover-lab/hadoop" LAB_HDFS_KEYTAB="/var/lib/data-mover-lab/terrasync-runner.keytab"; ./cleanup-run.sh '+run
 with open("cleanup-standard.log","w") as log:result=subprocess.run(["bash","-c",shell],stdout=log,stderr=subprocess.STDOUT,timeout=240)
 statuses.append(["standard","lifecycle",result.returncode])
except Exception as exc:statuses.append(["standard","exception",str(exc)])
for folder in ["source","destination","fixtures","warm-destination"]:
 path=root/folder
 if path.exists():shutil.rmtree(path)
(root/"cleanup-status.json").write_text(json.dumps(statuses,indent=2));print(statuses,flush=True)
