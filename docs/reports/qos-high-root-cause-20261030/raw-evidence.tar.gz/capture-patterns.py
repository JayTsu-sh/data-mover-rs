from pathlib import Path
import json,hashlib
r=Path.cwd();assert (r/'cifs-attribution/complete.json').exists();folder=r/'fixture-patterns';folder.mkdir();rows=[]
refs={16:r/'preparation/warm-local-to-local.json',128:r/'regression/limits/local-to-local/local-to-local/bandwidth-strict.json',512:r/'source-only/fixed-baseline-0.json'}
for size,ref in refs.items():
 path=r/'fixtures'/f'{size}.bin';assert path.stat().st_size==size*1048576
 with path.open('rb') as f:block=f.read(1048576)
 name=f'{size}.block.bin';(folder/name).write_bytes(block);data=json.load(open(ref));assert data['bytes']==size*1048576;rows.append({'path':name,'bytes':size*1048576,'repeat_count':size,'block_sha256':hashlib.sha256(block).hexdigest(),'reconstructed_blake3':data['digest'],'reference':str(ref.relative_to(r))})
(folder/'manifest.json').write_text(json.dumps(rows,indent=2));(r/'patterns-captured.json').write_text(json.dumps({'blocks':3,'all_measurements_finished':True}));print('Three 1MiB fixture blocks preserved before isolated cleanup')
