from pathlib import Path
import json,time
from urllib.parse import urlsplit,unquote
import boto3
from botocore.config import Config
r=Path.cwd()
while not (r/'cleanup-status.json').exists():time.sleep(1)
cfg=json.load(open('endpoints.private.json'));run=cfg['run_id'];assert run==r.name and run.startswith('nightly-qos-high-');prefix='ci/'+run+'/'
src=cfg['sources']['s3']['env'];host=src['S3_HOST'];host=host if '://' in host else 'http://'+host;p=urlsplit(cfg['destinations']['s3']['endpoint']);bucket,dst_host=p.hostname.split('.',1)
entries=[('source',host,src['S3_AK'],src['S3_SK'],src['S3_BUCKET']),('destination','http://'+dst_host+':'+str(p.port or 9000),unquote(p.username),unquote(p.password),bucket)];rows=[]
for label,endpoint,ak,sk,bucket in entries:
 s3=boto3.client('s3',endpoint_url=endpoint,aws_access_key_id=ak,aws_secret_access_key=sk,region_name='us-east-1',config=Config(proxies={},s3={'addressing_style':'path'}));versioning=s3.get_bucket_versioning(Bucket=bucket).get('Status','Unversioned');deleted=aborted=0
 for _ in range(100):
  uploads=s3.list_multipart_uploads(Bucket=bucket,Prefix=prefix).get('Uploads',[])
  if not uploads:break
  for v in uploads:assert v['Key'].startswith(prefix);s3.abort_multipart_upload(Bucket=bucket,Key=v['Key'],UploadId=v['UploadId']);aborted+=1
 else:raise RuntimeError('run-scoped multipart cleanup did not converge')
 for _ in range(100):
  data=s3.list_object_versions(Bucket=bucket,Prefix=prefix);objects=[{'Key':v['Key'],'VersionId':v['VersionId']} for kind in ['Versions','DeleteMarkers'] for v in data.get(kind,[])]
  if not objects:break
  assert all(v['Key'].startswith(prefix) for v in objects);answer=s3.delete_objects(Bucket=bucket,Delete={'Objects':objects,'Quiet':True});assert not answer.get('Errors');deleted+=len(objects)
 else:raise RuntimeError('run-scoped version cleanup did not converge')
 assert not s3.list_objects_v2(Bucket=bucket,Prefix=prefix).get('Contents');rows.append({'endpoint':label,'prefix':prefix,'versioning':versioning,'versions_and_markers_deleted':deleted,'multipart_aborted':aborted,'empty':True})
(r/'s3-cleanup.json').write_text(json.dumps(rows,indent=2));statuses=json.load(open('cleanup-status.json'));data={'lifecycle':statuses,'s3':rows,'all_lifecycle_operations_succeeded':all(isinstance(v[-1],int) and v[-1]==0 for v in statuses),'local_fixture_directories_remaining':[name for name in ['source','destination','fixtures','warm-destination'] if (r/name).exists()]};assert data['all_lifecycle_operations_succeeded'] and not data['local_fixture_directories_remaining'];(r/'cleanup.json').write_text(json.dumps(data,indent=2));print('All five lifecycle operations succeeded; two S3 run prefixes empty including versions/delete markers/multipart; local fixtures removed')
