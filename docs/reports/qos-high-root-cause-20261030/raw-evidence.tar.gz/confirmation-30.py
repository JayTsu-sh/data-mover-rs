from pathlib import Path
import json,time,subprocess,os,random,statistics,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'fixed-limits/complete.json').exists():time.sleep(1)
profile=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']=='s3-to-hdfs');env={**os.environ,**profile['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'confirmation-30';folder.mkdir();rng=random.Random(202610301);order=[['baseline','high']]*15+[['high','baseline']]*15;rng.shuffle(order);arms={'baseline':[],'high':[]}
(folder/'plan.json').write_text(json.dumps({'pairs':30,'size_mib':512,'seed':202610301,'order':order,'minimum_ratio':.98,'idle_ms':1000,'binary_sha256':hashlib.sha256((r/'capture-bin').read_bytes()).hexdigest(),'original_15_pair_failure_retained':True},indent=2))
for i,pair in enumerate(order):
 for arm in pair:
  cmd=[str(r/'capture-bin'),'--source',str(r/'fixtures'),'--destination',str(r/'destination/s3-to-hdfs'),'--path','512.bin','--chunk-bytes',str(profile['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'confirmation failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));arms[arm].append(d['mibps']);print(arm,i,d['mibps'],flush=True)
med={a:statistics.median(v) for a,v in arms.items()};ratio=med['high']/med['baseline'];result={'baseline_mibps':med['baseline'],'high_mibps':med['high'],'ratio':ratio,'passed':ratio>=.98,'samples_per_arm':30};(folder/'summary.json').write_text(json.dumps(result,indent=2))
# Pool every eligible uninstrumented same-size final-binary copy, never the best subset.
all_arms={a:list(arms[a]) for a in arms}
for arm in all_arms:
 for i in range(12):all_arms[arm].append(json.load(open(r/'matched-capture'/f'fixed-{arm}-{i}.json'))['mibps'])
 for i in range(15):all_arms[arm].append(json.load(open(r/'regression/focused/s3-to-hdfs'/f'{arm}-{i}.json'))['mibps'])
pooled=statistics.median(all_arms['high'])/statistics.median(all_arms['baseline']);(folder/'pooled-all-57.json').write_text(json.dumps({'ratio':pooled,'passed':pooled>=.98,'samples_per_arm':57,'cohorts':['matched-capture final arms,12','regression/focused s3-to-hdfs,15','confirmation-30,30'],'status':'post-hoc pooled sensitivity analysis; independent 30-pair verdict is separate; initial 15-pair failure retained'},indent=2));(folder/'complete.json').write_text(json.dumps(result));print('Independent confirmation',ratio,'all-57 pooled',pooled,flush=True)
