from pathlib import Path
import json,time,subprocess,concurrent.futures,hashlib
r=Path.cwd()
while not (r/'matched/status.json').exists():time.sleep(1)
matched=json.load(open(r/'matched/status.json'))
if not matched['candidate_non_regression_passed']:
 (r/'regression-blocked.json').write_text(json.dumps(matched));raise SystemExit('Matched comparison failed; no broad run of unqualified candidate')
folder=r/'regression';folder.mkdir();status=[]
def invoke(label,cmd):
 print(label,flush=True)
 with (folder/(label+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 status.append(dict(label=label,exit=code,command=cmd));(folder/'status.json').write_text(json.dumps(status,indent=2));return code
cfg=json.load(open('endpoints.private.json'))
for name in ['local','nfs3','nfs40','nfs41','cifs','s3','hdfs']:(r/'destination'/f'{name}-to-local').mkdir(parents=True,exist_ok=True)
base=['python3','run-cross-backend-qos.py','--config',str(r/'endpoints.private.json'),'--root',str(r),'--binary',str(r/'fixed-bin')]
assert invoke('warmup',base+['--stage','warmup'])==0
assert invoke('seed',base+['--stage','seed'])==0
matrix=json.load(open('matrix.private.json'));sizes=json.load(open('previous-performance-sizes.json'))
for row in matrix['profiles']:row['performance_size_mib']=sizes[row['name']]
private=r/'regression.private.json';private.write_text(json.dumps(matrix));private.chmod(0o600)
names=[p['name'] for p in matrix['profiles']];focused=['nfs41-to-s3','s3-to-hdfs'];others=[n for n in names if n not in focused]
command=['python3','run-backend-qos.py','--config',str(private),'--root',str(r),'--binary',str(r/'fixed-bin'),'--reuse-fixtures','--retain-source','--performance-idle-ms','1000']
# Every performance gate and failed attempt is retained; there is no success-based sample selection.
for label,profiles,repeats in [('focused',focused,15),('others',others,5)]:invoke(label,command+['--phase','survey','--repeats',str(repeats),'--output',str(folder/label),'--profiles',*profiles])
def finite(name):
 focus=name in focused;return invoke('limits-'+name,command+['--phase','final','--repeats','15' if focus else '5','--baseline',str(folder/('focused' if focus else 'others')),'--output',str(folder/'limits'/name),'--profiles',name])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(finite,names))
checks=[];summary={}
for name in names:
 path=folder/'limits'/name;checks.extend(json.load(open(path/'checks.json')));summary.update(json.load(open(path/'summary.json')))
(folder/'checks.json').write_text(json.dumps(checks,indent=2));(folder/'summary.json').write_text(json.dumps(summary,indent=2));(folder/'complete.json').write_text(json.dumps({'passed':sum(c['passed'] for c in checks),'total':len(checks),'routes':len(names),'binary_sha256':hashlib.sha256((r/'fixed-bin').read_bytes()).hexdigest(),'performance_idle_ms':1000,'original_sizes_preserved':True},indent=2));print('Full regression finished',sum(c['passed'] for c in checks),len(checks),flush=True)
