from pathlib import Path
import json,time,subprocess,os,random,statistics,hashlib
from qos_evidence import redact,secret_values
from target_settle import settle_target
r=Path.cwd();name='hdfs-to-nfs41';folder=r/'hdfs-nfs-absolute'
while not (r/'cifs-absolute/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']==name);env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder.mkdir();arms=['old-high','fixed-high','fixed-baseline'];values={a:[] for a in arms};rng=random.Random(202610304);order=[]
for cycle in range(4):
 base=arms.copy();rng.shuffle(base);cycle_order=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle_order);order.extend(cycle_order)
(folder/'plan.json').write_text(json.dumps({'blocks':12,'size_mib':128,'order':order,'seed':202610304,'threshold':.98,'binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','capture-bin']},'precondition':'before each arm target VM13 Dirty<=16MiB, Writeback=0, sda inflight=0 on two half-second-spaced snapshots; max180s; no sync or server setting change'},indent=2))
for i,block in enumerate(order):
 for arm in block:
  settle_target(folder/'readiness.jsonl',arm+'-'+str(i))
  cmd=[str(r/('qos-bin' if arm=='old-high' else 'capture-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'/name),'--path','128.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'absolute control failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));values[arm].append(d['mibps']);print(name,arm,i,d['mibps'],flush=True)
med={k:statistics.median(v) for k,v in values.items()};ratio=med['fixed-high']/med['old-high'];relative=med['fixed-high']/med['fixed-baseline'];d={'medians':med,'ratio':ratio,'passed':ratio>=.98,'fixed_high_to_fixed_baseline':relative,'relative_passed':relative>=.98,'blocks':12,'target_readiness_controlled':True};(folder/'summary.json').write_text(json.dumps(d,indent=2));(folder/'complete.json').write_text(json.dumps(d));print('Readiness-controlled absolute comparison',d,flush=True)
