from pathlib import Path
import json,time,subprocess,os,random,statistics,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'confirmation-30/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']=='s3-to-hdfs');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};env.pop('QOS_DESTINATION',None);secrets=secret_values([env]);folder=r/'source-only';folder.mkdir();arms=['old-baseline','old-high','fixed-baseline','fixed-high'];values={a:[] for a in arms};rng=random.Random(202610302);order=[]
for cycle in range(3):
 base=arms.copy();rng.shuffle(base);cycles=[base[i:]+base[:i] for i in range(4)];rng.shuffle(cycles);order.extend(cycles)
(folder/'plan.json').write_text(json.dumps({'size_mib':512,'blocks':order,'seed':202610302,'scope':'source-only attribution, no HDFS write/close; full negotiated backend source concurrency; not a replacement for copy acceptance','binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['old-source-probe','capture-source-probe']},'idle_ms':1000},indent=2))
for i,block in enumerate(order):
 for arm in block:
  cmd=[str(r/('old-source-probe' if arm.startswith('old') else 'capture-source-probe')),'--source',str(r/'fixtures'),'--destination',str(r/'warm-destination'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--transfer-profile','cross','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'source-only diagnostic failed';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));assert d['operations']==64 and d['bytes']==512*1048576;values[arm].append(d['mibps']);print(arm,i,d['mibps'],flush=True)
med={k:statistics.median(v) for k,v in values.items()};(folder/'summary.json').write_text(json.dumps({'medians':med,'old_ratio':med['old-high']/med['old-baseline'],'fixed_ratio':med['fixed-high']/med['fixed-baseline'],'diagnostic_only':True},indent=2));(folder/'complete.json').write_text(json.dumps({'samples':48,'scope':'no sink writes, source-only attribution','all_payload_requests_8MiB':True}));print('Source-only study complete',med,flush=True)
