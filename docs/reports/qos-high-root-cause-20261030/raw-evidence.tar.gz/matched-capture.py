from pathlib import Path
import json,time,subprocess,os,hashlib,statistics,resource,random
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'stage-probes/status.json').exists():time.sleep(1)
cfg=json.load(open('repro.private.json'));p=next(p for p in cfg['profiles'] if p['name']=='s3-to-hdfs');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'matched-capture';folder.mkdir();samples={k:[] for k in ['old-baseline','old-high','fixed-baseline','fixed-high']};rows=[];plan=[]
# Balanced rotations, fixed before observing the matched experiment.
arms=list(samples)
rng=random.Random(20261030)
for cycle in range(3):
 base=arms.copy();rng.shuffle(base);orders=[base[i:]+base[:i] for i in range(4)];rng.shuffle(orders);plan.extend(orders)
(folder/'plan.json').write_text(json.dumps({'size_mib':512,'blocks':plan,'idle_ms':1000,'threshold':.98,'binary_sha256':{k:hashlib.sha256((r/k).read_bytes()).hexdigest() for k in ['qos-bin','capture-bin']},'route':'s3-to-hdfs'},indent=2))
for i,order in enumerate(plan):
 for arm in order:
  binary='qos-bin' if arm.startswith('old') else 'capture-bin';cmd=[str(r/binary),'--source',str(r/'fixtures'),'--destination',str(r/'destination/s3-to-hdfs'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  before=resource.getrusage(resource.RUSAGE_CHILDREN);result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);after=resource.getrusage(resource.RUSAGE_CHILDREN);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'matched sample failed';d=json.loads(result.stdout);d['command']=cmd;d['resources']={f:getattr(after,f)-getattr(before,f) for f in ['ru_utime','ru_stime','ru_nvcsw','ru_nivcsw']};(folder/f'{arm}-{i}.json').write_text(json.dumps(d));samples[arm].append(d['mibps']);rows.append(dict(arm=arm,block=i,mibps=d['mibps'],seconds=d['seconds'],resources=d['resources']));(folder/'samples.json').write_text(json.dumps(rows,indent=2));print(arm,i,d['mibps'],flush=True)
medians={k:statistics.median(v) for k,v in samples.items()};ratios={'old_high_to_old_baseline':medians['old-high']/medians['old-baseline'],'fixed_high_to_fixed_baseline':medians['fixed-high']/medians['fixed-baseline'],'fixed_high_to_old_high':medians['fixed-high']/medians['old-high'],'fixed_baseline_to_old_baseline':medians['fixed-baseline']/medians['old-baseline']};checks=[dict(name=k,ratio=v,passed=v>=.98) for k,v in ratios.items()];(folder/'summary.json').write_text(json.dumps({'medians':medians,'checks':checks},indent=2));(folder/'status.json').write_text(json.dumps({'completed':48,'candidate_non_regression_passed':all(c['passed'] for c in checks if c['name']!='old_high_to_old_baseline')}));print(json.dumps(ratios),flush=True)
