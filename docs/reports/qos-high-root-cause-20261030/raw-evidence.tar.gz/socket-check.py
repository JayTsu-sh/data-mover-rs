from pathlib import Path
import json,time,subprocess,os,re
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'matched-shared/status.json').exists():time.sleep(1)
p=next(p for p in json.load(open('repro.private.json'))['profiles'] if p['name']=='s3-to-hdfs');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'socket-check';folder.mkdir();rows=[]
for binary in ['qos-bin','shared-bin']:
 for arm in ['baseline','high']:
  trace=folder/f'{binary}-{arm}.connect';cmd=[str(r/binary),'--source',str(r/'fixtures'),'--destination',str(r/'destination/s3-to-hdfs'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(['strace','-f','-ttt','-T','-e','trace=connect','-o',str(trace),*cmd],env=env,capture_output=True,text=True,timeout=180);(folder/f'{binary}-{arm}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'socket diagnostic copy failed';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{binary}-{arm}.json').write_text(json.dumps(d));lines=[line for line in trace.read_text().splitlines() if 'connect(' in line and 'htons(9000)' in line and '10.10.1.12' in line];rows.append({'binary':binary,'arm':arm,'s3_tcp_connection_attempts':len(lines),'diagnostic_only':True});print(rows[-1],flush=True)
(folder/'summary.json').write_text(json.dumps(rows,indent=2));(folder/'status.json').write_text(json.dumps({'completed':4,'scope':'actual connect syscalls; metadata and payload combined; instrumented timing excluded from qualification'}))
