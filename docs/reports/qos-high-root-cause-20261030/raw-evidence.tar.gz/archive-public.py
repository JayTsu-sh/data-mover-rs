from pathlib import Path
import json,tarfile,io,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd();cfg=json.load(open('endpoints.private.json'));secrets=secret_values([p.get('env',{}) for p in [*cfg['sources'].values(),*cfg['destinations'].values()]]);secrets=sorted(set(secrets+[json.dumps(v)[1:-1] for v in secrets]),key=len,reverse=True)
paths=[]
for name in ['preparation','reproduce-initial-preparation','reproduce','stage-probes','matched','matched-shared','matched-capture','socket-check','socket-capture','regression','fixed-limits','fixture-patterns','confirmation-30','source-only','cifs-absolute','hdfs-nfs-absolute','local-nfs-cold','cifs-attribution']:
 if (r/name).is_dir():paths.extend(p for p in (r/name).rglob('*') if p.is_file() and '.private.' not in p.name and (p.suffix in ['.json','.jsonl','.log','.stderr','.connect'] or p.name.endswith('.block.bin')))
paths.extend(p for p in r.iterdir() if p.is_file() and '.private.' not in p.name and p.suffix in ['.json','.log','.py','.sh'] and p.name!='archive-audit.json')
manifest=[];redactions=0
with tarfile.open(r/'public-evidence.tar.gz','w:gz') as tar:
 for p in sorted(set(paths)):
  if p.name.endswith('.block.bin'):data=p.read_bytes()
  else:
   raw=p.read_text();clean=redact(raw,secrets);redactions+=raw!=clean;data=clean.encode()
  assert not any(v.encode() in data for v in secrets),'Credential remains in '+str(p.relative_to(r))
  name=str(p.relative_to(r));item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;tar.addfile(item,io.BytesIO(data));manifest.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(r/'archive-audit.json').write_text(json.dumps(dict(files=len(manifest),redacted_files=redactions,credential_scan_passed=True,manifest=manifest,archive_sha256=hashlib.sha256((r/'public-evidence.tar.gz').read_bytes()).hexdigest()),indent=2));print('Public evidence credential scan passed:',len(manifest),'files')
