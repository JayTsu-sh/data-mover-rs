"""Ensure the real directed matrix cannot silently miss a backend pair."""
import importlib.util
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location("cross_qos_matrix", Path(__file__).parent / "lab/cross_qos_matrix.py")
MATRIX = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MATRIX)
EVIDENCE_SPEC = importlib.util.spec_from_file_location("qos_evidence", Path(__file__).parent / "lab/qos_evidence.py")
EVIDENCE = importlib.util.module_from_spec(EVIDENCE_SPEC)
EVIDENCE_SPEC.loader.exec_module(EVIDENCE)


def config():
    return {"sources": {kind: {"env": {"QOS_SOURCE": f"source/{kind}"}} for kind in MATRIX.SOURCES},
            "destinations": {kind: {"endpoint": f"destination/{kind}/{{pair}}"} for kind in MATRIX.FAMILIES}}


class CrossQosMatrix(unittest.TestCase):
    def test_baseline_import_cannot_select_fewer_repeats_or_change_idle(self):
        measured = {"configuration_sha256": "config", "binary_sha256": "binary",
                    "repetitions": 15, "performance_idle_ms": 1000}
        EVIDENCE.verify_baseline_identity(measured, "config", "binary", 15, 1000)
        for arguments in [("other", "binary", 15, 1000), ("config", "other", 15, 1000),
                          ("config", "binary", 5, 1000), ("config", "binary", 15, 0)]:
            with self.assertRaises(ValueError):
                EVIDENCE.verify_baseline_identity(measured, *arguments)

    def test_url_credentials_and_encoded_passwords_are_redacted(self):
        secrets = EVIDENCE.secret_values([{"QOS_DESTINATION": "s3://user:p%40ss@example/bucket",
                                           "S3_SK": "secret-key"}])
        text = EVIDENCE.redact("s3://user:p%40ss@example/bucket p@ss secret-key", secrets)
        self.assertEqual(text, "s3://<REDACTED>:<REDACTED>@example/bucket <REDACTED> <REDACTED>")

    def test_all_twenty_directed_cross_family_pairs_and_seven_regressions(self):
        rows = MATRIX.profiles(config())
        pairs = {(row["source_kind"], row["destination_kind"]) for row in rows}
        self.assertEqual(len(rows), 23)
        self.assertEqual(len(pairs), 23)
        expected = {(source, destination) for source in MATRIX.FAMILIES
                    for destination in MATRIX.FAMILIES if source != destination}
        self.assertTrue(expected <= pairs)
        self.assertTrue({(source, "local") for source in MATRIX.SOURCES} <= pairs)
        self.assertNotIn(("s3", "s3"), pairs)  # native server-side bytes are unshaped

    def test_source_family_is_not_inferred_from_route_label(self):
        rows = MATRIX.profiles(config())
        row = next(row for row in rows if row["name"] == "s3-to-cifs")
        self.assertEqual(row["source_kind"], "s3")
        self.assertEqual(row["chunk_bytes"], 8 * 1024 * 1024)
        self.assertEqual(row["env"]["QOS_DESTINATION"], "destination/cifs/s3-to-cifs")
        self.assertEqual(row["transfer_profile"], "cross")

    def test_larger_fixture_override_cannot_change_the_route_or_finite_limits(self):
        original = MATRIX.profiles(config())[1]
        revised = {**original, "performance_size_mib": 512}
        MATRIX.validate_override(original, revised)
        with self.assertRaisesRegex(ValueError, "changed the route"):
            MATRIX.validate_override(original, {**revised, "env": {"QOS_SOURCE": "different-source"}})
        with self.assertRaisesRegex(ValueError, "changed the route"):
            MATRIX.validate_override(original, {**revised, "soft_mibps": 1})

    def test_conflicting_process_global_credentials_are_rejected(self):
        data = config()
        data["sources"]["s3"]["env"]["S3_HOST"] = "source-server"
        data["destinations"]["hdfs"]["env"] = {"S3_HOST": "different-server"}
        with self.assertRaisesRegex(ValueError, "conflicting endpoint environment"):
            MATRIX.profiles(data)


if __name__ == "__main__":
    unittest.main()
