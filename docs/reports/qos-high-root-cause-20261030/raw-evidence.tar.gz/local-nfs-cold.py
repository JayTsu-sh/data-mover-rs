from pathlib import Path
import json,time,subprocess,os,random,statistics
from qos_evidence import redact,secret_values
from target_settle import settle_target
r=Path.cwd()
while not (r/'hdfs-nfs-absolute/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']=='local-to-nfs41');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'local-nfs-cold';folder.mkdir();original=json.load(open('local-nfs-reference.json'));rng=random.Random(202610305);order=[['old','fixed']]*3+[['fixed','old']]*2;rng.shuffle(order);values={'old':[],'fixed':[]};soft=int(original[original.index('--soft-bytes')+1]);(folder/'plan.json').write_text(json.dumps({'pairs':5,'order':order,'seed':202610305,'scope':'exact original 128MiB strict bandwidth, cold lifecycle preflight attribution; serialized target volume','command_reference':original,'new_code_not_on_this_backend_path':True},indent=2))
for i,pair in enumerate(order):
 for arm in pair:
  settle_target(folder/'readiness.jsonl',arm+'-'+str(i))
  cmd=[v.replace('/tmp/nightly-qos-cross-20261029192047',str(r)) for v in original];cmd[0]=str(r/('qos-bin' if arm=='old' else 'capture-bin'));result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'local/NFS finite control failed';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));ratio=d['bytes']/d['seconds']/soft;values[arm].append(ratio);print(arm,i,ratio,'first_admission',d['admissions'][0]['seconds'],'tail',d['seconds']-d['admissions'][-1]['seconds'],flush=True)
med={k:statistics.median(v) for k,v in values.items()};summary={'end_to_end_ratio_medians':med,'fixed_to_old_ratio':med['fixed']/med['old'],'absolute_non_regression_passed':med['fixed']/med['old']>=.98,'cold_end_to_end_98_percent':{k:v>=.98 for k,v in med.items()},'pairs':5};(folder/'summary.json').write_text(json.dumps(summary,indent=2));(folder/'complete.json').write_text(json.dumps(summary));print('Cold Local/NFS paired control',summary,flush=True)
