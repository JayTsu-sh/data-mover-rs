from pathlib import Path
import json,time,subprocess
r=Path.cwd()
while not (r/'warmup-checks.json').exists() or len(json.load(open(r/'warmup-checks.json')))<23:time.sleep(1)
cfg=json.load(open('matrix.private.json'));cfg['profiles']=[p for p in cfg['profiles'] if p['name'] in ['nfs41-to-s3','s3-to-hdfs']]
for p in cfg['profiles']:p['performance_size_mib']=512
private=r/'repro.private.json';private.write_text(json.dumps(cfg));private.chmod(0o600)
cmd=['python3','run-backend-qos.py','--config',str(private),'--root',str(r),'--binary',str(r/'qos-bin'),'--phase','survey','--performance-size-mib','512','--repeats','10','--performance-idle-ms','1000','--retain-source','--output',str(r/'reproduce')]
with (r/'reproduce.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
(r/'reproduce-status.json').write_text(json.dumps({'exit':code,'command':cmd}));print('reproduction exit',code,flush=True)
