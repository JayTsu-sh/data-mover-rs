"""Protect credentials and the provenance of QoS lab artifacts."""
from urllib.parse import unquote, urlsplit


def secret_values(environments):
    secrets = set()
    for environment in environments:
        for key, value in environment.items():
            if any(part in key.upper() for part in
                   ("PASS", "SECRET", "_AK", "_SK", "TOKEN", "ACCESS_KEY", "API_KEY")):
                secrets.add(value)
            try:
                parsed = urlsplit(value)
                if parsed.password:
                    secrets.update((parsed.password, unquote(parsed.password)))
                    if parsed.username:
                        secrets.update((parsed.username, unquote(parsed.username)))
            except ValueError:
                pass
    return sorted((value for value in secrets if value), key=len, reverse=True)


def redact(value, secrets):
    for secret in secrets:
        value = value.replace(secret, "<REDACTED>")
    return value


def verify_baseline_identity(measured, configuration_sha256, binary_sha256, repetitions, idle_ms):
    if measured.get("configuration_sha256") != configuration_sha256:
        raise ValueError("baseline and source/destination configuration differ")
    if measured["binary_sha256"] != binary_sha256:
        raise ValueError("baseline and candidate binary differ")
    if measured["repetitions"] != repetitions:
        raise ValueError("baseline and candidate repetition counts differ")
    if measured.get("performance_idle_ms", 0) != idle_ms:
        raise ValueError("baseline and candidate unmeasured idle differ")
