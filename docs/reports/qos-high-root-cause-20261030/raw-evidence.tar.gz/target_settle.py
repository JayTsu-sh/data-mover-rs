from pathlib import Path
import json,time,subprocess,shlex
SNAPSHOT="from pathlib import Path;import json;v={s.split(':')[0]:int(s.split(':')[1].split()[0]) for s in Path('/proc/meminfo').read_text().splitlines() if s.split(':')[0] in ['Dirty','Writeback']};v['inflight']=sum(map(int,Path('/sys/block/sda/inflight').read_text().split()));print(json.dumps(v))"
def settle_target(log_path,label):
 deadline=time.monotonic()+180;quiet=0
 while time.monotonic()<deadline:
  result=subprocess.run(['ssh','-i','/home/github-runner/.ssh/terrasync_lab','-o','BatchMode=yes','-o','ConnectTimeout=5','root@10.131.9.13','python3 -c '+shlex.quote(SNAPSHOT)],capture_output=True,text=True,timeout=10)
  assert result.returncode==0,'read-only target readiness check failed'
  v=json.loads(result.stdout);v.update(label=label,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));quiet=quiet+1 if v['Dirty']<=16384 and v['Writeback']==0 and v['inflight']==0 else 0
  with log_path.open('a') as log:log.write(json.dumps(v)+'\n')
  if quiet>=2:return
  time.sleep(.5)
 raise RuntimeError('target failed to reach predeclared idle state in 180s; no performance verdict allowed')
