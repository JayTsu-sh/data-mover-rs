from pathlib import Path
import json,hashlib,statistics,math,importlib.util,collections,csv,re
base=Path('/work/qos-high-evidence');root=base/'raw'
spec=importlib.util.spec_from_file_location('validator','tests/lab/run-local-qos.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
manifest=json.load(open(base/'remote-archive-audit.json'))['manifest'];assert all(hashlib.sha256((root/p['path']).read_bytes()).hexdigest()==p['sha256'] for p in manifest)
verdicts=[]
for name in ['matched','matched-shared','matched-capture']:
 plan=json.load(open(root/name/'plan.json'));samples=json.load(open(root/name/'samples.json'));summary=json.load(open(root/name/'summary.json'));assert len(samples)==48
 med={}
 for arm in ['old-baseline','old-high','fixed-baseline','fixed-high']:
  files=[json.load(open(root/name/f'{arm}-{i}.json')) for i in range(12)];assert all(d['bytes']==512*1048576 for d in files);med[arm]=statistics.median(d['mibps'] for d in files);assert math.isclose(med[arm],summary['medians'][arm])
 ratios={'old_high_to_old_baseline':med['old-high']/med['old-baseline'],'fixed_high_to_fixed_baseline':med['fixed-high']/med['fixed-baseline'],'fixed_high_to_old_high':med['fixed-high']/med['old-high'],'fixed_baseline_to_old_baseline':med['fixed-baseline']/med['old-baseline']}
 assert all(math.isclose(g['ratio'],ratios[g['name']]) and g['passed']==(g['ratio']>=.98) for g in summary['checks']);verdicts.append(dict(experiment=name,checks_reproduced=True))
for name in ['socket-check','socket-capture']:
 for row in json.load(open(root/name/'summary.json')):
  lines=(root/name/f"{row['binary']}-{row['arm']}.connect").read_text().splitlines();n=sum('connect(' in line and 'htons(9000)' in line and '10.10.1.12' in line for line in lines);assert n==row['s3_tcp_connection_attempts']
summary=json.load(open(root/'regression/summary.json'));checks=json.load(open(root/'regression/checks.json'));expected={};perf=finite=0
binary=json.load(open(root/'regression/complete.json'))['binary_sha256'];binding=[]
for name,s in summary.items():
 p=root/'regression/limits'/name;env=json.load(open(p/'environment.json'));focused=name in ['nfs41-to-s3','s3-to-hdfs'];origin=root/'regression'/('focused' if focused else 'others');srcenv=json.load(open(origin/'environment.json'))
 assert srcenv['binary_sha256']==env['binary_sha256']==binary and srcenv['configuration_sha256']==env['configuration_sha256'];assert env['repetitions']==srcenv['repetitions']==(15 if focused else 5) and env['performance_idle_ms']==srcenv['performance_idle_ms']==1000
 arms={}
 for arm in ['baseline','high']:
  arms[arm]=[]
  for i in range(env['repetitions']):
   f=f'{arm}-{i}.json';source=origin/name/f;copy=p/name/f;assert source.read_bytes()==copy.read_bytes();d=json.load(open(copy));arms[arm].append(d);perf+=1
 baseline=statistics.median(d['mibps'] for d in arms['baseline']);high=statistics.median(d['mibps'] for d in arms['high']);cap=s['request_cap_bytes'];assert all(d['effective_read_bytes']==cap for d in arms['baseline']+arms['high'])
 expected[(name,'high','matches_baseline_98_percent')]=high>=baseline*.98
 expected[(name,'capacity','bandwidth_headroom')]=baseline*1048576>=s['soft_bytes']*2*1.25
 expected[(name,'capacity','iops_headroom')]=statistics.median(d['iops'] for d in arms['baseline'])>=s['soft_iops']*2*1.25
 for case in ['bandwidth-strict','bandwidth-dual','iops-strict','iops-dual','combined']:
  d=json.load(open(p/name/(case+'.json')));cmd=d['command'];peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';finite+=1;assert len(d['admissions'])==d['operations'] and sum(e['bytes'] for e in d['admissions'])==d['bytes']
  if name.startswith('s3-to-') and case in ['bandwidth-strict','bandwidth-dual','combined']:expected[(name,case,'s3_payload_requests_no_inflation')]=d['operations']==(d['bytes']+cap-1)//cap
  for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
   key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);t=V.validate_trace(d,resource,soft,hard,peak,dual);actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];prefix=resource+'_' if case=='combined' else ''
   expected[(name,case,prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent'))]=actual>=soft*.98
   for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):expected[(name,case,prefix+gate)]=t[gate]
 binding.append(dict(profile=name,binary_and_configuration_verified=True,repetitions=env['repetitions'],performance_idle_ms=1000))
assert len(expected)==len(checks)==955 and all(g['passed']==expected[(g['profile'],g['case'],g['name'])] for g in checks)
rows=[];digests=collections.defaultdict(set)
for path in root.rglob('*.json'):
 try:d=json.load(open(path))
 except (ValueError,UnicodeError):continue
 if not isinstance(d,dict) or not all(k in d for k in ['bytes','seconds','digest','mibps','operations']) or not d['bytes']:continue
 digests[d['bytes']].add(d['digest']);row={k:d.get(k) for k in ['bytes','operations','seconds','mibps','iops','digest','effective_read_bytes','verification_seconds','transfer_profile']};row['path']=str(path.relative_to(root));row['mode']='copy' if '--copy' in d.get('command',[]) else 'source-only';row['admissions']=len(d['admissions']);rows.append(row)
assert all(len(ds)==1 for ds in digests.values())
import subprocess
for item in json.load(open(root/'fixture-patterns/manifest.json')):
 block=root/'fixture-patterns'/item['path'];assert hashlib.sha256(block.read_bytes()).hexdigest()==item['block_sha256'];digest=subprocess.check_output(['/work/qos-cross-hash-pattern',str(block),str(item['repeat_count'])],text=True).strip();assert digests[item['bytes']]=={digest}
with (base/'measurements.csv').open('w') as f:writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(sorted(rows,key=lambda x:x['path']))
out=dict(all_archive_checksums_verified=True,all_955_regression_verdicts_reproduced=True,regression_passed=sum(g['passed'] for g in checks),regression_failed=sum(not g['passed'] for g in checks),accepted_performance_samples=perf,finite_samples=finite,matched_experiments=verdicts,actual_tcp_connect_counts_reproduced=True,all_same_size_digests_match=True,all_full_fixture_hashes_reconstructed=True,measurements_including_imported_copies=len(rows),baseline_bindings=binding)
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2));(base/'checks.json').write_text(json.dumps(checks,indent=2));(base/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='baseline_bindings'},indent=2))

# Independently audit the exact-original finite quota regression, including old/new deltas.
fixed_rows=json.load(open(root/'fixed-limits/checks.json'));original_reference=json.load(open(root/'fixed-limits-reference.json'));computed={}
for ref in original_reference:
 name,case=ref['profile'],ref['case'];d=json.load(open(root/'fixed-limits'/name/(case+'.json')));cmd=d['command'];normal=[v.replace('/tmp/nightly-qos-high-20261029234234','/tmp/nightly-qos-cross-20261029192047') for v in cmd];normal[0]=ref['command'][0];assert normal==ref['command'];assert d['bytes']==128*1048576
 peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';gates={}
 for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
  key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);trace=V.validate_trace(d,resource,soft,hard,peak,dual);prefix=resource+'_' if case=='combined' else '';actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];gates[prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent')]=actual>=soft*.98
  for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):gates[prefix+gate]=trace[gate]
 for old in ref['old_checks']:computed[(name,case,old['name'])]=(old['passed'],gates[old['name']])
assert len(fixed_rows)==len(computed)==304
for g in fixed_rows:
 old,new=computed[(g['profile'],g['case'],g['name'])];assert g['old_passed']==old and g['passed']==new and g['new_failure']==(old and not new)
out.update(all_304_original_fixed_limit_verdicts_reproduced=True,all_original_fixed_limit_commands_bound=True,fixed_limit_samples=40,fixed_limit_passed=sum(g['passed'] for g in fixed_rows),fixed_limit_new_failures=sum(g['new_failure'] for g in fixed_rows))
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2));print('Exact-original finite limit regression audit:',out['fixed_limit_passed'],'/304;',out['fixed_limit_new_failures'],'new failures')

# Independent confirmation and all subsequently collected diagnostic controls.
def close(a,b):assert math.isclose(a,b,rel_tol=1e-12)
def medians(folder,arms,n,size):
 values={}
 for arm in arms:
  ds=[json.load(open(root/folder/f'{arm}-{i}.json')) for i in range(n)]
  assert all(d['bytes']==size*1048576 for d in ds)
  values[arm]=statistics.median(d['mibps'] for d in ds)
 return values
conf=json.load(open(root/'confirmation-30/summary.json'));plan=json.load(open(root/'confirmation-30/plan.json'));assert plan['binary_sha256']==binary and plan['idle_ms']==1000 and plan['pairs']==30 and plan['minimum_ratio']==.98
cm=medians('confirmation-30',['baseline','high'],30,512);close(cm['baseline'],conf['baseline_mibps']);close(cm['high'],conf['high_mibps']);close(cm['high']/cm['baseline'],conf['ratio']);assert conf['passed']==(conf['ratio']>=.98)
for arm in ['baseline','high']:
 for i in range(30):
  d=json.load(open(root/f'confirmation-30/{arm}-{i}.json'));assert '--copy' in d['command'] and d['command'][0].endswith('/capture-bin') and d['effective_read_bytes']==8388608 and '--idle-ms' in d['command'] and d['command'][d['command'].index('--idle-ms')+1]=='1000'
pool={}
for arm in ['baseline','high']:
 paths=list((root/'confirmation-30').glob(arm+'-*.json'))+list((root/'regression/focused/s3-to-hdfs').glob(arm+'-*.json'))+list((root/'matched-capture').glob('fixed-'+arm+'-*.json'))
 assert len(paths)==57;ds=[json.load(open(p)) for p in paths];assert all(d['bytes']==512*1048576 and d['command'][0].endswith('/capture-bin') and '--copy' in d['command'] for d in ds);pool[arm]=statistics.median(d['mibps'] for d in ds)
pooled=json.load(open(root/'confirmation-30/pooled-all-57.json'));close(pool['high']/pool['baseline'],pooled['ratio']);assert pooled['passed']==(pooled['ratio']>=.98)
sm=medians('source-only',['old-baseline','old-high','fixed-baseline','fixed-high'],12,512);ss=json.load(open(root/'source-only/summary.json'))
for arm,value in sm.items():
 close(value,ss['medians'][arm])
 for i in range(12):
  d=json.load(open(root/f'source-only/{arm}-{i}.json'));assert '--copy' not in d['command'] and d['operations']==64 and len(d['events'])==64 and all(e['bytes']==8388608 for e in d['events'])
close(sm['old-high']/sm['old-baseline'],ss['old_ratio']);close(sm['fixed-high']/sm['fixed-baseline'],ss['fixed_ratio']);assert ss['diagnostic_only']
controls={}
def readiness(folder,labels):
 groups=collections.defaultdict(list)
 for line in (root/folder/'readiness.jsonl').read_text().splitlines():
  row=json.loads(line);groups[row['label']].append(row)
 assert set(groups)==set(labels)
 for group in groups.values():assert len(group)>=2 and all(v['Dirty']<=16384 and v['Writeback']==0 and v['inflight']==0 for v in group[-2:])
 return len(groups)
for folder,size in [('cifs-absolute',512),('hdfs-nfs-absolute',128)]:
 arms=['old-high','fixed-high','fixed-baseline'];med=medians(folder,arms,12,size);cs=json.load(open(root/folder/'summary.json'))
 for arm,v in med.items():close(v,cs['medians'][arm])
 close(med['fixed-high']/med['old-high'],cs['ratio']);close(med['fixed-high']/med['fixed-baseline'],cs['fixed_high_to_fixed_baseline']);assert cs['passed']==(cs['ratio']>=.98) and cs['relative_passed']==(cs['fixed_high_to_fixed_baseline']>=.98)
 cs['readiness_preconditions_independently_verified']=readiness(folder,[f'{a}-{i}' for a in arms for i in range(12)]);controls[folder]=cs
ls=json.load(open(root/'local-nfs-cold/summary.json'));ratios={}
for arm in ['old','fixed']:
 ds=[json.load(open(root/f'local-nfs-cold/{arm}-{i}.json')) for i in range(5)];assert all(d['bytes']==128*1048576 and d['command'][d['command'].index('--soft-bytes')+1]=='8388608' and d['command'][d['command'].index('--hard-bytes')+1]=='8388608' for d in ds);ratios[arm]=statistics.median(d['bytes']/d['seconds']/8388608 for d in ds);close(ratios[arm],ls['end_to_end_ratio_medians'][arm])
close(ratios['fixed']/ratios['old'],ls['fixed_to_old_ratio']);assert ls['absolute_non_regression_passed']==(ls['fixed_to_old_ratio']>=.98);readiness('local-nfs-cold',[f'{a}-{i}' for a in ['old','fixed'] for i in range(5)])
for label in ['baseline-stage','high-stage','high-admission']:
 d=json.load(open(root/f'cifs-attribution/{label}.json'));assert d['bytes']==512*1048576 and d['operations']==512 and d['effective_read_bytes']==1048576
probe=(root/'cifs-attribution/high-admission.stderr').read_text();assert 'calls=512 waits=0 admission_ns=424188' in probe
for label in ['baseline-stage','high-stage']:
 probe=(root/f'cifs-attribution/{label}.stderr').read_text();assert 'chunks=512' in probe and 'parts=64 size=8388608' in probe
readiness('cifs-attribution',['baseline-stage','high-stage','high-admission'])
out.update(independent_30_pair_confirmation=conf,pooled_57_pair_posthoc=pooled,source_only_diagnostic=ss,absolute_controls=controls,local_nfs_cold_control=ls,cifs_attribution_operations_and_zero_wait_verified=True)
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2));print('Independent 30-pair, all-57 posthoc, source-only and absolute controls verified; relative CIFS failure retained')
