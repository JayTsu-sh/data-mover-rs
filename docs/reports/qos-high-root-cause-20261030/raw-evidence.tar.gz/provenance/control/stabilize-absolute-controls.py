import json,paramiko,shlex
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
stop='''from pathlib import Path
import os,signal
r=Path.cwd();assert not (r/'cifs-absolute').exists() and not (r/'hdfs-nfs-absolute').exists() and not (r/'local-nfs-cold').exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if Path(os.readlink(p/'cwd'))!=r:continue
  if (p/'cmdline').read_bytes().split(b'\\0')[:2] in [[b'python3',n] for n in [b'cifs-absolute.py',b'hdfs-nfs-absolute.py',b'local-nfs-cold.py']]:os.kill(int(p.name),signal.SIGTERM)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
'''
_,o,e=c.exec_command('cd '+r+' && python3 -c '+shlex.quote(stop));assert o.channel.recv_exit_status()==0
settle='''from pathlib import Path
import json,time,subprocess,shlex
SNAPSHOT="from pathlib import Path;import json;v={s.split(':')[0]:int(s.split(':')[1].split()[0]) for s in Path('/proc/meminfo').read_text().splitlines() if s.split(':')[0] in ['Dirty','Writeback']};v['inflight']=sum(map(int,Path('/sys/block/sda/inflight').read_text().split()));print(json.dumps(v))"
def settle_target(log_path,label):
 deadline=time.monotonic()+180;quiet=0
 while time.monotonic()<deadline:
  result=subprocess.run(['ssh','-i','/home/github-runner/.ssh/terrasync_lab','-o','BatchMode=yes','-o','ConnectTimeout=5','root@10.131.9.13','python3 -c '+shlex.quote(SNAPSHOT)],capture_output=True,text=True,timeout=10)
  assert result.returncode==0,'read-only target readiness check failed'
  v=json.loads(result.stdout);v.update(label=label,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));quiet=quiet+1 if v['Dirty']<=16384 and v['Writeback']==0 and v['inflight']==0 else 0
  with log_path.open('a') as log:log.write(json.dumps(v)+'\\n')
  if quiet>=2:return
  time.sleep(.5)
 raise RuntimeError('target failed to reach predeclared idle state in 180s; no performance verdict allowed')
'''
with s.file(r+'/target_settle.py','w') as f:f.write(settle)
script='''from pathlib import Path
import json,time,subprocess,os,random,statistics,hashlib
from qos_evidence import redact,secret_values
from target_settle import settle_target
r=Path.cwd();name='PROFILE';folder=r/'FOLDER'
while not (r/'WAIT/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']==name);env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder.mkdir();arms=['old-high','fixed-high','fixed-baseline'];values={a:[] for a in arms};rng=random.Random(SEED);order=[]
for cycle in range(4):
 base=arms.copy();rng.shuffle(base);cycle_order=[base[i:]+base[:i] for i in range(3)];rng.shuffle(cycle_order);order.extend(cycle_order)
(folder/'plan.json').write_text(json.dumps({'blocks':12,'size_mib':SIZE,'order':order,'seed':SEED,'threshold':.98,'binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','capture-bin']},'precondition':'before each arm target VM13 Dirty<=16MiB, Writeback=0, sda inflight=0 on two half-second-spaced snapshots; max180s; no sync or server setting change'},indent=2))
for i,block in enumerate(order):
 for arm in block:
  settle_target(folder/'readiness.jsonl',arm+'-'+str(i))
  cmd=[str(r/('qos-bin' if arm=='old-high' else 'capture-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination'/name),'--path','SIZE.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm.endswith('high'):cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'absolute control failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));values[arm].append(d['mibps']);print(name,arm,i,d['mibps'],flush=True)
med={k:statistics.median(v) for k,v in values.items()};ratio=med['fixed-high']/med['old-high'];relative=med['fixed-high']/med['fixed-baseline'];d={'medians':med,'ratio':ratio,'passed':ratio>=.98,'fixed_high_to_fixed_baseline':relative,'relative_passed':relative>=.98,'blocks':12,'target_readiness_controlled':True};(folder/'summary.json').write_text(json.dumps(d,indent=2));(folder/'complete.json').write_text(json.dumps(d));print('Readiness-controlled absolute comparison',d,flush=True)
'''
for profile,folder,wait,size,seed in [('cifs-to-s3','cifs-absolute','source-only',512,202610303),('hdfs-to-nfs41','hdfs-nfs-absolute','cifs-absolute',128,202610304)]:
 v=script.replace('PROFILE',profile).replace('FOLDER',folder).replace('WAIT',wait).replace('SIZE',str(size)).replace('SEED',str(seed))
 with s.file(r+'/'+folder+'.py','w') as f:f.write(v)
v=s.open(r+'/local-nfs-cold.py').read().decode().replace('from qos_evidence import redact,secret_values','from qos_evidence import redact,secret_values\nfrom target_settle import settle_target').replace(" for arm in pair:\n  cmd=", " for arm in pair:\n  settle_target(folder/'readiness.jsonl',arm+'-'+str(i))\n  cmd=")
with s.file(r+'/local-nfs-cold.py','w') as f:f.write(v)
for name in ['cifs-absolute.py','hdfs-nfs-absolute.py','local-nfs-cold.py']:
 _,o,e=c.exec_command('cd '+r+' && nohup python3 '+name+' >'+name+'.log 2>&1 </dev/null &')
print('Before first sample: revised two unexpected-path controls to 12 random balanced blocks with old-high/new-high/new-baseline; each arm waits for read-only, identical VM13 readiness precondition. Local/NFS cold control uses same guard.');s.close();c.close()
