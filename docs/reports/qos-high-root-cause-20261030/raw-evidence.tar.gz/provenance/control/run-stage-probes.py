from pathlib import Path
import json,paramiko
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('/work/qos-high-stage-probe',r+'/stage-probe');s.chmod(r+'/stage-probe',0o700)
script='''from pathlib import Path
import json,time,subprocess,os,re,statistics,resource,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'reproduce-status.json').exists():time.sleep(1)
cfg=json.load(open('repro.private.json'));folder=r/'stage-probes';folder.mkdir();secrets=secret_values([p['env'] for p in cfg['profiles']]);rows=[]
for p in cfg['profiles']:
 name=p['name'];env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};(folder/name).mkdir()
 cmd=[str(r/'stage-probe'),'--source',str(r/'fixtures'),'--destination',str(r/'destination'/name),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile',p['transfer_profile'],'--destination-cleanup','delete','--idle-ms','1000']
 for i in range(5):
  for arm in (['baseline','high'] if i%2==0 else ['high','baseline']):
   extra=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled'] if arm=='high' else []
   before=resource.getrusage(resource.RUSAGE_CHILDREN);result=subprocess.run(cmd+extra,env=env,capture_output=True,text=True,timeout=180);after=resource.getrusage(resource.RUSAGE_CHILDREN);(folder/name/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,name+' failed; inspect redacted stderr';data=json.loads(result.stdout);data['command']=cmd+extra;data['resources']={f:getattr(after,f)-getattr(before,f) for f in ['ru_utime','ru_stime','ru_nvcsw','ru_nivcsw','ru_inblock','ru_oublock']};(folder/name/f'{arm}-{i}.json').write_text(json.dumps(data));phases=[dict(re.findall(r'(\\w+)=(\\S+)',line)) for line in result.stderr.splitlines() if '[HIGH-PROBE]' in line];rows.append(dict(profile=name,arm=arm,repeat=i,seconds=data['seconds'],mibps=data['mibps'],resources=data['resources'],phases=phases));(folder/'summary.json').write_text(json.dumps(rows,indent=2));print(name,arm,i,data['mibps'],phases,flush=True)
(folder/'status.json').write_text(json.dumps({'completed':len(rows),'binary_sha256':hashlib.sha256((r/'stage-probe').read_bytes()).hexdigest(),'diagnostic_only':True}))
'''
with s.file(r+'/run-stage-probes.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 run-stage-probes.py >stage-probes.log 2>&1 </dev/null &');print('5-pair stage probes queued serially after original reproduction');s.close();c.close()
