import json,paramiko
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
# The regression controller is still waiting for matched results; restart only that idle controller.
script='''import pathlib,os,signal
r=pathlib.Path.cwd();assert not (r/'regression').exists()
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if pathlib.Path(os.readlink(p/'cwd'))!=r:continue
  args=(p/'cmdline').read_bytes().split(b'\\0')
  if args[:2]==[b'python3',b'regression-shared.py']:os.kill(int(p.name),signal.SIGTERM)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
'''
import shlex
_,o,e=c.exec_command('cd '+r+' && python3 -c '+shlex.quote(script));assert o.channel.recv_exit_status()==0
v=s.open(r+'/regression-shared.py').read().decode().replace("while not (r/'matched-shared/status.json').exists():time.sleep(1)","while not (r/'matched-shared/status.json').exists() or not (r/'socket-check/status.json').exists():time.sleep(1)")
with s.file(r+'/regression-shared.py','w') as f:f.write(v)
script='''from pathlib import Path
import json,time,subprocess,os,re
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'matched-shared/status.json').exists():time.sleep(1)
p=next(p for p in json.load(open('repro.private.json'))['profiles'] if p['name']=='s3-to-hdfs');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'socket-check';folder.mkdir();rows=[]
for binary in ['qos-bin','shared-bin']:
 for arm in ['baseline','high']:
  trace=folder/f'{binary}-{arm}.connect';cmd=[str(r/binary),'--source',str(r/'fixtures'),'--destination',str(r/'destination/s3-to-hdfs'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
  if arm=='high':cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(['strace','-f','-ttt','-T','-e','trace=connect','-o',str(trace),*cmd],env=env,capture_output=True,text=True,timeout=180);(folder/f'{binary}-{arm}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'socket diagnostic copy failed';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{binary}-{arm}.json').write_text(json.dumps(d));lines=[line for line in trace.read_text().splitlines() if 'connect(' in line and 'htons(9000)' in line and '10.10.1.12' in line];rows.append({'binary':binary,'arm':arm,'s3_tcp_connection_attempts':len(lines),'diagnostic_only':True});print(rows[-1],flush=True)
(folder/'summary.json').write_text(json.dumps(rows,indent=2));(folder/'status.json').write_text(json.dumps({'completed':4,'scope':'actual connect syscalls; metadata and payload combined; instrumented timing excluded from qualification'}))
'''
with s.file(r+'/socket-check.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 socket-check.py >socket-check.log 2>&1 </dev/null &');_,o,e=c.exec_command('cd '+r+' && nohup python3 regression-shared.py >regression-shared.log 2>&1 </dev/null &');print('Actual connect-syscall diagnostic queued after matched benchmark and before all broad regression, no performance overlap');s.close();c.close()
