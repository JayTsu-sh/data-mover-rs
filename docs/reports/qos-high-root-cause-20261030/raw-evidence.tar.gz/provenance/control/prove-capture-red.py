from pathlib import Path
import subprocess,hashlib
p=Path('crates/backend-s3/src/backend/client/qos_client.rs');before=p.read_bytes();s=before.decode();old='''    if let Some(http) = capture.0.get() {
        config.set_http_client(Some(http.clone()));
    }
''';assert s.count(old)==1;s=s.replace(old,'');p.write_text(s);mutated=hashlib.sha256(p.read_bytes()).hexdigest()
try:
 with open('/work/qos-high-capture-pool-red.log','w') as log:r=subprocess.run(['cargo','test','--locked','-p','data-mover-backend-s3','--lib','source_qos_reuses_the_metadata_and_payload_connection_pool','--','--nocapture'],stdout=log,stderr=subprocess.STDOUT)
 log=Path('/work/qos-high-capture-pool-red.log').read_text();assert r.returncode!=0 and 'left: 2' in log and 'right: 1' in log
 print('Final pool regression catches omitted runtime transport: 2 connections, expected 1')
finally:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==mutated;p.write_bytes(before)
