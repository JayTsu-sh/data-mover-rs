import json,paramiko
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
# Reuse already built, separate diagnostic executables; production remains the accepted hash.
s.stat('/tmp/nightly-qos-cross-20261029192047/admission-probe')
_,o,e=c.exec_command('cp /tmp/nightly-qos-cross-20261029192047/admission-probe '+r+'/admission-probe');assert o.channel.recv_exit_status()==0
script='''from pathlib import Path
import json,time,subprocess,os,re,hashlib
from qos_evidence import redact,secret_values
from target_settle import settle_target
r=Path.cwd()
while not (r/'local-nfs-cold/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']=='cifs-to-s3');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'cifs-attribution';folder.mkdir();rows=[]
for label,binary,limited in [('baseline-stage','stage-probe',False),('high-stage','stage-probe',True),('high-admission','admission-probe',True)]:
 settle_target(folder/'readiness.jsonl',label)
 cmd=[str(r/binary),'--source',str(r/'fixtures'),'--destination',str(r/'destination/cifs-to-s3'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000']
 if limited:cmd+=['--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
 result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/(label+'.stderr')).write_text(redact(result.stderr,secrets));assert result.returncode==0,'CIFS attribution copy failed';d=json.loads(result.stdout);d['command']=cmd;(folder/(label+'.json')).write_text(json.dumps(d));rows.append({'label':label,'seconds':d['seconds'],'mibps':d['mibps'],'reported_cap':d['effective_read_bytes'],'operations':d['operations'],'probes':[line for line in result.stderr.splitlines() if '[HIGH-PROBE]' in line or '[QOS-PROBE]' in line],'diagnostic_only':True,'binary_sha256':hashlib.sha256((r/binary).read_bytes()).hexdigest()});print(rows[-1],flush=True)
(folder/'summary.json').write_text(json.dumps(rows,indent=2));(folder/'complete.json').write_text(json.dumps({'samples':3,'purpose':'check actual producer chunk count, source/target wait and nonbinding admission waits; not a qualification study'}))
'''
with s.file(r+'/cifs-attribution.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 cifs-attribution.py >cifs-attribution.log 2>&1 </dev/null &');print('Three separate-binary CIFS attribution copies queued; actual chunk counts and admission waits will distinguish payload-size constraints from sink variability.');s.close();c.close()
