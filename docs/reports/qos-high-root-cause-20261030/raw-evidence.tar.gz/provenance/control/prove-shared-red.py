from pathlib import Path
import subprocess,hashlib
p=Path('crates/backend-s3/src/backend/client.rs');before=p.read_bytes();s=before.decode();a=s.index('    // Resolve the SDK default once into the stored configuration.');b=s.index('    configure_compatibility(builder, compatibility).build()',a);s=s[:a]+s[b:];p.write_text(s);mutated=hashlib.sha256(p.read_bytes()).hexdigest()
try:
 with open('/work/qos-high-shared-pool-red.log','w') as log:r=subprocess.run(['cargo','test','--locked','-p','data-mover-backend-s3','--lib','source_qos_reuses_the_metadata_and_payload_connection_pool','--','--nocapture'],stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode!=0
 log=Path('/work/qos-high-shared-pool-red.log').read_text();assert 'left: 2' in log and 'right: 1' in log,'failure did not reproduce the pool bug'
 print('Final regression test reproduces two connections without the shared-default fix')
finally:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==mutated
 p.write_bytes(before)
