from pathlib import Path
import json,paramiko,hashlib
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();binary=Path('/work/cargo-target/release/examples/backend_qos_acceptance');s.put(str(binary),r+'/shared-bin');s.chmod(r+'/shared-bin',0o700);s.put('/work/cargo-target/release/examples/backend_qos_cleanup',r+'/cleanup-bin');s.chmod(r+'/cleanup-bin',0o700)
v=s.open(r+'/matched.py').read().decode().replace("folder=r/'matched'","folder=r/'matched-shared'").replace("'fixed-bin'","'shared-bin'")
with s.file(r+'/matched-shared.py','w') as f:f.write(v)
v=s.open(r+'/regression.py').read().decode().replace("r/'matched/status.json'", "r/'matched-shared/status.json'").replace("'fixed-bin'", "'shared-bin'")
with s.file(r+'/regression-shared.py','w') as f:f.write(v)
try:s.rename(r+'/regression-blocked.json',r+'/regression-blocked-operation-override.json')
except FileNotFoundError:pass
_,o,e=c.exec_command('cd '+r+' && nohup python3 matched-shared.py >matched-shared.log 2>&1 </dev/null &');_,o,e=c.exec_command('cd '+r+' && nohup python3 regression-shared.py >regression-shared.log 2>&1 </dev/null &');print('Shared-pool binary',hashlib.sha256(binary.read_bytes()).hexdigest(),'deployed; new 12-block matched qualification launched, broad regression waits for its gates.');s.close();c.close()
