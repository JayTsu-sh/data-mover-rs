import json,paramiko,shlex
from pathlib import Path
x=json.load(open('.scratch/qos-high/remote.json'));assert x['root']=='/tmp/nightly-qos-high-20261029234234';c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10)
script='''from pathlib import Path
import json
r=Path.cwd();assert r.name=='nightly-qos-high-20261029234234';private=list(r.rglob('*.private.json'));caches=[p for p in r.rglob('*') if p.is_file() and (p.name.startswith('krb5cc') or p.name.endswith('.ccache'))]
for p in private+caches:assert p.resolve().is_relative_to(r.resolve());p.unlink()
remaining=list(r.rglob('*.private.json'))+[p for p in r.rglob('*') if p.is_file() and (p.name.startswith('krb5cc') or p.name.endswith('.ccache'))]
assert not remaining
result={'private_configs_removed':len(private),'ticket_caches_removed':len(caches),'remaining_private_configs_or_ticket_caches':len(remaining),'scope':'only this isolated run directory; shared keytabs/services unchanged','data_fixture_directories_remaining':[str(p.relative_to(r)) for p in [r/'fixtures',r/'source',r/'destination',r/'pressure/fixtures',r/'pressure/destination',r/'warm-destination'] if p.exists()]};assert not result['data_fixture_directories_remaining'];(r/'private-cleanup.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
'''
_,o,e=c.exec_command('cd '+shlex.quote(x['root'])+' && python3 -c '+shlex.quote(script));out=o.read().decode();code=o.channel.recv_exit_status();assert code==0,'Private cleanup failed';result=json.loads(out);print(json.dumps(result));Path('/work/qos-high-evidence/private-cleanup.json').write_text(json.dumps(result,indent=2));Path('docs/reports/qos-high-root-cause-20261030/private-cleanup.json').write_text(json.dumps(result,indent=2));c.close()
