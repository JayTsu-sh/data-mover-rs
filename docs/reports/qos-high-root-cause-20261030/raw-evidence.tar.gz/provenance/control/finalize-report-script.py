from pathlib import Path
p=Path('.scratch/qos-high/write-report.py');s=p.read_text()
s=s.replace('最终 23 路高 QoS 判定通过', 'S3→HDFS 的主矩阵 15 组结果仍为 **97.969%，未通过**；随后独立预定的 30 组原尺寸复验为 **99.928%，通过**。后者不覆盖前者。CIFS→S3 的额外对照仍观察到相对同版基准 **91.637%，未通过**，但新版高 QoS 相对原版高 QoS为 **101.700%**，未观察到本次修复引入的绝对性能下降。\n\n最终 23 路高 QoS 判定通过')
s=s.replace('原失败 94.822% 的全部差额没有历史分阶段服务端日志，', '另外用保留最大源并发的独立 source-only 诊断二进制，去掉 HDFS 写入和关闭，完成同样 512 MiB 的 12 区组、48 次完整哈希读取：原版高 QoS / 原版基准 **100.400%**，修复版 **100.497%**，每次仍为 64 个 8 MiB payload。**原版也没有稳定的源读取吞吐退化，所以不能把旧的 5.18% 差额全部归因连接池。** 原版分阶段五组中 HDFS close 中位数为无 QoS 148.47 ms、高 QoS 162.81 ms；完整复制还包含冷启动、目标消费、关闭和发布的波动。source-only 只用于归因，未代替复制验收。\n\n原失败 94.822% 的全部差额没有历史分阶段服务端日志，')
s=s.replace('随后有限配额最多四路并行。', '随后主矩阵有限配额最多四路并行；第 4 节固定配额补测另对共享目标物理盘串行隔离。')
s=s.replace('四路并发与上轮有限配额一致。','最多四个 worker，但经只读布局核验，目标 S3 `/data/rustfs0` 与 NFSv4.1 `/srv/nfs/v4` 位于同一设备（`st_dev=2049`，`/dev/sda1` ext4）；固定配额补测在第一条测量前对这两个目标增加共享物理卷锁，其他目标可并行。**并发拓扑与旧主矩阵不同**，这项结果说明隔离条件下的同配额兼容性，不能单独视作只改变代码的因果对照。计划见 `fixed-limits/plan.json`，布局/负载见 `target-storage-layout.log`、`target-load.log`。')
anchor='## 5. 自动化、证据和剩余边界'
extra='''## 5. 原尺寸独立确认与异常项直接对照

所有正式补测仍使用最终普通二进制，保持相同请求 cap、并发、复制策略及完整目标读回。S3→HDFS 独立 30 组的随机 AB/BA 顺序和种子 202610301 在开测前写入计划，每次同等空闲 1 秒，性能阶段串行。

| S3→HDFS，512 MiB | 无 QoS 中位 MiB/s | 高 QoS 中位 MiB/s | 比例 | 判定 |
|---|---:|---:|---:|---|
| 主矩阵 15 组 | 253.471 | 248.323 | 97.969% | **未通过，保留** |
| 独立确认 30 组 | 282.549 | 282.345 | 99.928% | 通过 |
| 所有合格正式样本合并，57 组 | 见原始样本 | 见原始样本 | 99.199% | 仅事后敏感性分析 |

57 组包含最终候选的 12 区组、主矩阵 15 组以及确认 30 组，没有删除失败组；合并结果不是又一次独立确认。详见 [独立确认与合并说明](confirmation.json)、[源读取诊断](source-only.json)。

对主矩阵另外三项异常，执行旧版/新版直接对照。CIFS→S3 与 HDFS→NFSv4.1 分别为 12 个随机均衡的三臂区组，每次开始前在目标 VM13 连续两次、间隔约 0.5 秒确认 Dirty≤16 MiB、Writeback=0、磁盘 inflight=0；最多等 180 秒，没有执行 sync、清缓存或改服务设置。Local→NFSv4.1 为 5 对，保持原 128 MiB、soft=hard=8 MiB/s 严格配额。所有 readiness 快照与计划均入档。

| 路径及用例 | 新版高 / 旧版高（或同配额） | 新版高 / 新版基准 | 结论 |
|---|---:|---:|---|
| CIFS→S3 高 QoS，512 MiB | 101.700% | **91.637%** | 未观察到本次引入的绝对回退；相对 98% 门槛仍未通过 |
| HDFS→NFSv4.1 高 QoS，128 MiB | 102.426% | 104.953% | 直接对照通过，主矩阵失败保留 |
| Local→NFSv4.1 严格带宽，128 MiB | 100.004% | 不适用 | 旧/新版端到端配额达成率分别 99.047% / 99.051% |

Local→NFSv4.1 主矩阵失败样本的首准入延迟约 271 ms，补测约 58～65 ms，尾段仍约 80～100 ms。这条路径不经过本次修改的 S3 模块；冷初始化与目标等待足以影响 16 秒理想时长的短文件端到端比例。[全部直接对照](absolute-controls.json) 保留原始中位数和失败标记。

CIFS→S3 的相对缺口仍需单列：两版高 QoS 直接对照无新增下降，尚未证明唯一、稳定的代码根因。额外三次旧版诊断确认 producer 实际均为 **512×1 MiB**，目标均为 **64×8 MiB MPU**，排除了无 QoS 仅按大块估算操作数导致的比较误读。高 QoS 准入 512 次、限速等待 0 次、累计 0.424 ms；发送队列等待约 13.3 秒，源等待读取约 2.1～2.5 秒，目标背压占主要耗时。诊断轮基准 28.855 MiB/s、高 QoS 30.800 MiB/s，方向发生反转，提示明显目标波动；**这些诊断不能用来撤销三臂正式对照的 91.637% 失败，也不足以宣称剩余缺口已经修复。**

## 6. 自动化、证据和剩余边界'''
assert anchor in s;s=s.replace(anchor,extra)
s=s.replace('三轮 12 区组对照和真实 TCP connect 次数','三轮 12 区组对照、独立 30 组确认、57 组事后合并、source-only/三臂/固定配额控制及真实 TCP connect 次数')
s=s.replace('[隔离清理](cleanup.json)、[附件 SHA-256]', '[隔离清理](cleanup.json)、[私有配置清理](private-cleanup.json)、[归档凭据与逐文件审计](archive-audit.json)、[附件 SHA-256]')
s += "\n(out/'confirmation.json').write_text(json.dumps({'independent_30_pair':audit['independent_30_pair_confirmation'],'posthoc_57_pair':audit['pooled_57_pair_posthoc']},indent=2))\n(out/'source-only.json').write_text(json.dumps(audit['source_only_diagnostic'],indent=2))\n(out/'absolute-controls.json').write_text(json.dumps({'controls':audit['absolute_controls'],'local_nfs':audit['local_nfs_cold_control']},indent=2))\n"
p.write_text(s)
