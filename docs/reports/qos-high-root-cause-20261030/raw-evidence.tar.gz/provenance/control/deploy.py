import pathlib,json,shlex,paramiko,datetime
run='nightly-qos-high-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S');root='/tmp/'+run
c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect('10.131.9.11',username='root',timeout=10);s=c.open_sftp();s.mkdir(root,mode=0o700)
for src,name in [('/work/cargo-target/release/examples/backend_qos_acceptance','qos-bin'),*[(f'tests/lab/{name}',name) for name in ['run-backend-qos.py','run-local-qos.py','run-cross-backend-qos.py','cross_qos_matrix.py','common.sh','prepare-run.sh','s3_helper.py','qos_evidence.py']]]:
 s.put(src,root+'/'+name);s.chmod(root+'/'+name,0o700)
_,o,e=c.exec_command(f'bash -c \'set -euo pipefail; cd {root}; source ./common.sh; require_s3_credentials; ./prepare-run.sh {run}\'',timeout=50);out=o.read().decode();err=e.read().decode();code=o.channel.recv_exit_status()
with s.file(root+'/prepare.log','w') as f:f.write(out+err)
assert code==0,'isolated lab preparation failed'
_,o,e=c.exec_command("ssh -i /home/github-runner/.ssh/terrasync_lab -o BatchMode=yes -o ConnectTimeout=5 root@10.131.9.12 '. /etc/default/rustfs; printf \"%s\\n%s\\n\" \"$RUSTFS_ACCESS_KEY\" \"$RUSTFS_SECRET_KEY\"'",timeout=15);keys=o.read().decode().splitlines();assert len(keys)==2
cifs={}
for line in pathlib.Path('.claude/skills/e2e-cifs/.env').read_text().splitlines():
 if line and not line.startswith('#') and '=' in line:
  k,v=line.split('=',1);values=shlex.split(v)
  if values and k in ['CIFS_REAL_SERVER','CIFS_REAL_SHARE','CIFS_REAL_USER','CIFS_REAL_PASS']:cifs[k]=values[0]
hdfs={'LAB_HDFS_CONFIG_DIR':'/var/lib/data-mover-lab/hadoop','LAB_HDFS_KEYTAB':'/var/lib/data-mover-lab/terrasync-runner.keytab','KRB5CCNAME':'FILE:'+root+'/invalid.ccache'}
hdfs_base='hdfs://hdfs%2Fterrasync-runner%40HDFS.LOCAL@hdfs-ha/tmp/data-mover-nightly/'+run+'/hdfs'
sources={
 'local':{'env':{'QOS_SOURCE':root+'/source'}},
 'nfs3':{'env':{'QOS_SOURCE':f'nfs://10.10.1.12/srv/nfs/v3:/ci/{run}?version=3&noresvport=true'}},
 'nfs40':{'env':{'QOS_SOURCE':f'nfs://10.131.7.201/jay_nfs:/{run}?version=4.0&noresvport=true&uid=0&gid=0'}},
 'nfs41':{'env':{'QOS_SOURCE':f'nfs://10.10.1.12/srv/nfs/v4:/ci/{run}?version=4.1&noresvport=true'}},
 'cifs':{'env':{'QOS_SOURCE':f'smb:{run}/source',**cifs}},
 's3':{'env':{'QOS_SOURCE':f's3:ci/{run}/source','S3_HOST':'10.10.1.12:9000','S3_BUCKET':'terrasync-ci','S3_AK':keys[0],'S3_SK':keys[1]}},
 'hdfs':{'env':{'QOS_SOURCE':hdfs_base+'/source',**hdfs}},
}
destinations={
 'local':{'endpoint':root+'/destination/{pair}'},
 'nfs41':{'endpoint':f'nfs://10.10.1.13/srv/nfs/v4:/ci/{run}/destination/{{pair}}?version=4.1&noresvport=true'},
 'cifs':{'endpoint':f'smb:{run}/destination/{{pair}}','env':cifs},
 's3':{'endpoint':f's3://{keys[0]}:{keys[1]}@terrasync-ci.10.10.1.13:9000/ci/{run}/destination/{{pair}}'},
 'hdfs':{'endpoint':hdfs_base+'/destination/{pair}','env':hdfs},
}
with s.file(root+'/endpoints.private.json','w') as f:f.write(json.dumps({'run_id':run,'sources':sources,'destinations':destinations}))
s.chmod(root+'/endpoints.private.json',0o600)
pathlib.Path('.scratch/qos-high/remote.json').write_text(json.dumps({'root':root,'run_id':run,'host':'10.131.9.11'}))
cmd=f'cd {root} && nohup python3 run-cross-backend-qos.py --config endpoints.private.json --root {root} --binary {root}/qos-bin --stage warmup >warmup.log 2>&1 </dev/null &'
_,o,e=c.exec_command(cmd,timeout=10);print('Prepared new isolated run; real 23-route warmup started:',run);s.close();c.close()
