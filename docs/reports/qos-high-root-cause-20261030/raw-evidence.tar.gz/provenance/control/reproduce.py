from pathlib import Path
import json,paramiko
x=json.load(open('.scratch/qos-high/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,time,subprocess
r=Path.cwd()
while not (r/'warmup-checks.json').exists() or len(json.load(open(r/'warmup-checks.json')))<23:time.sleep(1)
cfg=json.load(open('matrix.private.json'));cfg['profiles']=[p for p in cfg['profiles'] if p['name'] in ['nfs41-to-s3','s3-to-hdfs']]
for p in cfg['profiles']:p['performance_size_mib']=512
private=r/'repro.private.json';private.write_text(json.dumps(cfg));private.chmod(0o600)
cmd=['python3','run-backend-qos.py','--config',str(private),'--root',str(r),'--binary',str(r/'qos-bin'),'--phase','survey','--repeats','10','--performance-idle-ms','1000','--retain-source','--output',str(r/'reproduce')]
with (r/'reproduce.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
(r/'reproduce-status.json').write_text(json.dumps({'exit':code,'command':cmd}));print('reproduction exit',code,flush=True)
'''
with s.file(x['root']+'/reproduce.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+x['root']+' && nohup python3 reproduce.py >reproduce-controller.log 2>&1 </dev/null &');print('512 MiB, original binary, 10 alternating pairs per route, equal 1 s idle launched; >=98% assertion retained');s.close();c.close()
