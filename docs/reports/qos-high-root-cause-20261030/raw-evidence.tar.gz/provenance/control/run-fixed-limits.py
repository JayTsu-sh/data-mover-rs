import json,paramiko
from pathlib import Path
oldroot=Path('/work/qos-cross-evidence/raw');previous=json.load(open('docs/reports/qos98-cross-backends-20261030/checks.json'));reference=[]
for name in json.load(open('docs/reports/qos98-cross-backends-20261030/summary.json')):
 if not (name.startswith('s3-to-') or name.endswith('-to-s3')):continue
 for case in ['bandwidth-strict','bandwidth-dual','iops-strict','iops-dual','combined']:
  d=json.load(open(oldroot/'limits'/name/name/(case+'.json')));reference.append(dict(profile=name,case=case,command=d['command'],old_checks=[g for g in previous if g['profile']==name and g['case']==case]))
assert len(reference)==40
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
with s.file(r+'/fixed-limits-reference.json','w') as f:f.write(json.dumps(reference,indent=2))
script='''from pathlib import Path
import json,time,subprocess,concurrent.futures,os,importlib.util
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'regression/complete.json').exists():time.sleep(1)
spec=importlib.util.spec_from_file_location('validator',r/'run-local-qos.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
profiles={p['name']:p for p in json.load(open('matrix.private.json'))['profiles']};reference=json.load(open('fixed-limits-reference.json'));folder=r/'fixed-limits';folder.mkdir();results=[]
def qualify(name):
 p=profiles[name];env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);(folder/name).mkdir();rows=[]
 for ref in reference:
  if ref['profile']!=name:continue
  case=ref['case'];cmd=[v.replace('/tmp/nightly-qos-cross-20261029192047',str(r)) for v in ref['command']];cmd[0]=str(r/'capture-bin');result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/name/(case+'.stderr')).write_text(redact(result.stderr,secrets));assert result.returncode==0,name+'/'+case+' failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/name/(case+'.json')).write_text(json.dumps(d));peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';checks={}
  for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
   key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);trace=V.validate_trace(d,resource,soft,hard,peak,dual);prefix=resource+'_' if case=='combined' else '';actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];checks[prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent')]=actual>=soft*.98
   for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):checks[prefix+gate]=trace[gate]
  for old in ref['old_checks']:
   passed=checks[old['name']];rows.append(dict(profile=name,case=case,name=old['name'],old_passed=old['passed'],passed=passed,new_failure=old['passed'] and not passed))
  print(name,case,'fixed original quota',d['mibps'],flush=True)
 return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for rows in pool.map(qualify,sorted(profiles.keys() & {p['profile'] for p in reference})):results.extend(rows)
(folder/'checks.json').write_text(json.dumps(results,indent=2));(folder/'complete.json').write_text(json.dumps({'samples':40,'checks':len(results),'passed':sum(g['passed'] for g in results),'new_failures':sum(g['new_failure'] for g in results),'quotas_caps_peaks_policies_original':True},indent=2));print('Original fixed-limit regression complete',sum(g['new_failure'] for g in results),'new failed gates',flush=True)
'''
with s.file(r+'/run-fixed-limits.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 run-fixed-limits.py >fixed-limits.log 2>&1 </dev/null &');print('40-copy regression queued for all eight S3 endpoint routes, exact original finite quotas/caps/peaks and copy profiles; prevents baseline-derived quota changes from confounding regression comparison.');s.close();c.close()
