import json,paramiko
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''from pathlib import Path
import json,time,subprocess,os,random,statistics,hashlib
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'source-only/complete.json').exists():time.sleep(1)
p=next(p for p in json.load(open('regression.private.json'))['profiles'] if p['name']=='cifs-to-s3');env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);folder=r/'cifs-absolute';folder.mkdir();arms={'old-high':[],'fixed-high':[]};rng=random.Random(202610303);order=[['old-high','fixed-high']]*5+[['fixed-high','old-high']]*5;rng.shuffle(order)
(folder/'plan.json').write_text(json.dumps({'pairs':10,'size_mib':512,'order':order,'seed':202610303,'scope':'direct original/new absolute high-QoS comparison for unexpected CIFS-to-S3 survey failure','threshold':.98,'binaries':{b:hashlib.sha256((r/b).read_bytes()).hexdigest() for b in ['qos-bin','capture-bin']}},indent=2))
for i,pair in enumerate(order):
 for arm in pair:
  cmd=[str(r/('qos-bin' if arm=='old-high' else 'capture-bin')),'--source',str(r/'fixtures'),'--destination',str(r/'destination/cifs-to-s3'),'--path','512.bin','--chunk-bytes',str(p['chunk_bytes']),'--copy','--transfer-profile','cross','--destination-cleanup','delete','--idle-ms','1000','--soft-bytes',str(1024**4),'--hard-bytes',str(1024**4),'--soft-iops','1000000000','--hard-iops','1000000000','--admission-trace','disabled']
  result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/f'{arm}-{i}.stderr').write_text(redact(result.stderr,secrets));assert result.returncode==0,'CIFS control failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/f'{arm}-{i}.json').write_text(json.dumps(d));arms[arm].append(d['mibps']);print(arm,i,d['mibps'],flush=True)
med={k:statistics.median(v) for k,v in arms.items()};ratio=med['fixed-high']/med['old-high'];d={'medians':med,'ratio':ratio,'passed':ratio>=.98,'pairs':10};(folder/'summary.json').write_text(json.dumps(d,indent=2));(folder/'complete.json').write_text(json.dumps(d));print('Absolute CIFS control',ratio,flush=True)
'''
with s.file(r+'/cifs-absolute.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 cifs-absolute.py >cifs-absolute.log 2>&1 </dev/null &');print('10 randomized paired old/new high-QoS absolute comparisons queued for unexpected CIFS-to-S3 survey discrepancy; same 512MiB and caps, no background test overlap.');s.close();c.close()
