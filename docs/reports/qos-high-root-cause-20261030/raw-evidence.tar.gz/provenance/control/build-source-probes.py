from pathlib import Path
import subprocess,hashlib,shutil
paths=['tests/lab/tools/backend_qos_acceptance.rs','crates/backend-s3/src/backend/client.rs','crates/backend-s3/src/backend/client/role_protocol.rs'];original={p:Path(p).read_bytes() for p in paths};written={}
try:
 p=paths[0];s=original[p].decode();needle='                read_inflight: 1,\n                read_budget: None,';assert s.count(needle)==1;s=s.replace(needle,'                read_inflight: source.read_source()?.read_concurrency().max(1),\n                read_budget: None,');Path(p).write_text(s);written[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 with open('/work/qos-high-capture-source-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-high-capture-source-probe')
 for p,backup in zip(paths[1:],['client.before-fix.rs','role_protocol.before-fix.rs']):
  Path(p).write_bytes(Path('.scratch/qos-high/'+backup).read_bytes());written[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 with open('/work/qos-high-old-source-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-high-old-source-probe')
finally:
 for p in written:
  assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==written[p],p
  Path(p).write_bytes(original[p])
print('Two source-only diagnostic binaries built at full backend read concurrency; all source restored byte-for-byte')
with open('/work/qos-high-final-normal-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance','--example','backend_qos_cleanup'],stdout=f,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(Path('/work/cargo-target/release/examples/backend_qos_acceptance').read_bytes()).hexdigest()=='9b56c318e8547d358eadc4bbc05914cce34fc9a4683d784a869216905376e4dd'
print('Normal binary restored with exact accepted candidate SHA-256')
