from pathlib import Path
import json,statistics,shutil,hashlib
b=Path('/work/qos-high-evidence');r=b/'raw';out=Path('docs/reports/qos-high-root-cause-20261030');out.mkdir(parents=True,exist_ok=True)
summary=json.load(open(b/'summary.json'));checks=json.load(open(b/'checks.json'));fixed=json.load(open(r/'fixed-limits/complete.json'));same=json.load(open(r/'fixed-limits/checks.json'));audit=json.load(open(b/'evidence-audit.json'));m=json.load(open(r/'matched-capture/summary.json'));completed=json.load(open(r/'regression/complete.json'))
def pct(v):return f'{100*v:.3f}%'
def table(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','|'+'|'.join(['---']*len(head))+'|',*['| '+' | '.join(map(str,row))+' |' for row in rows]])
high=[g for g in checks if g['case']=='high'];focus=[next(g for g in high if g['profile']==name) for name in ['nfs41-to-s3','s3-to-hdfs']]
mainrows=[[name,s['performance_size_mib'],f"{s['baseline_mibps']:.3f}",pct(s['high_ratio']),'通过' if next(g for g in high if g['profile']==name)['passed'] else '**未通过**'] for name,s in sorted(summary.items())]
matched=[]
for folder,description in [('matched','逐 GET 配置覆盖，撤回'),('matched-shared','显式默认 transport，撤回'),('matched-capture','复用实际 transport，最终候选')]:
 d=json.load(open(r/folder/'summary.json'));g={g['name']:g for g in d['checks']};matched.append([description,pct(g['old_high_to_old_baseline']['ratio']),pct(g['fixed_high_to_fixed_baseline']['ratio']),pct(g['fixed_high_to_old_high']['ratio']),pct(g['fixed_baseline_to_old_baseline']['ratio'])])
failrows=[[g['profile'],g['case'],g['name'],pct(g['ratio']) if 'ratio' in g else '见 JSON'] for g in checks if not g['passed']]
newfixed=[[g['profile'],g['case'],g['name']] for g in same if g['new_failure']]
report=f'''# 两项高 QoS 失败：根因、修复与回归验证

日期：2026-10-30（Asia/Shanghai）。隔离 run：`nightly-qos-high-20261029234234`。

**确认并修复了 S3 高 QoS 读取丢失已建立 HTTP 连接池的问题。** 在相同 512 MiB、随机均衡的 12 个区组中，原版高 QoS / 原版基准为 95.878%，修复版为 **99.973%**；新版高 QoS / 原版高 QoS 为 **106.703%**，新版无 QoS / 原版无 QoS 为 **102.333%**。真实 TCP 连接数从高 QoS 的 3 个降至 2 个，与无 QoS 一致。

NFSv4.1→S3 的原失败没有复现为稳定的限速器退化：原版新隔离对照为 100.608%，分阶段探针显示源读约 0.36 秒，而写入背压约 11.9 秒；目标 VM 同时存在明确 I/O 等待。最终原尺寸 15 组复验为 **{pct(focus[0]['ratio'])}**。其主要问题是目标存储波动下的短样本归因，不能虚称修复了一个已证实的 NFS 调度缺陷。

S3→HDFS 的主矩阵 15 组结果仍为 **97.969%，未通过**；随后独立预定的 30 组原尺寸复验为 **99.928%，通过**。后者不覆盖前者。CIFS→S3 的额外对照仍观察到相对同版基准 **91.637%，未通过**，但新版高 QoS 相对原版高 QoS为 **101.700%**，未观察到本次修复引入的绝对性能下降。

最终 23 路高 QoS 判定通过 **{sum(g['passed'] for g in high)}/23**；主回归 **{sum(g['passed'] for g in checks)}/{len(checks)}** 项通过。八条涉及 S3 的路径另按上轮完全相同有限配额执行 40 次复制、{fixed['checks']} 项判定，新增失败 **{fixed['new_failures']}** 项。历史 strict 短文件不达标与本次新增失败分别列出，不声称覆盖全部文件、缓存及外部负载的绝对无回退保证。

## 1. 两项问题分别是什么

### S3→HDFS：克隆配置没有携带 SDK 的默认 HTTP client

原实现为保证每次 GET 重试重新扣带宽/IOPS，预构建一个关闭 SDK 自动重试的 client：`Client::from_conf(client.config().to_builder().retry_config(disabled).build())`。但 SDK 的默认 HTTP client 由 runtime plugin 注入，**并不保存在原 `Client::config()` 中**。因此克隆配置创建了另一套连接池。元数据/无 QoS GET 已建立的连接，QoS GET 无法复用；准入 trace 中的零等待无法看见这项传输层开销。

证据来自两种独立执行路径：

- 本地真实 TCP 回归测试执行 HEAD、普通 GET、HEAD、带 QoS GET；不依赖 mock 的连接数估计。移除 transport 复用后 **2 个连接、期望 1 个**，测试在约 0.06 秒内失败；恢复修复通过。HTTP 数据仍走真实 SDK 和公开 `ReadSource`。
- lab 的真实 512 MiB S3→HDFS 复制，`strace -f -e connect` 计数：原版无 QoS **2**、原版高 QoS **3**；修复版两者均 **2**。包含元数据与 payload 的 TCP connect，**不等同于 GET 次数**。带 strace 的耗时不参与性能通过判定。

修复只捕获并复用 SDK 运行时实际选中的 `SharedHttpClient`，在连接/元数据阶段完成；单次尝试 client 仍预构建，原来的默认 transport、TLS/代理选择、请求尺寸和并发均保留。显式自定义 transport 直接复用。逐次重试扣费、取消、对象版本/ETag 绑定不变，未增加免费首包或跳过 QoS。最终没有新增依赖、升级版本或修改 Cargo.lock。

实现见 [qos_client.rs](../../../crates/backend-s3/src/backend/client/qos_client.rs)、[连接初始化](../../../crates/backend-s3/src/backend/client.rs)、[GET 调用](../../../crates/backend-s3/src/backend/client/role_protocol.rs)、[真实 TCP 回归测试](../../../crates/backend-s3/src/backend/client/role_protocol/qos_pool_tests.rs)。

另外用保留最大源并发的独立 source-only 诊断二进制，去掉 HDFS 写入和关闭，完成同样 512 MiB 的 12 区组、48 次完整哈希读取：原版高 QoS / 原版基准 **100.400%**，修复版 **100.497%**，每次仍为 64 个 8 MiB payload。**原版也没有稳定的源读取吞吐退化，所以不能把旧的 5.18% 差额全部归因连接池。** 原版分阶段五组中 HDFS close 中位数为无 QoS 148.47 ms、高 QoS 162.81 ms；完整复制还包含冷启动、目标消费、关闭和发布的波动。source-only 只用于归因，未代替复制验收。

原失败 94.822% 的全部差额没有历史分阶段服务端日志，不能把每一毫秒都归因连接池；本次已确定独立可复现的代码缺陷，并在旧版再次失败的同一对照实验中验证修复，而非用延长文件或放宽 98% 阈值通过。

### NFSv4.1→S3：目标 I/O 瓶颈和抽样波动，源调度不是主导开销

同一原版二进制 `d7c04f…` 在新隔离环境，512 MiB、10 组交替对照为 **100.608%**；上轮无 QoS A/A 就有 107.412% 的组间比值。不能把一次 96.123% 点估计当成稳定、可重复的 QoS 代码退化。

原版分阶段诊断五组的中位数如下；这些是诊断数据，未混入正式通过样本：

| 阶段 | 无 QoS | 高 QoS |
|---|---:|---:|
| producer 总时长 | 12.409 s | 12.658 s |
| 源 stream 等待累计 | 0.360 s | 0.360 s |
| 向目标队列发送等待累计 | 11.864 s | 12.165 s |
| 源哈希累计 | 0.144 s | 0.143 s |
| S3 EOF 后分片排空 | 0.080 s | 0.067 s |
| CompleteMultipartUpload | 0.184 s | 0.136 s |

队列等待主要来自目标写入背压；源读取和 QoS 准入都不是这些约 13～17 秒复制的主导耗时。上轮准入专项仅累计约 0.266 ms、0 次限速等待。目标 VM 的本次只读采样进一步显示 8 vCPU、内存充足，但 I/O PSI 的 `some avg10=40.01%`、`full avg10=39.12%`，复制活跃段 CPU iowait 约 13～21%，写入约 25～49 MiB/s，吻合实际吞吐与波动。

这证明当前路径受目标 I/O 约束，与原样本波动一致；**没有旧失败时刻的同等服务端遥测，不能宣称已定位那个时刻的具体磁盘请求。** 本次保留 NFS 调度实现，使用原尺寸复测、完整旧版对照及目标遥测修正归因；没有停止服务、修改存储参数或用更大文件覆盖旧失败。

## 2. 防止修复自身造成回退

先验证最终候选的相对性能，再分别检查绝对高 QoS 和绝对无 QoS 吞吐。前两版虽然修复了连接计数，也因当轮性能门槛未通过被撤回，全量回归被拦住。

{table(['候选','原版高 / 原版基准','候选高 / 候选基准','候选高 / 原版高','候选基准 / 原版基准'],matched)}

前两版为逐 GET 重试配置覆盖、显式构造默认 transport；最终版复用 SDK 实际选中的 transport。上述数字是各轮观察，不能据此断言前两版所有退化都是稳定代码成本；拒绝标准始终是既定的 98% 门槛，没有选择性隐藏失败。

最终候选四组对照：512 MiB，每组 12 个样本，共 48 次独立真实复制；以种子 20261030 生成三个随机均衡 Latin 区组周期，每个 arm 在四个位置出现次数相同；顺序数组和二进制 SHA-256 在测量前写入 `matched-capture/plan.json`。每次计时外同等空闲 1 秒，全量目标读回/哈希成功后删除目标。两版、同一路径、请求 cap、并发和复制策略完全相同。

[三轮对照汇总](matched-comparisons.json)、[真实 TCP 连接数](tcp-connections.json)、[全部尝试及测量 CSV](measurements.csv)。最终二进制 SHA-256：`{completed['binary_sha256']}`。

## 3. 23 路跨 backend 全量回归

覆盖七种源到 Local，以及 Local/NFSv4.1/CIFS/S3/HDFS 五类之间全部 20 个有向非对角组合，共 23 路。每路性能文件尺寸与上轮最终主矩阵相同：**两条原失败路径仍为 512 MiB**；这次没有依靠 2 GiB/12 GiB 长样本通过。

两条重点路径各 15 组 baseline/high，其余各五组；两 arms 同等空闲 1 秒，性能阶段串行、不与诊断/有限配额负载重叠。随后主矩阵有限配额最多四路并行；第 4 节固定配额补测另对共享目标物理盘串行隔离。真实连接、读写、提交/关闭、发布和全量目标 BLAKE3 均验证，未用 mock 代替 backend。主矩阵采用 270 个性能样本、115 个有限配额复制；导入副本逐字节及二进制/配置/样本数绑定核对，副本不是新增样本。

{table(['路径','MiB','基准 MiB/s','高 QoS / 基准','高 QoS'],mainrows)}

计时与上轮口径一致：到 Local 使用 default 复制策略；其余使用 AtomicReplace、关闭复制内读回，计时包括 payload 与必要协议提交/发布，独立验收全量读回在计时外。**AtomicReplace 在 Local/NFS 省略最终持久化屏障，不能把这些数据称为默认 durable-copy 性能。** 源 fixture 为真实完整写入的重复随机块，未清空共享缓存；只代表当前单文件、逻辑 payload 负载。

带宽/IOPS 的硬包络、软包络、稳态下限、有限突发与突发后窗口沿用原规则。硬包络仍是全部准入区间 `traffic ≤ hard×Δt + one_actual_request`，未加百分比余量；不证明物理微秒窗口绝不超 hard。源 S3 GET 保留 8 MiB 上限，12 项 `s3_payload_requests_no_inflation` 单列计入本次主矩阵，所以主矩阵从上轮 943 增至 955，不能混淆分母。GET 请求数与 TCP 连接数分别验证。

本轮主矩阵未通过项：

{table(['路径','用例','判定','达成率'],failrows) if failrows else '无。'}

主矩阵有限配额会按当轮基准自动选取合理限额，因此基准变化也会改变限额；不能把新旧不同限额的判定直接当成回退对照。

## 4. 保持上轮配额不变的额外回归

八条涉及 S3 的路径各五个有限配额用例，共 40 次复制。直接复用上轮原始命令中的 soft/hard、peak、idle、chunk cap、128 MiB 文件尺寸和复制策略，只替换隔离路径和二进制。所有测试先按固定计划完成，再汇总；未按通过情况挑样本。最多四个 worker，但经只读布局核验，目标 S3 `/data/rustfs0` 与 NFSv4.1 `/srv/nfs/v4` 位于同一设备（`st_dev=2049`，`/dev/sda1` ext4）；固定配额补测在第一条测量前对这两个目标增加共享物理卷锁，其他目标可并行。**并发拓扑与旧主矩阵不同**，这项结果说明隔离条件下的同配额兼容性，不能单独视作只改变代码的因果对照。计划见 `fixed-limits/plan.json`，布局/负载见 `target-storage-layout.log`、`target-load.log`。

共 **{fixed['passed']}/{fixed['checks']}** 项通过；相对于上轮同参数判定，新增失败 **{fixed['new_failures']}** 项。原本不通过的短文件 strict 项依然如实记录，不能称为已全部修复。

{table(['新增失败路径','用例','判定'],newfixed) if newfixed else '同参数对照没有出现新的“上轮通过、本轮失败”判定。'}

[固定配额对照](fixed-limit-checks.json) 同时包含 `old_passed`、`passed`、`new_failure`；完整命令和 trace 在归档 `fixed-limits/` 与 `fixed-limits-reference.json`。S3 带宽容差尚未数值化，本次仍按原 98% 记录偏差；未把带宽容忍自动扩大到 IOPS、请求次数或 hard 准入包络。

## 5. 原尺寸独立确认与异常项直接对照

所有正式补测仍使用最终普通二进制，保持相同请求 cap、并发、复制策略及完整目标读回。S3→HDFS 独立 30 组的随机 AB/BA 顺序和种子 202610301 在开测前写入计划，每次同等空闲 1 秒，性能阶段串行。

| S3→HDFS，512 MiB | 无 QoS 中位 MiB/s | 高 QoS 中位 MiB/s | 比例 | 判定 |
|---|---:|---:|---:|---|
| 主矩阵 15 组 | 253.471 | 248.323 | 97.969% | **未通过，保留** |
| 独立确认 30 组 | 282.549 | 282.345 | 99.928% | 通过 |
| 所有合格正式样本合并，57 组 | 见原始样本 | 见原始样本 | 99.199% | 仅事后敏感性分析 |

57 组包含最终候选的 12 区组、主矩阵 15 组以及确认 30 组，没有删除失败组；合并结果不是又一次独立确认。详见 [独立确认与合并说明](confirmation.json)、[源读取诊断](source-only.json)。

对主矩阵另外三项异常，执行旧版/新版直接对照。CIFS→S3 与 HDFS→NFSv4.1 分别为 12 个随机均衡的三臂区组，每次开始前在目标 VM13 连续两次、间隔约 0.5 秒确认 Dirty≤16 MiB、Writeback=0、磁盘 inflight=0；最多等 180 秒，没有执行 sync、清缓存或改服务设置。Local→NFSv4.1 为 5 对，保持原 128 MiB、soft=hard=8 MiB/s 严格配额。所有 readiness 快照与计划均入档。

| 路径及用例 | 新版高 / 旧版高（或同配额） | 新版高 / 新版基准 | 结论 |
|---|---:|---:|---|
| CIFS→S3 高 QoS，512 MiB | 101.700% | **91.637%** | 未观察到本次引入的绝对回退；相对 98% 门槛仍未通过 |
| HDFS→NFSv4.1 高 QoS，128 MiB | 102.426% | 104.953% | 直接对照通过，主矩阵失败保留 |
| Local→NFSv4.1 严格带宽，128 MiB | 100.004% | 不适用 | 旧/新版端到端配额达成率分别 99.047% / 99.051% |

Local→NFSv4.1 主矩阵失败样本的首准入延迟约 271 ms，补测约 58～65 ms，尾段仍约 80～100 ms。这条路径不经过本次修改的 S3 模块；冷初始化与目标等待足以影响 16 秒理想时长的短文件端到端比例。[全部直接对照](absolute-controls.json) 保留原始中位数和失败标记。

CIFS→S3 的相对缺口仍需单列：两版高 QoS 直接对照无新增下降，尚未证明唯一、稳定的代码根因。额外三次旧版诊断确认 producer 实际均为 **512×1 MiB**，目标均为 **64×8 MiB MPU**，排除了无 QoS 仅按大块估算操作数导致的比较误读。高 QoS 准入 512 次、限速等待 0 次、累计 0.424 ms；发送队列等待约 13.3 秒，源等待读取约 2.1～2.5 秒，目标背压占主要耗时。诊断轮基准 28.855 MiB/s、高 QoS 30.800 MiB/s，方向发生反转，提示明显目标波动；**这些诊断不能用来撤销三臂正式对照的 91.637% 失败，也不足以宣称剩余缺口已经修复。**

## 6. 自动化、证据和剩余边界

- Rust workspace lib：**2076 通过、0 失败、9 忽略**，14 个 suite；新增真实 TCP pool 回归和既有 SDK 重试/取消/IOPS 扣费测试通过。忽略项不算作实测替代。
- Python QoS：16 通过；Clippy release 两个验收 example、S3 lib/tests `-D warnings`、cargo fmt、架构依赖检查通过。Cargo.lock/依赖版本不变。既有 binrw future-incompatibility 提示保留。
- 临时 `[HIGH-PROBE]` 分阶段日志只存在独立诊断二进制；生产源码逐字节恢复。最终正式二进制没有该标签及旧 QoS/tail/pressure 探针标签。生产 transport 捕获拦截器无日志。
- [独立证据审计](evidence-audit.json) 重算全部 955 项主判定、三轮 12 区组对照、独立 30 组确认、57 组事后合并、source-only/三臂/固定配额控制及真实 TCP connect 次数，核对全量摘要、基准副本/绑定及归档逐文件 SHA-256。审计一致不把失败改成通过。
- [完整脱敏证据](raw-evidence.tar.gz) 包含原版复现、阶段探针、两轮被拒候选、最终随机对照、socket 原始 trace、23 路正式回归、固定配额对照、实际控制脚本、源代码快照和本地验证日志；排除私有端点配置、keytab/票据及大 fixture。小随机块与 manifest 可重建全文件哈希。
- [本轮修复补丁](high-qos-fix.patch)、[源代码清单](source-manifest.json)、[验证结果](validation.json)、[隔离清理](cleanup.json)、[私有配置清理](private-cleanup.json)、[归档凭据与逐文件审计](archive-audit.json)、[附件 SHA-256](SHA256SUMS)。保留之前 dirty working tree，未提交或推送。

根因和修复的证据边界分别保留：S3 默认连接池丢失是可确定复现并修复的代码缺陷；NFS→S3 的原低点没有证据支持稳定的源调度退化，不能凭新的通过样本抹去历史失败，也不能把所有服务端波动归为代码已修复。四场景、历史 strict 尾部与物理限速语义仍以 [上轮完整报告](../qos98-cross-backends-20261030/REPORT.md) 和本轮逐项原始判定为准。
'''
(out/'REPORT.md').write_text(report)
for name in ['source-manifest.json','high-qos-fix.patch','measurements.csv','evidence-audit.json','checks.json','summary.json','validation.json','cleanup.json']:shutil.copy2(b/name,out/name)
shutil.copy2(r/'fixed-limits/checks.json',out/'fixed-limit-checks.json')
(out/'matched-comparisons.json').write_text(json.dumps({n:json.load(open(r/n/'summary.json')) for n in ['matched','matched-shared','matched-capture']},indent=2));shutil.copy2(r/'socket-capture/summary.json',out/'tcp-connections.json');print('Report written',out)

(out/'confirmation.json').write_text(json.dumps({'independent_30_pair':audit['independent_30_pair_confirmation'],'posthoc_57_pair':audit['pooled_57_pair_posthoc']},indent=2))
(out/'source-only.json').write_text(json.dumps(audit['source_only_diagnostic'],indent=2))
(out/'absolute-controls.json').write_text(json.dumps({'controls':audit['absolute_controls'],'local_nfs':audit['local_nfs_cold_control']},indent=2))
