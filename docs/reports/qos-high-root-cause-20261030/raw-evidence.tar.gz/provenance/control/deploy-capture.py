from pathlib import Path
import json,paramiko,hashlib
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();binary=Path('/work/cargo-target/release/examples/backend_qos_acceptance');s.put(str(binary),r+'/capture-bin');s.chmod(r+'/capture-bin',0o700)
v=s.open(r+'/matched.py').read().decode().replace("folder=r/'matched'","folder=r/'matched-capture'").replace("'fixed-bin'","'capture-bin'")
a=v.index('for i in range(12):\n order=arms[i%4:]');b=v.index("(folder/'plan.json')",a);v=v[:a]+'''rng=random.Random(20261030)
for cycle in range(3):
 base=arms.copy();rng.shuffle(base);orders=[base[i:]+base[:i] for i in range(4)];rng.shuffle(orders);plan.extend(orders)
'''+v[b:]
with s.file(r+'/matched-capture.py','w') as f:f.write(v)
v=s.open(r+'/socket-check.py').read().decode().replace("r/'matched-shared/status.json'","r/'matched-capture/status.json'").replace("folder=r/'socket-check'","folder=r/'socket-capture'").replace("'shared-bin'","'capture-bin'")
with s.file(r+'/socket-capture.py','w') as f:f.write(v)
v=s.open(r+'/regression.py').read().decode().replace("while not (r/'matched/status.json').exists():time.sleep(1)","while not (r/'matched-capture/status.json').exists() or not (r/'socket-capture/status.json').exists():time.sleep(1)").replace("r/'matched/status.json'","r/'matched-capture/status.json'").replace("'fixed-bin'","'capture-bin'")
with s.file(r+'/regression-capture.py','w') as f:f.write(v)
try:s.rename(r+'/regression-blocked.json',r+'/regression-blocked-explicit-default.json')
except FileNotFoundError:pass
for script in ['matched-capture.py','socket-capture.py','regression-capture.py']:
 _,o,e=c.exec_command('cd '+r+' && nohup python3 '+script+' >'+script+'.log 2>&1 </dev/null &')
print('Runtime-capture binary',hashlib.sha256(binary.read_bytes()).hexdigest(),'deployed; predeclared random balanced 12-block qualification, then socket proof, then full regression.');s.close();c.close()
