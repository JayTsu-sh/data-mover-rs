import json,paramiko,shlex
x=json.load(open('.scratch/qos-high/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
stop='''from pathlib import Path
import os,signal
r=Path.cwd();assert not (r/'fixed-limits').exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if Path(os.readlink(p/'cwd'))!=r:continue
  if (p/'cmdline').read_bytes().split(b'\\0')[:2]==[b'python3',b'run-fixed-limits.py']:os.kill(int(p.name),signal.SIGTERM)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
'''
_,o,e=c.exec_command('cd '+r+' && python3 -c '+shlex.quote(stop));assert o.channel.recv_exit_status()==0
v=s.open(r+'/run-fixed-limits.py').read().decode().replace('import json,time,subprocess,concurrent.futures,os,importlib.util','import json,time,subprocess,concurrent.futures,os,importlib.util,threading')
v=v.replace("def qualify(name):", "volume_locks={'vm13-root-volume':threading.Lock()}\norder=['local-to-s3','s3-to-local','cifs-to-s3','s3-to-cifs','nfs41-to-s3','s3-to-hdfs','hdfs-to-s3','s3-to-nfs41']\n(folder/'plan.json').write_text(json.dumps({'profiles':order,'max_workers':4,'target_physical_volume_serialized':['s3','nfs41'],'evidence':'target-storage-layout.log: /data/rustfs0 and /srv/nfs/v4 both st_dev=2049','no_quota_or_file_size_changes':True},indent=2))\ndef qualify(name):")
v=v.replace("with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:\n for rows in pool.map(qualify,sorted(profiles.keys() & {p['profile'] for p in reference})):results.extend(rows)","def isolated(name):\n if profiles[name]['destination_kind'] in ['s3','nfs41']:\n  with volume_locks['vm13-root-volume']:return qualify(name)\n return qualify(name)\nwith concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:\n for rows in pool.map(isolated,order):results.extend(rows)")
v=v.replace("'quotas_caps_peaks_policies_original':True", "'quotas_caps_peaks_policies_original':True,'physical_target_volume_isolated':True")
with s.file(r+'/run-fixed-limits.py','w') as f:f.write(v)
_,o,e=c.exec_command('cd '+r+' && nohup python3 run-fixed-limits.py >fixed-limits.log 2>&1 </dev/null &');print('Fixed-limit regression now serializes destinations sharing VM13 physical volume; quotas, caps, 128MiB payload and protocols unchanged. Updated before any fixed-limit sample.');s.close();c.close()
