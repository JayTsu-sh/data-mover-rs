from pathlib import Path
import subprocess,hashlib,shutil
paths=['crates/transfer/src/transfer/engine.rs','crates/transfer/src/transfer/engine/producer.rs','crates/backend-hdfs/src/backend/writer.rs','crates/backend-s3/src/backend/staged/parts.rs','crates/backend-s3/src/backend/staged/at_destination.rs']
originals={p:Path(p).read_bytes() for p in paths};written={}
replacements={
paths[0]:[
('    let transferred = run_until_transferred(request).await?;', '    let high_probe = std::time::Instant::now();\n    let transferred = run_until_transferred(request).await?;\n    eprintln!("[HIGH-PROBE] phase=payload_prepare ns={}", high_probe.elapsed().as_nanos());\n    let high_probe = std::time::Instant::now();'),
('    let expected_size = transferred.checkpoint.durable_prefix;', '    eprintln!("[HIGH-PROBE] phase=publication ns={}", high_probe.elapsed().as_nanos());\n    let expected_size = transferred.checkpoint.durable_prefix;')],
paths[1]:[
('    let mut offset = read_start;','    let mut offset = read_start;\n    let high_started = std::time::Instant::now();\n    let mut high_reads = 0u64;\n    let mut high_sends = 0u64;\n    let mut high_hashes = 0u64;\n    let mut high_chunks = 0u64;'),
('    loop {\n        let item = tokio::select!', '    loop {\n        let high_probe = std::time::Instant::now();\n        let item = tokio::select!'),
('        let Some(bytes) = item else { break };', '        high_reads += high_probe.elapsed().as_nanos() as u64;\n        let Some(bytes) = item else { break };\n        high_chunks += 1;'),
('        if let Some(hasher) = &mut hasher {\n            hasher.update(&bytes);\n        }','        if let Some(hasher) = &mut hasher {\n            let high_probe = std::time::Instant::now();\n            hasher.update(&bytes);\n            high_hashes += high_probe.elapsed().as_nanos() as u64;\n        }'),
('            tokio::select! {\n                biased;\n                () = request.cancel.cancelled()', '            let high_probe = std::time::Instant::now();\n            tokio::select! {\n                biased;\n                () = request.cancel.cancelled()'),
('            }\n        }\n        offset = next;', '            }\n            high_sends += high_probe.elapsed().as_nanos() as u64;\n        }\n        offset = next;'),
('    Ok(hasher.map(|hasher| *hasher.finalize().as_bytes()))','    eprintln!("[HIGH-PROBE] phase=producer ns={} read_ns={} send_ns={} hash_ns={} chunks={}", high_started.elapsed().as_nanos(),high_reads,high_sends,high_hashes,high_chunks);\n    Ok(hasher.map(|hasher| *hasher.finalize().as_bytes()))')],
paths[2]:[
('    let mut writer = adapter','    let high_probe = std::time::Instant::now();\n    let mut writer = adapter'),
('    let result = consume(adapter, stage, &mut *writer, &mut input, expected).await;', '    eprintln!("[HIGH-PROBE] phase=hdfs_open ns={}", high_probe.elapsed().as_nanos());\n    let high_probe = std::time::Instant::now();\n    let result = consume(adapter, stage, &mut *writer, &mut input, expected).await;\n    eprintln!("[HIGH-PROBE] phase=hdfs_consume ns={}", high_probe.elapsed().as_nanos());'),
('    let closed = writer.close().await;', '    let high_probe = std::time::Instant::now();\n    let closed = writer.close().await;\n    eprintln!("[HIGH-PROBE] phase=hdfs_close ns={}", high_probe.elapsed().as_nanos());')],
paths[3]:[
('        if !buffered.is_empty() || (progress.sent.parts.is_empty() && inflight.is_empty()) {', '        let high_probe = std::time::Instant::now();\n        if !buffered.is_empty() || (progress.sent.parts.is_empty() && inflight.is_empty()) {'),
('        progress.sent.parts.sort_by_key(|part| part.0);', '        eprintln!("[HIGH-PROBE] phase=s3_drain ns={} parts={} size={}", high_probe.elapsed().as_nanos(),progress.sent.parts.len(),target.part_size);\n        progress.sent.parts.sort_by_key(|part| part.0);')],
paths[4]:[
('        let facts = self\n            .complete_final_upload(path, upload, &parts, md5_etags, request.expected_size)', '        let high_probe = std::time::Instant::now();\n        let facts = self\n            .complete_final_upload(path, upload, &parts, md5_etags, request.expected_size)'),
('        upload.lock().published = Some(facts.clone());','        eprintln!("[HIGH-PROBE] phase=s3_complete ns={}", high_probe.elapsed().as_nanos());\n        upload.lock().published = Some(facts.clone());')]
}
try:
 for p,old in originals.items():
  new=old.decode()
  for a,b in replacements[p]:assert new.count(a)==1,(p,a,new.count(a));new=new.replace(a,b)
  Path(p).write_text(new);written[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 with open('/work/qos-high-stage-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-high-stage-probe')
finally:
 for p in written:
  assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==written[p],p
  Path(p).write_bytes(originals[p])
print('Stage probe built; production source restored byte-for-byte')
