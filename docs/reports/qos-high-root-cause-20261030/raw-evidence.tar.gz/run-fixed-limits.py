from pathlib import Path
import json,time,subprocess,concurrent.futures,os,importlib.util,threading
from qos_evidence import redact,secret_values
r=Path.cwd()
while not (r/'regression/complete.json').exists():time.sleep(1)
spec=importlib.util.spec_from_file_location('validator',r/'run-local-qos.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
profiles={p['name']:p for p in json.load(open('matrix.private.json'))['profiles']};reference=json.load(open('fixed-limits-reference.json'));folder=r/'fixed-limits';folder.mkdir();results=[]
volume_locks={'vm13-root-volume':threading.Lock()}
order=['local-to-s3','s3-to-local','cifs-to-s3','s3-to-cifs','nfs41-to-s3','s3-to-hdfs','hdfs-to-s3','s3-to-nfs41']
(folder/'plan.json').write_text(json.dumps({'profiles':order,'max_workers':4,'target_physical_volume_serialized':['s3','nfs41'],'evidence':'target-storage-layout.log: /data/rustfs0 and /srv/nfs/v4 both st_dev=2049','no_quota_or_file_size_changes':True},indent=2))
def qualify(name):
 p=profiles[name];env={**os.environ,**p['env'],'NO_PROXY':'*','no_proxy':'*'};secrets=secret_values([env]);(folder/name).mkdir();rows=[]
 for ref in reference:
  if ref['profile']!=name:continue
  case=ref['case'];cmd=[v.replace('/tmp/nightly-qos-cross-20261029192047',str(r)) for v in ref['command']];cmd[0]=str(r/'capture-bin');result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);(folder/name/(case+'.stderr')).write_text(redact(result.stderr,secrets));assert result.returncode==0,name+'/'+case+' failed; inspect redacted stderr';d=json.loads(result.stdout);d['command']=cmd;(folder/name/(case+'.json')).write_text(json.dumps(d));peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';checks={}
  for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
   key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);trace=V.validate_trace(d,resource,soft,hard,peak,dual);prefix=resource+'_' if case=='combined' else '';actual=d['bytes']/d['seconds'] if key=='bytes' else d['iops'];checks[prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent')]=actual>=soft*.98
   for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):checks[prefix+gate]=trace[gate]
  for old in ref['old_checks']:
   passed=checks[old['name']];rows.append(dict(profile=name,case=case,name=old['name'],old_passed=old['passed'],passed=passed,new_failure=old['passed'] and not passed))
  print(name,case,'fixed original quota',d['mibps'],flush=True)
 return rows
def isolated(name):
 if profiles[name]['destination_kind'] in ['s3','nfs41']:
  with volume_locks['vm13-root-volume']:return qualify(name)
 return qualify(name)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for rows in pool.map(isolated,order):results.extend(rows)
(folder/'checks.json').write_text(json.dumps(results,indent=2));(folder/'complete.json').write_text(json.dumps({'samples':40,'checks':len(results),'passed':sum(g['passed'] for g in results),'new_failures':sum(g['new_failure'] for g in results),'quotas_caps_peaks_policies_original':True,'physical_target_volume_isolated':True},indent=2));print('Original fixed-limit regression complete',sum(g['new_failure'] for g in results),'new failed gates',flush=True)
