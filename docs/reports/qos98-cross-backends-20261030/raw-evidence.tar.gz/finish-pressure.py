import pathlib,json,shutil,hashlib
from urllib.parse import urlsplit,unquote
import boto3
from botocore.config import Config
root=pathlib.Path.cwd();folder=root/'pressure';cfg=json.load(open('matrix.private.json'));original=cfg['run_id'];run=original+'-pressure';rows={p['name']:p for p in cfg['profiles']};source_env=rows['s3-to-local']['env'];target_env=rows['local-to-s3']['env'];cleanup=[]
def client(endpoint,ak,sk):return boto3.client("s3",endpoint_url=endpoint,aws_access_key_id=ak,aws_secret_access_key=sk,region_name="us-east-1",config=Config(proxies={},s3={"addressing_style":"path"}))
def clean(label,s3,bucket,prefix):
 deleted=aborted=0;versioning=s3.get_bucket_versioning(Bucket=bucket).get("Status","Unversioned")
 for _ in range(100):
  page=s3.list_multipart_uploads(Bucket=bucket,Prefix=prefix);uploads=page.get("Uploads",[])
  if not uploads:break
  for upload in uploads:
   assert upload["Key"].startswith(prefix);s3.abort_multipart_upload(Bucket=bucket,Key=upload["Key"],UploadId=upload["UploadId"]);aborted+=1
 else:raise RuntimeError("multipart cleanup did not converge")
 for _ in range(100):
  page=s3.list_object_versions(Bucket=bucket,Prefix=prefix);objects=[{"Key":v["Key"],"VersionId":v["VersionId"]} for k in ["Versions","DeleteMarkers"] for v in page.get(k,[])]
  if not objects:break
  assert all(o["Key"].startswith(prefix) for o in objects);answer=s3.delete_objects(Bucket=bucket,Delete={"Objects":objects,"Quiet":True});assert not answer.get("Errors");deleted+=len(objects)
 else:raise RuntimeError("version cleanup did not converge")
 assert not s3.list_objects_v2(Bucket=bucket,Prefix=prefix).get("Contents");cleanup.append(dict(endpoint=label,prefix=prefix,versioning=versioning,versions_and_markers_deleted=deleted,multipart_aborted=aborted,empty=True))
host=source_env['S3_HOST'];host=host if '://' in host else 'http://'+host
if urlsplit(host).port is None:host+=':9000'
p=urlsplit(target_env['QOS_DESTINATION']);bucket,hostpart=p.hostname.split('.',1)
clients=[('source',client(host,source_env['S3_AK'],source_env['S3_SK']),source_env['S3_BUCKET']),('destination',client('http://'+hostpart+':'+str(p.port or 9000),unquote(p.username),unquote(p.password)),bucket)]
for label,s3,bucket in clients:
 for prefix in ['ci/'+run+'/', 'ci/'+original+'/']:clean(label,s3,bucket,prefix)
for name in ['fixtures','destination']:shutil.rmtree(folder/name,ignore_errors=True)
(folder/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
checks=json.load(open(folder/'checks.json'));assert len(checks)==44 and all(g['passed'] for g in checks)
(folder/'environment.json').write_text(json.dumps({'run_id':run,'probe_sha256':hashlib.sha256((root/'request-probe').read_bytes()).hexdigest(),'scope':'actual SDK before-transmit attempts including retries; payload/readback/metadata classified separately','payload_size':64*1024*1024,'fixture_block_sha256':hashlib.sha256((folder/'64.block.bin').read_bytes()).hexdigest(),'fixtures_removed':True,'diagnostic_only':True,'cleanup_initial_failure':'destination custom S3 URL bucket.host initially parsed as DNS host; cleanup-only parser fixed; measurements unchanged'},indent=2))
(folder/'status.json').write_text(json.dumps({'passed':44,'total':44}))
print('Pressure checks 44/44; four exact-prefix S3 scopes empty including versions/markers/multipart')
