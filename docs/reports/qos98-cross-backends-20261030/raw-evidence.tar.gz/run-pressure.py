import pathlib,json,subprocess,os,re,hashlib,collections,time,shutil,importlib.util
from urllib.parse import urlsplit,unquote
import boto3
from botocore.config import Config
from qos_evidence import secret_values,redact
root=pathlib.Path.cwd();config=json.load(open("matrix.private.json"));original=config["run_id"];run=original+"-pressure";folder=root/"pressure";folder.mkdir();fixtures=folder/"fixtures";fixtures.mkdir();destination=folder/"destination";destination.mkdir()
block=(root/"fixture-patterns/128.block.bin").read_bytes()
with (fixtures/"64.bin").open("wb") as f:
 for _ in range(64):f.write(block)
 f.flush();os.fsync(f.fileno())
(folder/"64.block.bin").write_bytes(block)
rows={p["name"]:p for p in config["profiles"]};source_env={k:v.replace(original,run) for k,v in rows["s3-to-local"]["env"].items()};target_env={k:v.replace(original,run) for k,v in rows["local-to-s3"]["env"].items()};target_env["QOS_SOURCE"]=str(fixtures)
secrets=secret_values([source_env,target_env]);checks=[];summaries=[]
spec=importlib.util.spec_from_file_location("validator",root/"run-local-qos.py");V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
pattern=re.compile(r"\[S3-PRESSURE\] method=(\S+) kind=(\S+) range_bytes=(\d+) body_bytes=(\d+)")
def measure(route,case,env,extra=(),seed=False):
 cmd=[str(root/"request-probe"),"--source",str(fixtures),"--destination",str(destination),"--path","64.bin","--chunk-bytes",str(8*1024*1024 if route=="s3-to-local" else 2*1024*1024),"--transfer-profile","cross","--destination-cleanup","delete",*( ["--seed"] if seed else ["--copy"]),*extra]
 result=subprocess.run(cmd,env={**os.environ,**env,"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=180)
 (folder/(route+"-"+case+".stderr")).write_text(redact(result.stderr,secrets))
 if result.returncode:raise RuntimeError(route+"/"+case+" exit="+str(result.returncode)+"; private stderr omitted")
 data=json.loads(result.stdout);data["command"]=cmd;(folder/(route+"-"+case+".json")).write_text(json.dumps(data))
 if seed:return
 events=[dict(method=m,kind=k,range_bytes=int(r),body_bytes=int(b)) for m,k,r,b in pattern.findall(result.stderr)];counts=dict(collections.Counter(e["kind"] for e in events));payload=[e for e in events if e["kind"]==("range-get" if route=="s3-to-local" else "upload-part")];sizes=[e["range_bytes"] if route=="s3-to-local" else e["body_bytes"] for e in payload]
 row=dict(route=route,case=case,counts=counts,payload_requests=len(payload),payload_request_bytes=sizes,seconds=data["seconds"],mibps=data["mibps"],iops=data["iops"],digest=data["digest"],expected_payload_requests=8)
 summaries.append(row);checks.append(dict(route=route,case=case,name="payload_request_count_no_inflation",passed=len(payload)==8));checks.append(dict(route=route,case=case,name="payload_requests_remain_8MiB",passed=sizes==[8*1024*1024]*8));checks.append(dict(route=route,case=case,name="payload_wire_bytes_match",passed=sum(sizes)==64*1024*1024))
 if route=="s3-to-local" and data["admissions"]:
  checks.append(dict(route=route,case=case,name="wire_requests_match_qos_accounting",passed=len(payload)==data["operations"]))
 if route=="local-to-s3":checks.append(dict(route=route,case=case,name="independent_readback_wire_bytes_match",passed=sum(e["range_bytes"] for e in events if e["kind"]=="range-get")==data["bytes"]))
 if data["admissions"]:
  resource="iops" if case=="iops-strict" else "bandwidth";key="iops" if resource=="iops" else "bytes";soft=int(extra[extra.index("--soft-"+key)+1]);hard=int(extra[extra.index("--hard-"+key)+1]);packet=max(e["bytes"] for e in data["admissions"]) if resource=="bandwidth" else 1;peak=4 if case=="bandwidth-dual" else .5
  for label,rate,budget in [("hard_envelope",hard,packet),("soft_envelope",soft,(hard-soft)*peak+packet)]:checks.append(dict(route=route,case=case,name=label,passed=V.envelope_excess(data["admissions"],rate,resource)<=budget+1e-6))
  window=max(5,2*packet/soft);row["steady_window_seconds"]=window;row["steady_rate"]=V.trailing_rate(data,resource,window);row["soft"]=soft;row["end_to_end_ratio"]=data["iops"]/soft if resource=="iops" else data["bytes"]/data["seconds"]/soft
 (folder/"summary.json").write_text(json.dumps(summaries,indent=2));(folder/"checks.json").write_text(json.dumps(checks,indent=2));print(route,case,counts,"payload",len(payload),"MiB/s",data["mibps"],flush=True)
def client(endpoint,ak,sk):return boto3.client("s3",endpoint_url=endpoint,aws_access_key_id=ak,aws_secret_access_key=sk,region_name="us-east-1",config=Config(proxies={},s3={"addressing_style":"path"}))
host=source_env["S3_HOST"];host=host if "://" in host else "http://"+host
if urlsplit(host).port is None:host+=":9000"
p=urlsplit(target_env["QOS_DESTINATION"]);dst_host="http://"+str(p.hostname)+":"+str(p.port or 9000)
clients=[("source",client(host,source_env["S3_AK"],source_env["S3_SK"]),source_env["S3_BUCKET"]),("destination",client(dst_host,unquote(p.username),unquote(p.password)),p.path.strip("/").split("/")[0])]
cleanup=[]
def clean(label,s3,bucket,prefix):
 deleted=aborted=0;versioning=s3.get_bucket_versioning(Bucket=bucket).get("Status","Unversioned")
 for _ in range(100):
  page=s3.list_multipart_uploads(Bucket=bucket,Prefix=prefix);uploads=page.get("Uploads",[])
  if not uploads:break
  for upload in uploads:
   assert upload["Key"].startswith(prefix);s3.abort_multipart_upload(Bucket=bucket,Key=upload["Key"],UploadId=upload["UploadId"]);aborted+=1
 else:raise RuntimeError("multipart cleanup did not converge")
 for _ in range(100):
  page=s3.list_object_versions(Bucket=bucket,Prefix=prefix);objects=[{"Key":v["Key"],"VersionId":v["VersionId"]} for k in ["Versions","DeleteMarkers"] for v in page.get(k,[])]
  if not objects:break
  assert all(o["Key"].startswith(prefix) for o in objects);answer=s3.delete_objects(Bucket=bucket,Delete={"Objects":objects,"Quiet":True});assert not answer.get("Errors");deleted+=len(objects)
 else:raise RuntimeError("version cleanup did not converge")
 assert not s3.list_objects_v2(Bucket=bucket,Prefix=prefix).get("Contents");cleanup.append(dict(endpoint=label,prefix=prefix,versioning=versioning,versions_and_markers_deleted=deleted,multipart_aborted=aborted,empty=True))
try:
 measure("s3-to-local","seed",source_env,seed=True)
 high=["--soft-bytes",str(1<<40),"--hard-bytes",str(1<<40),"--soft-iops","1000000000","--hard-iops","1000000000","--admission-trace","disabled"]
 for case,extra in [("baseline",[]),("high",high),("bandwidth-strict",["--soft-bytes","4194304","--hard-bytes","4194304"]),("bandwidth-dual",["--soft-bytes","4194304","--hard-bytes","8388608","--peak-ms","4000","--idle-ms","4100"]),("bandwidth-low",["--soft-bytes","1048576","--hard-bytes","1048576"]),("iops-strict",["--soft-iops","1","--hard-iops","1"])]:measure("s3-to-local",case,source_env,extra)
 for case,extra in [("baseline",[]),("high",high),("bandwidth-strict",["--soft-bytes","4194304","--hard-bytes","4194304"])]:measure("local-to-s3",case,target_env,extra)
finally:
 for label,s3,bucket in clients:
  for prefix in ["ci/"+run+"/","ci/"+original+"/"]:clean(label,s3,bucket,prefix)
 for name in ["fixtures","destination"]:shutil.rmtree(folder/name,ignore_errors=True)
 (folder/"cleanup.json").write_text(json.dumps(cleanup,indent=2))
(folder/"environment.json").write_text(json.dumps({"run_id":run,"probe_sha256":hashlib.sha256((root/"request-probe").read_bytes()).hexdigest(),"scope":"actual SDK before-transmit attempts including retries; source payload/target payload/independent validation/metadata classified separately","payload_size":64*1024*1024,"fixture_block_sha256":hashlib.sha256(block).hexdigest(),"fixtures_removed":True,"diagnostic_only":True},indent=2));(folder/"status.json").write_text(json.dumps({"passed":sum(g["passed"] for g in checks),"total":len(checks)}))
