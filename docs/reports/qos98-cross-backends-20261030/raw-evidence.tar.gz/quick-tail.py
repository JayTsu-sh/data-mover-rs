import pathlib,json,subprocess,os,hashlib
root=pathlib.Path.cwd();p=next(p for p in json.load(open("matrix.private.json"))["profiles"] if p["name"]=="local-to-s3");folder=root/"optimization"/"tail-1m";folder.mkdir(parents=True)
checks=[]
for arm,binary in [("original","qos-bin"),("candidate","qos-tail-1m")]:
 cmd=[str(root/binary),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path","128.bin","--chunk-bytes",str(p["chunk_bytes"]),"--copy","--transfer-profile","cross","--destination-cleanup","delete","--soft-iops","4","--hard-iops","4"]
 run=subprocess.run(cmd,env={**os.environ,**p["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=180)
 if run.returncode:raise RuntimeError("Tail candidate failed; private stderr omitted")
 data=json.loads(run.stdout);(folder/(arm+".json")).write_text(run.stdout);check=dict(arm=arm,ratio=data["iops"]/4,passed=data["iops"]>=4*.98,binary_sha256=hashlib.sha256((root/binary).read_bytes()).hexdigest());checks.append(check);print(check,flush=True)
(folder/"checks.json").write_text(json.dumps(checks,indent=2))
