import json,pathlib,subprocess,os
root=pathlib.Path.cwd();config=json.load(open("matrix.private.json"));folder=root/"admission-probes";folder.mkdir();results=[]
for name in ["nfs41-to-s3","s3-to-hdfs"]:
 p=next(p for p in config["profiles"] if p["name"]==name)
 command=["./admission-probe","--source","fixtures","--destination","warm-destination","--path","512.bin","--chunk-bytes",str(p["chunk_bytes"]),"--copy","--transfer-profile",p["transfer_profile"],"--destination-cleanup","delete","--soft-bytes",str(1<<40),"--hard-bytes",str(1<<40),"--soft-iops","1000000000","--hard-iops","1000000000","--admission-trace","disabled","--idle-ms","1000"]
 run=subprocess.run(command,env={**os.environ,**p["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=180)
 (folder/(name+".stderr")).write_text(run.stderr)
 if run.returncode:raise RuntimeError("admission timing probe failed")
 data=json.loads(run.stdout);(folder/(name+".json")).write_text(json.dumps(data));print(name,"transfer_seconds",data["seconds"],run.stderr,flush=True)
