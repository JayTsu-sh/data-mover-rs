import os,pathlib,signal,time,json,subprocess,statistics
root=pathlib.Path.cwd();parent=None;child=None
for p in pathlib.Path("/proc").iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/"cmdline").read_bytes().split(b"\0")
  if pathlib.Path(os.readlink(p/"cwd"))!=root:continue
  if args[:2]==[b"python3",b"orchestrate.py"]:parent=int(p.name)
  if b"run-cross-backend-qos.py" in args and b"survey" in args:child=int(p.name)
 except OSError:pass
if parent is None or child is None:raise RuntimeError("survey already advanced; no processes changed")
os.kill(parent,signal.SIGSTOP)
try:
 while pathlib.Path(f"/proc/{child}").exists():
  try:
   if pathlib.Path(f"/proc/{child}/stat").read_text().split()[2]=="Z":break
  except FileNotFoundError:break
  time.sleep(2)
 data=json.load(open("matrix.private.json"));checks=json.load(open("survey/checks.json"));names=[c["profile"] for c in checks if c["case"]=="high" and not c["passed"]]
 print("Short-sample high-QoS failures",names,flush=True)
 overrides={};folder=root/"calibration";folder.mkdir()
 for name in names:
  profile=next(p for p in data["profiles"] if p["name"]==name);env={**os.environ,**profile["env"],"NO_PROXY":"*","no_proxy":"*"};case=folder/name;case.mkdir()
  base=[str(root/"qos-bin"),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path","128.bin","--chunk-bytes",str(profile["chunk_bytes"]),"--copy","--transfer-profile",profile["transfer_profile"],"--destination-cleanup","delete"]
  arms={"A":[],"B":[]}
  for repeat in range(5):
   for arm in (["A","B"] if repeat%2==0 else ["B","A"]):
    result=subprocess.run(base,env=env,capture_output=True,text=True,timeout=180)
    if result.returncode:raise RuntimeError("No-QoS A/A control failed")
    sample=json.loads(result.stdout);(case/f"control-{arm}-{repeat}.json").write_text(json.dumps(sample));arms[arm].append(sample["mibps"])
  ratio=statistics.median(arms["B"])/statistics.median(arms["A"])
  (case/"control-summary.json").write_text(json.dumps({"arms":arms,"ratio":ratio,"same_unlimited_configuration":True},indent=2));print(name,"No-QoS A/A ratio",ratio,flush=True)
  # Predeclared longer sample for every failed route, preserving all original data.
  endpoint=config_source=profile["env"]
  if profile["source_kind"]=="s3":
   result=subprocess.run([str(root/"qos-bin"),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path","512.bin","--chunk-bytes",str(profile["chunk_bytes"]),"--seed"],env=env,capture_output=True,text=True,timeout=180)
   if result.returncode:raise RuntimeError("large S3 fixture seed failed")
  revised=json.loads(json.dumps(data));row=next(p for p in revised["profiles"] if p["name"]==name);row["performance_size_mib"]=512
  private=case/"config.private.json";private.write_text(json.dumps(revised));private.chmod(0o600)
  baseline=case/"survey"
  command=["python3","run-backend-qos.py","--config",str(private),"--root",str(root),"--binary",str(root/"qos-bin"),"--phase","survey","--profiles",name,"--reuse-fixtures","--retain-source","--output",str(baseline)]
  with (case/"survey.log").open("w") as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
  overrides[name]={"config":str(private),"baseline":str(baseline),"reason":"complete failed-route long-sample requalification; original and unlimited A/A evidence retained","unlimited_control_ratio":ratio,"exit":code}
  print(name,"long-sample survey",code,flush=True)
 (root/"baseline-overrides.private.json").write_text(json.dumps(overrides,indent=2));(root/"baseline-overrides.private.json").chmod(0o600)
 (root/"calibration-status.json").write_text(json.dumps({"routes":names,"results":[[n,v["exit"]] for n,v in overrides.items()]},indent=2))
finally:os.kill(parent,signal.SIGCONT)
