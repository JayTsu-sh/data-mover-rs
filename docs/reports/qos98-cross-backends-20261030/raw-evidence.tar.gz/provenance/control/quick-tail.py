import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp();s.put('/work/cargo-target/release/examples/backend_qos_acceptance',r+'/qos-tail-1m');s.chmod(r+'/qos-tail-1m',0o700)
script='''import pathlib,json,subprocess,os,hashlib
root=pathlib.Path.cwd();p=next(p for p in json.load(open("matrix.private.json"))["profiles"] if p["name"]=="local-to-s3");folder=root/"optimization"/"tail-1m";folder.mkdir(parents=True)
checks=[]
for arm,binary in [("original","qos-bin"),("candidate","qos-tail-1m")]:
 cmd=[str(root/binary),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path","128.bin","--chunk-bytes",str(p["chunk_bytes"]),"--copy","--transfer-profile","cross","--destination-cleanup","delete","--soft-iops","4","--hard-iops","4"]
 run=subprocess.run(cmd,env={**os.environ,**p["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=180)
 if run.returncode:raise RuntimeError("Tail candidate failed; private stderr omitted")
 data=json.loads(run.stdout);(folder/(arm+".json")).write_text(run.stdout);check=dict(arm=arm,ratio=data["iops"]/4,passed=data["iops"]>=4*.98,binary_sha256=hashlib.sha256((root/binary).read_bytes()).hexdigest());checks.append(check);print(check,flush=True)
(folder/"checks.json").write_text(json.dumps(checks,indent=2))
'''
with s.file(r+'/quick-tail.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 quick-tail.py >optimization-1m.log 2>&1 </dev/null &');print('Paired original/1MiB-tail real-copy experiment running');s.close();c.close()
