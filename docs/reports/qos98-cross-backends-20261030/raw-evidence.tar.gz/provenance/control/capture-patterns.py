import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp()
script='''import pathlib,json,hashlib,time
root=pathlib.Path.cwd()
while not (root/"tail-probes/status.json").exists():time.sleep(2)
folder=root/"fixture-patterns";folder.mkdir();records=[]
measurements={16:"preparation/warm-local-to-local.json",128:"limits/local-to-local/local-to-local/bandwidth-strict.json",512:"survey/local-to-local/baseline-0.json",2048:"duration-validation/nfs41-to-s3/baseline-0.json",12288:"duration-validation/s3-to-hdfs/baseline-0.json"}
for size,reference in measurements.items():
 path=root/"fixtures"/f"{size}.bin";measured=json.load(open(root/reference));assert path.stat().st_size==measured["bytes"]==size*1024*1024
 with path.open("rb") as f:block=f.read(1024*1024)
 name=f"{size}.block.bin";(folder/name).write_bytes(block);records.append({"path":name,"repeat_count":size,"bytes":size*1024*1024,"block_sha256":hashlib.sha256(block).hexdigest(),"reconstructed_blake3":measured["digest"],"reference_measurement":reference})
(folder/"manifest.json").write_text(json.dumps(records,indent=2));(root/"patterns-captured.json").write_text(json.dumps({"blocks":len(records),"total_bytes":sum((folder/r["path"]).stat().st_size for r in records)}));print("Five reproducible 1MiB fixture blocks captured")
'''
with s.file(r+'/capture-patterns.py','w') as f:f.write(script)
with s.file(r+'/archive-public.py') as f:archive=f.read().decode()
archive=archive.replace('"tail-probes"]','"tail-probes","fixture-patterns"]')
archive=archive.replace('(".json",".log",".stderr")','(".json",".log",".stderr",".bin")')
archive=archive.replace('names=[','names=["survey-checks.json","orchestrate.log","prepare-run.sh","cleanup-run.sh","common.sh","s3_helper.py","capture-patterns.py","patterns-captured.json",')
archive=archive.replace('raw=path.read_text();clean=redact(raw,secrets);redactions+=raw!=clean','''if path.suffix==".bin":
   data=path.read_bytes()
   if any(secret.encode() in data for secret in secrets):raise RuntimeError("Credential match in binary artifact")
  else:
   raw=path.read_text();clean=redact(raw,secrets);redactions+=raw!=clean
   if any(secret in clean for secret in secrets):raise RuntimeError("Unredacted credential detected")
   data=clean.encode()''')
archive=archive.replace('  if any(secret in clean for secret in secrets):raise RuntimeError("Unredacted credential detected")\n  data=clean.encode();name=', '  name=')
with s.file(r+'/archive-public.py','w') as f:f.write(archive)
_,o,e=c.exec_command('cd '+r+' && python3 -m py_compile archive-public.py && nohup python3 capture-patterns.py >capture-patterns.log 2>&1 </dev/null &');print('Reconstructable fixture blocks queued before data cleanup');s.close();c.close()
