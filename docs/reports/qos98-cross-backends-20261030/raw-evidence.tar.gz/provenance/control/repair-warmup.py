import pathlib,json,paramiko
x=json.loads(pathlib.Path('.scratch/qos-cross/remote.json').read_text());r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('tests/lab/run-cross-backend-qos.py',r+'/run-cross-backend-qos.py')
script='''import pathlib,time,os,json,subprocess,shutil
root=pathlib.Path.cwd()
while True:
 active=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit():continue
  try:
   args=(p/"cmdline").read_bytes().split(b"\\0")
   if b"run-cross-backend-qos.py" in args and b"warmup" in args and pathlib.Path(os.readlink(p/"cwd"))==root:active.append(int(p.name))
  except OSError:pass
 if not active:break
 time.sleep(1)
for name in ["warmup.log","warmup-checks.json","preparation"]:
 path=root/name
 if path.exists():path.rename(root/("initial-"+name))
command=["python3","run-cross-backend-qos.py","--config","endpoints.private.json","--root",str(root),"--binary",str(root/"qos-bin"),"--stage"]
results=[]
for phase in ["warmup","seed","survey","limits"]:
 with open(phase+".log","w") as f:code=subprocess.run(command+[phase],stdout=f,stderr=subprocess.STDOUT).returncode
 results.append([phase,code]);print(phase,code,flush=True)
 if code and phase in ["warmup","seed"]:break
(root/"matrix-status.json").write_text(json.dumps(results,indent=2));print("DONE",results,flush=True)
'''
with s.file(r+'/orchestrate.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 orchestrate.py >orchestrate.log 2>&1 </dev/null &',timeout=10);print('Warmup fixture directory fixed; fresh warmup and full matrix queued');s.close();c.close()
