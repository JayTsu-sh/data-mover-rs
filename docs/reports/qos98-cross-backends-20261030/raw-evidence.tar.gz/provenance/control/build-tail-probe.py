import pathlib,subprocess,shutil,hashlib
paths=['crates/backend-hdfs/src/backend/writer.rs','crates/backend-s3/src/backend/staged/parts.rs','crates/backend-s3/src/backend/staged/at_destination.rs']
originals={p:pathlib.Path(p).read_bytes() for p in paths}
replacements={
paths[0]:[('    let closed = writer.close().await;', '    let tail_probe = std::time::Instant::now();\n    let closed = writer.close().await;\n    eprintln!("[TAIL-PROBE] hdfs_close_ns={}", tail_probe.elapsed().as_nanos());')],
paths[1]:[('        if !buffered.is_empty() || (progress.sent.parts.is_empty() && inflight.is_empty()) {','        let tail_probe = std::time::Instant::now();\n        if !buffered.is_empty() || (progress.sent.parts.is_empty() && inflight.is_empty()) {'),('        progress.sent.parts.sort_by_key(|part| part.0);','        eprintln!("[TAIL-PROBE] s3_final_parts_ns={}", tail_probe.elapsed().as_nanos());\n        progress.sent.parts.sort_by_key(|part| part.0);')],
paths[2]:[('        let facts = self\n            .complete_final_upload(path, upload, &parts, md5_etags, request.expected_size)','        let tail_probe = std::time::Instant::now();\n        let facts = self\n            .complete_final_upload(path, upload, &parts, md5_etags, request.expected_size)'),('        upload.lock().published = Some(facts.clone());','        eprintln!("[TAIL-PROBE] s3_complete_ns={}", tail_probe.elapsed().as_nanos());\n        upload.lock().published = Some(facts.clone());')]
}
written={}
try:
 for p,data in originals.items():
  text=data.decode()
  for old,new in replacements[p]:
   assert text.count(old)==1,(p,old);text=text.replace(old,new)
  pathlib.Path(p).write_text(text);written[p]=hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
 with open('/work/qos-cross-tail-probe-build.log','w') as log:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-cross-tail-probe')
finally:
 for p in written:
  if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=written[p]:raise RuntimeError('concurrent edits; not restoring '+p)
  pathlib.Path(p).write_bytes(originals[p])
print('Tail probe binary built; three source files restored byte-for-byte')
