import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp()
s.rename(r+'/duration-validation',r+'/duration-initial-preparation');s.rename(r+'/duration-validation.log',r+'/duration-initial-preparation.log')
with s.file(r+'/duration-validation.py') as f:script=f.read().decode()
script=script.replace('timeout=300','timeout=900')
script=script.replace('fixture=root/"fixtures"/f"{size}.bin";V.fixture(fixture,size*1024*1024)\n run(name,"seed-large",size,["--seed"])','fixture=root/"fixtures"/f"{size}.bin"\n if not fixture.exists():V.fixture(fixture,size*1024*1024)\n if name=="nfs41-to-s3":continue\n # Probe an already published fixture before attempting an expensive replacement.\n try:run(name,"validate-existing-seed",size,["--copy","--admission-trace","disabled"])\n except RuntimeError:run(name,"seed-large",size,["--seed"])')
with s.file(r+'/duration-validation.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 duration-validation.py >duration-validation.log 2>&1 </dev/null &');print('Preparation timeout retained; continued with 900s bound and existing-fixture verification');c.close()
