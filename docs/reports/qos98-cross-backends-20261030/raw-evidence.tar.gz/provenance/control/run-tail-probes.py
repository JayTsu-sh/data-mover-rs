import pathlib,json,paramiko
x=json.loads(pathlib.Path('.scratch/qos-cross/remote.json').read_text());r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();s.put('/work/qos-cross-tail-probe',r+'/tail-probe');s.chmod(r+'/tail-probe',0o700)
script='''import pathlib,json,os,subprocess,time
root=pathlib.Path.cwd()
while not (root/"duration-validation/status.json").exists():time.sleep(2)
config=json.load(open("matrix.private.json"));rows={p["name"]:p for p in config["profiles"]};folder=root/"tail-probes";folder.mkdir()
for name in ["local-to-s3","nfs41-to-s3","s3-to-hdfs"]:
 summary=json.load(open(root/"limits"/name/"summary.json"))[name]
 for repeat in range(2):
  p=rows[name];cmd=["./tail-probe","--source","fixtures","--destination","warm-destination","--path","128.bin","--chunk-bytes",str(p["chunk_bytes"]),"--copy","--transfer-profile",p["transfer_profile"],"--destination-cleanup","delete","--soft-iops",str(summary["soft_iops"]),"--hard-iops",str(summary["soft_iops"])]
  run=subprocess.run(cmd,env={**os.environ,**p["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=120)
  if run.returncode:raise RuntimeError("Tail probe failed; endpoint-bearing stderr omitted")
  (folder/(name+"-"+str(repeat)+".json")).write_text(run.stdout);(folder/(name+"-"+str(repeat)+".stderr")).write_text(run.stderr)
  print(name,repeat,json.loads(run.stdout)["seconds"],run.stderr,flush=True)
(folder/"status.json").write_text(json.dumps({"completed":6,"diagnostic_only":True}))
'''
with s.file(r+'/run-tail-probes.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 run-tail-probes.py >tail-probes.log 2>&1 </dev/null &',timeout=10);print('Six tail probes queued after duration survey, acceptance binary unchanged');s.close();c.close()
