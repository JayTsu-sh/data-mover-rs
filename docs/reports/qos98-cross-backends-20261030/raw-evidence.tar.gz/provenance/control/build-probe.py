import pathlib,subprocess,hashlib,shutil
p=pathlib.Path('crates/storage-core/src/runtime/qos.rs');original=p.read_bytes();text=original.decode();backup=pathlib.Path('.scratch/qos-cross/qos.rs.original');backup.write_bytes(original)
text=text.replace('const HARD_SHAPING_QUANTUM:', '''static QOS_PROBE_CALLS: AtomicU64 = AtomicU64::new(0);
static QOS_PROBE_WAITS: AtomicU64 = AtomicU64::new(0);
static QOS_PROBE_NS: AtomicU64 = AtomicU64::new(0);

impl Drop for GroupInner {
    fn drop(&mut self) {
        eprintln!("[QOS-PROBE] calls={} waits={} admission_ns={}", QOS_PROBE_CALLS.load(Ordering::Relaxed), QOS_PROBE_WAITS.load(Ordering::Relaxed), QOS_PROBE_NS.load(Ordering::Relaxed));
    }
}

const HARD_SHAPING_QUANTUM:''',1)
text=text.replace('        if granted == 0 {','        let qos_probe_started = std::time::Instant::now();\n        if granted == 0 {',1)
text=text.replace('        if !immediate && deadline > tokio::time::Instant::now() {','        if !immediate && deadline > tokio::time::Instant::now() {\n            QOS_PROBE_WAITS.fetch_add(1, Ordering::Relaxed);',1)
text=text.replace('        Ok(granted)\n    }','        QOS_PROBE_CALLS.fetch_add(1, Ordering::Relaxed);\n        QOS_PROBE_NS.fetch_add(qos_probe_started.elapsed().as_nanos() as u64, Ordering::Relaxed);\n        Ok(granted)\n    }',1)
p.write_text(text);instrumented=hashlib.sha256(p.read_bytes()).hexdigest()
try:
 with open('/work/qos-cross-probe-build.log','w') as log:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-cross-admission-probe')
 pathlib.Path('.scratch/qos-cross/admission-probe.patch').write_text(subprocess.check_output(['git','diff','--','crates/storage-core/src/runtime/qos.rs'],text=True))
finally:
 if hashlib.sha256(p.read_bytes()).hexdigest()!=instrumented:raise RuntimeError('concurrent source edits detected; preserving them instead of restoring')
 p.write_bytes(original)
print('Profiling-only binary built; original QoS source restored byte-for-byte')
