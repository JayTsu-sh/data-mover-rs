import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp()
script='''import pathlib,json,tarfile,io,hashlib,time,os
from qos_evidence import secret_values,redact
root=pathlib.Path.cwd()
config=json.load(open("endpoints.private.json"));environments=[p.get("env",{}) for p in [*config["sources"].values(),*config["destinations"].values()]]
secrets=secret_values(environments)
secrets=sorted(set(secrets+[json.dumps(s)[1:-1] for s in secrets]),key=len,reverse=True)
dirs=["survey","limits","calibration","preparation","initial-preparation","duration-initial-preparation","duration-validation","admission-probes","tail-probes"]
names=["prepare.log","initial-warmup.log","initial-warmup-checks.json","warmup.log","warmup-checks.json","seed.log","seed-checks.json","survey.log","limits.log","limits-checks.json","matrix-status.json","calibrate.log","calibration-status.json","extended.log","extended-calibration-status.json","baseline-origins.json","baseline-origins-first-long.json","matrix-public.json","environment-public.json","duration-initial-preparation.log","duration-validation.log","admission-probes.log","tail-probes.log","destination-vmstat.log","cleanup.log","cleanup-status.json","cleanup-extra.log","cleanup-standard.log","orchestrate.py","calibrate.py","extended.py","duration-validation.py","run-admission-probes.py","run-tail-probes.py","run-backend-qos.py","run-cross-backend-qos.py","run-local-qos.py","cross_qos_matrix.py","qos_evidence.py"]
paths=[root/name for name in names if (root/name).is_file()]
for dirname in dirs:
 if (root/dirname).is_dir():paths.extend(p for p in (root/dirname).rglob("*") if p.is_file() and ".private." not in p.name and p.suffix in (".json",".log",".stderr"))
paths+=list(root.glob("limits-*.log"));manifest=[];redactions=0
archive=root/"public-evidence.tar.gz"
with tarfile.open(archive,"w:gz") as tar:
 for path in sorted(set(paths)):
  raw=path.read_text();clean=redact(raw,secrets);redactions+=raw!=clean
  if any(secret in clean for secret in secrets):raise RuntimeError("Unredacted credential detected")
  data=clean.encode();name=str(path.relative_to(root));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));manifest.append({"path":name,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)})
(root/"archive-audit.json").write_text(json.dumps({"files":len(manifest),"files_redacted":redactions,"credential_scan_passed":True,"private_configs_excluded":True,"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"manifest":manifest},indent=2))
print("Public archive",len(manifest),"files; credential scan passed;",redactions,"files redacted")
'''
with s.file(r+'/archive-public.py','w') as f:f.write(script)
print('Credential-scanned archive builder prepared; not run until all measurements and cleanup finish');s.close();c.close()
