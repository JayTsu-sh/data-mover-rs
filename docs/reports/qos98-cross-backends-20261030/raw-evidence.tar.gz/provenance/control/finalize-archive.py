from pathlib import Path
import json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();p=x['root']+'/archive-public.py';v=s.open(p).read().decode();v=v.replace('"optimization"]','"optimization","pressure"]');v=v.replace('names=[','names=["pressure.log","pressure-cleanup.log","run-pressure.py","finish-pressure.py",');v=v.replace('and p.suffix in (".json",".log",".stderr",".bin")','and (p.suffix in (".json",".log",".stderr") or p.name.endswith(".block.bin"))')
with s.file(p,'w') as f:f.write(v)
s.close();c.close()
