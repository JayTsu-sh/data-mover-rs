import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp();s.put('tests/lab/cross_qos_matrix.py',r+'/cross_qos_matrix.py');s.put('tests/lab/qos_evidence.py',r+'/qos_evidence.py')
script='''import pathlib,json,hashlib,platform,subprocess
from cross_qos_matrix import validate_override
root=pathlib.Path.cwd();matrix=json.load(open("matrix.private.json"));rows={p["name"]:p for p in matrix["profiles"]};overrides=json.load(open("baseline-overrides.private.json"));origins={}
for name,entry in overrides.items():
 replacement=json.load(open(entry["config"]));revised=next(p for p in replacement["profiles"] if p["name"]==name);validate_override(rows[name],revised)
 origins[name]={k:v for k,v in entry.items() if k!="config"};origins[name]["configuration_sha256"]=hashlib.sha256(json.dumps(replacement,sort_keys=True).encode()).hexdigest();origins[name]["only_performance_size_changed"]=True
(root/"baseline-origins.json").write_text(json.dumps(origins,indent=2))
profiles=[{k:v for k,v in p.items() if k!="env"} for p in matrix["profiles"]]
(root/"matrix-public.json").write_text(json.dumps({"run_id":matrix["run_id"],"profiles":profiles},indent=2))
env={"run_id":matrix["run_id"],"platform":platform.platform(),"cpu_count":__import__("os").cpu_count(),"binary_sha256":hashlib.sha256((root/"qos-bin").read_bytes()).hexdigest(),"admission_probe_sha256":hashlib.sha256((root/"admission-probe").read_bytes()).hexdigest(),"tail_probe_sha256":hashlib.sha256((root/"tail-probe").read_bytes()).hexdigest(),"filesystem":subprocess.check_output(["df","-T",str(root)],text=True),"memory":subprocess.check_output(["free","-b"],text=True),"performance_workers":1,"finite_workers":4,"runtime_workers_per_process":4,"source_warming":"local golden hash before every timer; remote source caching inherited from preparation and repeated copies, no cache flush"}
(root/"environment-public.json").write_text(json.dumps(env,indent=2));print("All six baseline override identities independently verified; public provenance exported")
'''
with s.file(r+'/export-public.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && python3 export-public.py');print(o.read().decode(),e.read().decode());s.close();c.close()
