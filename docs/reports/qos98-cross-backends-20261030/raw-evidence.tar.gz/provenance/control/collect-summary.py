import pathlib,json,paramiko
x=json.loads(pathlib.Path('.scratch/qos-cross/remote.json').read_text());r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp();checks=[];summary={}
for name in s.listdir(r+'/limits'):
 for fname in ['checks.json','summary.json']:
  with s.file(r+'/limits/'+name+'/'+fname) as f:data=json.load(f)
  if fname=='checks.json':checks+=data
  else:summary.update(data)
p=pathlib.Path('/work/qos-cross-evidence');(p/'checks.json').write_text(json.dumps(checks,indent=2));(p/'summary.json').write_text(json.dumps(summary,indent=2));print('main checks',sum(g['passed'] for g in checks),'/',len(checks))
for n,v in sorted(summary.items()):print(n,'baseline',round(v['baseline_mibps'],3),'high ratio',round(v['high_ratio'],5),'BW',round(v['cases']['bandwidth-strict']['ratio'],5),'IOPS',round(v['cases']['iops-strict']['ratio'],5))
s.close();c.close()
