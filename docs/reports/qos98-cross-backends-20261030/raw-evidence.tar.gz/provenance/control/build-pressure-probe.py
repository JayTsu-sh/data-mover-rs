from pathlib import Path
import subprocess,hashlib,shutil
p=Path('crates/backend-s3/src/backend/client.rs');original=p.read_bytes();Path('.scratch/qos-cross/pressure-client.rs.original').write_bytes(original)
module=Path('crates/backend-s3/src/backend/client/pressure_probe.rs');assert not module.exists()
code='''use aws_smithy_runtime_api::box_error::BoxError;
use aws_smithy_runtime_api::client::interceptors::Intercept;
use aws_smithy_runtime_api::client::interceptors::context::BeforeTransmitInterceptorContextRef;
use aws_smithy_runtime_api::client::runtime_components::RuntimeComponents;
use aws_smithy_types::config_bag::ConfigBag;
#[derive(Debug)]
pub(super) struct PressureProbe;
impl Intercept for PressureProbe {
 fn name(&self) -> &'static str { "PressureProbe" }
 fn read_before_transmit(&self, context: &BeforeTransmitInterceptorContextRef<'_>, _: &RuntimeComponents, _: &mut ConfigBag) -> Result<(), BoxError> {
  let request=context.request();let method=request.method();
  let query=request.uri().split_once('?').map_or("", |(_, q)|q);
  let has=|key: &str| query.split('&').any(|v|v==key||v.split_once('=').is_some_and(|(k,_)|k==key));
  let range=request.headers().get("range").and_then(|r|r.strip_prefix("bytes=")).and_then(|r|r.split_once('-')).and_then(|(a,b)|Some(b.parse::<u64>().ok()?.saturating_sub(a.parse::<u64>().ok()?).saturating_add(1)));
  let kind=if range.is_some(){"range-get"}else if method=="PUT"&&has("partNumber"){"upload-part"}else if method=="POST"&&has("uploadId"){"complete-multipart"}else if method=="POST"&&has("uploads"){"create-multipart"}else if method=="GET"&&has("uploads"){"list-multipart"}else if method=="GET"&&has("uploadId"){"list-parts"}else if method=="GET"&&has("versioning"){"bucket-versioning"}else if method=="HEAD"{"head-object"}else if method=="DELETE"{"delete"}else{"other"};
  let body=request.headers().get("content-length").and_then(|v|v.parse::<u64>().ok()).unwrap_or(0);
  eprintln!("[S3-PRESSURE] method={method} kind={kind} range_bytes={} body_bytes={body}",range.unwrap_or(0));Ok(())
 }
}
'''
Path('.scratch/qos-cross/pressure_probe.rs').write_text(code);module.write_text(code)
s=original.decode().replace('mod architecture;','mod architecture;\nmod pressure_probe;',1).replace('configure_compatibility(builder, compatibility).build()','configure_compatibility(builder.interceptor(pressure_probe::PressureProbe), compatibility).build()',1);p.write_text(s);edited=hashlib.sha256(p.read_bytes()).hexdigest()
try:
 with open('/work/qos-cross-pressure-probe-build.log','w') as f:subprocess.run(['cargo','build','--release','--locked','--features','qos-diagnostics','--example','backend_qos_acceptance'],stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copy2('/work/cargo-target/release/examples/backend_qos_acceptance','/work/qos-cross-pressure-probe')
finally:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==edited
 p.write_bytes(original);module.unlink()
print('Request-attempt probe built; original S3 client restored byte-for-byte')
