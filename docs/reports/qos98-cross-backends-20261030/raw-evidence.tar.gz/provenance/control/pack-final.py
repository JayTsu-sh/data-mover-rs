from pathlib import Path
import json,tarfile,hashlib,io,importlib.util,paramiko
base=Path('/work/qos-cross-evidence');out=Path('docs/reports/qos98-cross-backends-20261030');out.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('qos_evidence','tests/lab/qos_evidence.py');Q=importlib.util.module_from_spec(spec);spec.loader.exec_module(Q)
x=json.load(open('.scratch/qos-cross/remote.json'));c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp();cfg=json.load(s.open(x['root']+'/endpoints.private.json'));secrets=Q.secret_values([p.get('env',{}) for p in [*cfg['sources'].values(),*cfg['destinations'].values()]]);s.close();c.close()
secrets=sorted(set(secrets+[json.dumps(v)[1:-1] for v in secrets]),key=len,reverse=True)
additions=[]
for f in json.load(open(base/'source-manifest.json'))['files']:additions.append(('source-snapshot/'+f['path'],Path(f['path']).read_bytes()))
for p in sorted(Path('.scratch/qos-cross').glob('*')):
 if p.suffix in ['.py','.rs','.patch']:additions.append(('provenance/control/'+p.name,p.read_bytes()))
for p in sorted(Path('/work').glob('qos-cross-*.log')):additions.append(('validation-logs/'+p.name,p.read_bytes()))
for name in ['source-manifest.json','working-tree.patch','remote-archive-audit.json','validation.json','audit.log']:additions.append(('provenance/'+name,(base/name).read_bytes()))
manifest=[]
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as dst:
 def put(name,data):
  assert not name.startswith('/') and '..' not in Path(name).parts
  assert not any(v.encode() in data for v in secrets), 'Credential match in '+name
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;dst.addfile(item,io.BytesIO(data));manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 with tarfile.open(base/'remote-public-evidence.tar.gz') as src:
  for item in src.getmembers():assert item.isfile();put(item.name,src.extractfile(item).read())
 for name,data in additions:put(name,data)
assert len({p['path'] for p in manifest})==len(manifest)
audit=dict(credential_scan_passed=True,files=len(manifest),all_files_sha256=manifest,archive_sha256=hashlib.sha256((out/'raw-evidence.tar.gz').read_bytes()).hexdigest(),remote_manifest_preserved='provenance/remote-archive-audit.json',large_fixtures_and_credentials_excluded=True)
with tarfile.open(out/'raw-evidence.tar.gz') as tar:
 assert len(tar.getmembers())==len(manifest)
 for item,row in zip(tar.getmembers(),manifest):assert item.name==row['path'] and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==row['sha256']
(out/'archive-audit.json').write_text(json.dumps(audit,indent=2));print('Final archive credential scan and per-file SHA verified:',len(manifest),'files,',(out/'raw-evidence.tar.gz').stat().st_size,'bytes')
