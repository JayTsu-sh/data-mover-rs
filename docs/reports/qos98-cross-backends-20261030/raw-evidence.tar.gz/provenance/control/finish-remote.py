import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp();s.put('tests/lab/qos_evidence.py',r+'/qos_evidence.py')
for name in ['duration-validation/status.json','tail-probes/status.json','patterns-captured.json','optimization/tail-2m/status.json']:
 with s.file(r+'/'+name) as f:json.load(f)
with s.file(r+'/archive-public.py') as f:script=f.read().decode()
script=script.replace('"fixture-patterns"]','"fixture-patterns","optimization"]')
script=script.replace('names=[','names=["optimization-1m.log","optimization-2m.log","quick-tail.py","quick-tail2.py",')
with s.file(r+'/archive-public.py','w') as f:f.write(script)
with s.file(r+'/finish-testing','w') as f:f.write('All original, duration, diagnostic and rejected optimization measurements completed.\n')
print('All measurements and fixture blocks verified present; exact-run cleanup triggered')
s.close();c.close()
