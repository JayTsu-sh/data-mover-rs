import pathlib,json,paramiko,tarfile,hashlib
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];base=pathlib.Path('/work/qos-cross-evidence');c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
_,o,e=c.exec_command('cd '+r+' && python3 archive-public.py',timeout=90);out=o.read().decode();err=e.read().decode();code=o.channel.recv_exit_status();print(out,err);assert code==0
s.get(r+'/public-evidence.tar.gz',str(base/'remote-public-evidence.tar.gz'));s.get(r+'/archive-audit.json',str(base/'remote-archive-audit.json'));audit=json.load(open(base/'remote-archive-audit.json'));assert hashlib.sha256((base/'remote-public-evidence.tar.gz').read_bytes()).hexdigest()==audit['archive_sha256']
root=base/'raw';root.mkdir(exist_ok=True)
with tarfile.open(base/'remote-public-evidence.tar.gz') as tar:
 for member in tar.getmembers():
  assert member.isfile();target=root/member.name;assert target.resolve().is_relative_to(root.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
print('Public archive downloaded and safely extracted',audit['files'],'files')
s.close();c.close()
