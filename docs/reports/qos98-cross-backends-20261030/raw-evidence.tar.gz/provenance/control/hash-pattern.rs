fn main() {
    let mut args = std::env::args().skip(1);
    let block = std::fs::read(args.next().expect("block path")).expect("read block");
    let repeat: usize = args.next().expect("repeat count").parse().expect("integer");
    let mut hasher = blake3::Hasher::new();
    for _ in 0..repeat { hasher.update(&block); }
    println!("{}", hasher.finalize().to_hex());
}
