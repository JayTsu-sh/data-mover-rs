import pathlib,json,paramiko
x=json.load(open('.scratch/qos-cross/remote.json'));r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root');s=c.open_sftp();s.put('/work/cargo-target/release/examples/backend_qos_acceptance',r+'/qos-tail-2m');s.chmod(r+'/qos-tail-2m',0o700)
script='''import pathlib,json,subprocess,os,hashlib,importlib.util
root=pathlib.Path.cwd();config=json.load(open("matrix.private.json"));folder=root/"optimization"/"tail-2m";folder.mkdir(parents=True);checks=[]
spec=importlib.util.spec_from_file_location("validator",root/"run-local-qos.py");V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
for name in ["local-to-s3","nfs41-to-s3","cifs-to-s3","hdfs-to-s3"]:
 p=next(p for p in config["profiles"] if p["name"]==name);soft=json.load(open(root/"limits"/name/"summary.json"))[name]["soft_iops"];case=folder/name;case.mkdir()
 for arm,binary in [("original","qos-bin"),("candidate","qos-tail-2m")]:
  cmd=[str(root/binary),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path","128.bin","--chunk-bytes",str(p["chunk_bytes"]),"--copy","--transfer-profile","cross","--destination-cleanup","delete","--soft-iops",str(soft),"--hard-iops",str(soft)]
  run=subprocess.run(cmd,env={**os.environ,**p["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=180)
  if run.returncode:raise RuntimeError("Tail candidate failed; private stderr omitted")
  data=json.loads(run.stdout);data["command"]=cmd;(case/(arm+".json")).write_text(json.dumps(data));trace=V.validate_trace(data,"iops",soft,soft,2,False);ratio=data["iops"]/soft
  for gate,passed in [("end_to_end_at_least_98_percent",ratio>=.98),*[(key,trace[key]) for key in ["hard_envelope","soft_envelope","steady_ceiling","steady_at_least_98_percent"]]]:checks.append(dict(profile=name,arm=arm,name=gate,passed=passed,ratio=ratio,soft=soft,binary_sha256=hashlib.sha256((root/binary).read_bytes()).hexdigest()))
  (folder/"checks.json").write_text(json.dumps(checks,indent=2));print(name,arm,ratio,flush=True)
(folder/"status.json").write_text(json.dumps({"complete":True}))
'''
with s.file(r+'/quick-tail2.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 quick-tail2.py >optimization-2m.log 2>&1 </dev/null &');print('Four paired original/2MiB-tail strict IO copies started');s.close();c.close()
