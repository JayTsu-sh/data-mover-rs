import pathlib,json,paramiko
x=json.loads(pathlib.Path('.scratch/qos-cross/remote.json').read_text());r=x['root'];c=paramiko.SSHClient();c.set_missing_host_key_policy(paramiko.AutoAddPolicy());c.connect(x['host'],username='root',timeout=10);s=c.open_sftp()
script='''import pathlib,json,subprocess,os,importlib.util,statistics,concurrent.futures,hashlib,time
root=pathlib.Path.cwd();folder=root/"duration-validation";folder.mkdir()
spec=importlib.util.spec_from_file_location("validator",root/"run-local-qos.py");V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
config=json.load(open("matrix.private.json"));rows={p["name"]:p for p in config["profiles"]}
highs={"nfs41-to-s3":2048,"s3-to-hdfs":12288}
failed=[g for path in (root/"limits").glob("*/checks.json") for g in json.load(open(path)) if not g["passed"] and g["case"]!="high"]
plan={"high_sizes_mib":highs,"high_pairs":5,"equal_idle_ms":1000,"finite_size_mib":512,"finite_cases":[{k:g[k] for k in ["profile","case","soft"]} for g in failed],"rate_change":False,"threshold":0.98,"original_failures_retained":True}
(folder/"plan.json").write_text(json.dumps(plan,indent=2));checks=[]
def command(name,size,extra=()):
 p=rows[name];return [str(root/"qos-bin"),"--source",str(root/"fixtures"),"--destination",str(root/"warm-destination"),"--path",f"{size}.bin","--chunk-bytes",str(p["chunk_bytes"]),"--transfer-profile",p["transfer_profile"],"--destination-cleanup","delete",*extra]
def run(name,label,size,extra):
 case=folder/name;case.mkdir(exist_ok=True)
 result=subprocess.run(command(name,size,extra),env={**os.environ,**rows[name]["env"],"NO_PROXY":"*","no_proxy":"*"},capture_output=True,text=True,timeout=300)
 # Never retain raw failure text that may include endpoint credentials.
 if result.returncode:raise RuntimeError(f"{name}/{label}: exit {result.returncode}; stderr omitted")
 data=json.loads(result.stdout);(case/(label+".json")).write_text(json.dumps(data));print(name,label,data.get("seconds"),flush=True);return data
for name,size in highs.items():
 fixture=root/"fixtures"/f"{size}.bin";V.fixture(fixture,size*1024*1024)
 run(name,"seed-large",size,["--seed"])
for name,size in highs.items():
 arms={"baseline":[],"high":[]}
 for repeat in range(5):
  for arm in (["baseline","high"] if repeat%2==0 else ["high","baseline"]):
   extra=["--copy","--idle-ms","1000","--admission-trace","disabled"]
   if arm=="high":extra += ["--soft-bytes",str(1<<40),"--hard-bytes",str(1<<40),"--soft-iops","1000000000","--hard-iops","1000000000"]
   data=run(name,arm+"-"+str(repeat),size,extra);arms[arm].append(data["mibps"])
 ratio=statistics.median(arms["high"])/statistics.median(arms["baseline"])
 check=dict(profile=name,case="high",name="matches_baseline_98_percent",passed=ratio>=.98,ratio=ratio,arms=arms,size_mib=size);checks.append(check)
 (folder/"high-checks.json").write_text(json.dumps(checks,indent=2));print("HIGH",name,ratio,flush=True)
# Finite qualification retains every original rate and grows only file size.
def finite(g):
 name=g["profile"];case=g["case"];resource="bandwidth" if case.startswith("bandwidth") else "iops";key="bytes" if resource=="bandwidth" else "iops";soft=g["soft"]
 data=run(name,case,512,["--copy",f"--soft-{key}",str(soft),f"--hard-{key}",str(soft)])
 trace=V.validate_trace(data,resource,soft,soft,.5,False);actual=data["bytes"]/data["seconds"] if key=="bytes" else data["iops"]
 out=[dict(profile=name,case=case,name="end_to_end_at_least_98_percent",passed=actual>=soft*.98,ratio=actual/soft,soft=soft,actual=actual,size_mib=512)]
 out += [dict(profile=name,case=case,name=k,passed=trace[k],trace=trace) for k in ["hard_envelope","soft_envelope","steady_ceiling","steady_at_least_98_percent"]]
 return out
# Separate destination keys by route, and serialize multiple cases of each route.
def route_finite(name):
 out=[]
 for g in failed:
  if g["profile"]==name:out+=finite(g)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for out in pool.map(route_finite,sorted({g["profile"] for g in failed})):
  checks+=out;(folder/"checks.json").write_text(json.dumps(checks,indent=2))
(folder/"status.json").write_text(json.dumps({"passed":sum(g["passed"] for g in checks),"total":len(checks),"finished_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}))
'''
with s.file(r+'/duration-validation.py','w') as f:f.write(script)
_,o,e=c.exec_command('cd '+r+' && nohup python3 duration-validation.py >duration-validation.log 2>&1 </dev/null &',timeout=10);print('Fixed long-duration validation launched (2 high routes, 8 exact-rate finite rechecks)');s.close();c.close()
