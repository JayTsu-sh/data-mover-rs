import pathlib,json,hashlib,statistics,math,importlib.util,csv,collections
base=pathlib.Path('/work/qos-cross-evidence');root=base/'raw'
spec=importlib.util.spec_from_file_location('validator',pathlib.Path('tests/lab/run-local-qos.py'));V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
checks=json.load(open(base/'checks.json'));summary=json.load(open(base/'summary.json'));expected={};finite_count=performance_count=0;binary=json.load(open(root/'environment-public.json'))['binary_sha256'];origins=json.load(open(root/'baseline-origins.json'));public=json.load(open(root/'matrix-public.json'))
manifest=json.load(open(base/'remote-archive-audit.json'))['manifest'];manifest_ok=all(hashlib.sha256((root/p['path']).read_bytes()).hexdigest()==p['sha256'] for p in manifest)
assert manifest_ok
for name,s in summary.items():
 folder=root/'limits'/name;env=json.load(open(folder/'environment.json'));assert env['binary_sha256']==binary
 origin=pathlib.Path(env['baseline_origin']).relative_to(pathlib.Path('/tmp/nightly-qos-cross-20261029192047'));baseline_env=json.load(open(root/origin/'environment.json'));assert baseline_env['binary_sha256']==binary and baseline_env['configuration_sha256']==env['configuration_sha256'];assert baseline_env['repetitions']==env['repetitions'] and baseline_env.get('performance_idle_ms',0)==env.get('performance_idle_ms',0)
 if name in origins:assert origins[name]['only_performance_size_changed'] and origins[name]['configuration_sha256']==env['configuration_sha256']
 else:assert public['configuration_sha256']==env['configuration_sha256']
 samples={}
 for arm in ['baseline','high']:
  samples[arm]=[]
  for i in range(env['repetitions']):
   p=folder/name/f'{arm}-{i}.json';data=json.load(open(p));assert p.read_bytes()==(root/origin/name/p.name).read_bytes();samples[arm].append(data);performance_count+=1
 baseline=statistics.median(d['mibps'] for d in samples['baseline']);high=statistics.median(d['mibps'] for d in samples['high']);cap=s['request_cap_bytes']
 assert all(d['effective_read_bytes']==cap and d['operations']==samples['baseline'][0]['operations'] for d in samples['baseline']+samples['high'])
 expected[(name,'high','matches_baseline_98_percent')]=high>=baseline*.98
 expected[(name,'capacity','bandwidth_headroom')]=baseline*1048576>=s['soft_bytes']*2*1.25
 expected[(name,'capacity','iops_headroom')]=statistics.median(d['iops'] for d in samples['baseline'])>=s['soft_iops']*2*1.25
 for case in ['bandwidth-strict','bandwidth-dual','iops-strict','iops-dual','combined']:
  data=json.load(open(folder/name/(case+'.json')));cmd=data['command'];peak=int(cmd[cmd.index('--peak-ms')+1])/1000;dual=case.endswith('dual') or case=='combined';finite_count+=1
  assert len(data['admissions'])==data['operations'] and sum(e['bytes'] for e in data['admissions'])==data['bytes']
  for resource in (['bandwidth','iops'] if case=='combined' else ['bandwidth' if case.startswith('bandwidth') else 'iops']):
   key='bytes' if resource=='bandwidth' else 'iops';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);trace=V.validate_trace(data,resource,soft,hard,peak,dual)
   actual=data['bytes']/data['seconds'] if key=='bytes' else data['iops']
   prefix=resource+'_' if case=='combined' else ''
   expected[(name,case,prefix+('end_to_end_98_percent' if case=='combined' else 'end_to_end_at_least_98_percent'))]=actual>=soft*.98
   for gate in ['hard_envelope','soft_envelope','steady_ceiling','steady_at_least_98_percent']+(['steady_window_after_peak','burst_observed'] if dual else []):expected[(name,case,prefix+gate)]=trace[gate]
assert len(expected)==len(checks)==943
assert all(g['passed']==expected[(g['profile'],g['case'],g['name'])] for g in checks)
measurements=[];digests=collections.defaultdict(set)
for path in root.rglob('*.json'):
 try:data=json.load(open(path))
 except (ValueError,UnicodeError):continue
 if not isinstance(data,dict) or not all(k in data for k in ['bytes','seconds','digest','mibps','operations']):continue
 if not data['bytes']:continue
 digests[data['bytes']].add(data['digest'])
 row={k:data.get(k) for k in ['bytes','operations','seconds','mibps','iops','digest','effective_read_bytes','verification_seconds','transfer_profile']};row['path']=str(path.relative_to(root));row['admissions']=len(data['admissions']);row['tail_after_last_admission_seconds']=data['seconds']-data['admissions'][-1]['seconds'] if data['admissions'] else None;measurements.append(row)
assert all(len(ds)==1 for ds in digests.values())
with (base/'measurements.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(measurements[0]));writer.writeheader();writer.writerows(sorted(measurements,key=lambda x:x['path']))
long=json.load(open(root/'duration-validation/checks.json'))
for g in long:
 if g['case']=='high':
  folder=root/'duration-validation'/g['profile'];arms={arm:[json.load(open(folder/f'{arm}-{i}.json'))['mibps'] for i in range(5)] for arm in ['baseline','high']};ratio=statistics.median(arms['high'])/statistics.median(arms['baseline']);assert math.isclose(ratio,g['ratio']) and g['passed']==(ratio>=.98)
 elif g['name']=='end_to_end_at_least_98_percent':
  d=json.load(open(root/'duration-validation'/g['profile']/(g['case']+'.json')));actual=d['bytes']/d['seconds'] if g['case'].startswith('bandwidth') else d['iops'];assert math.isclose(actual/g['soft'],g['ratio']) and g['passed']==(actual>=g['soft']*.98)
 else:
  d=json.load(open(root/'duration-validation'/g['profile']/(g['case']+'.json')));peer=next(p for p in long if p['profile']==g['profile'] and p['case']==g['case'] and p['name']=='end_to_end_at_least_98_percent');resource='bandwidth' if g['case'].startswith('bandwidth') else 'iops';t=V.validate_trace(d,resource,peer['soft'],peer['soft'],.5,False);assert g['passed']==t[g['name']]
out={'all_943_original_verdicts_reproduced':True,'main_passed':sum(g['passed'] for g in checks),'main_failed':sum(not g['passed'] for g in checks),'accepted_performance_samples':performance_count,'finite_samples':finite_count,'supplemental_duration_checks':len(long),'supplemental_duration_passed':sum(g['passed'] for g in long),'supplemental_verdicts_reproduced':True,'all_archive_manifest_hashes_verified':manifest_ok,'all_same_size_digests_match':True,'unique_digests_by_size':{str(k):list(v) for k,v in sorted(digests.items())},'all_measurement_files_including_copied_baselines':len(measurements),'baseline_binary_and_configuration_binding_verified':True,'override_route_and_policy_guard_verified_before_private_config_removal':True}
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

history=[]
for directory in [root/'survey', *sorted((root/'calibration').glob('*/survey')), *sorted((root/'calibration').glob('*/extended/survey'))]:
 env=json.load(open(directory/'environment.json'))
 for gate in json.load(open(directory/'checks.json')):
  if gate['case']!='high':continue
  data=json.load(open(directory/gate['profile']/'baseline-0.json'))
  history.append({'profile':gate['profile'],'kind':'performance-survey','path':str(directory.relative_to(root)),**{k:gate[k] for k in ['passed','ratio','baseline_mibps','high_mibps']},'size_mib':data['bytes']//1048576,'repetitions':env['repetitions'],'performance_idle_ms':env.get('performance_idle_ms',0),'binary_sha256':env['binary_sha256']})
for p in sorted((root/'calibration').glob('*/control-summary.json')):
 d=json.load(open(p));history.append({'profile':p.parent.name,'kind':'identical-unlimited-control','path':str(p.relative_to(root)),'ratio':d['ratio'],'repetitions':5,'size_mib':128})
for g in long:
 if g['case']=='high':history.append({'profile':g['profile'],'kind':'fixed-duration-supplement','path':'duration-validation','ratio':g['ratio'],'passed':g['passed'],'size_mib':g['size_mib'],'repetitions':5,'performance_idle_ms':1000,'binary_sha256':binary})
(base/'attempt-history.json').write_text(json.dumps(history,indent=2))

# Reconstruct full original payloads from five small repeated blocks, without disk-sized fixtures.
import subprocess
patterns=json.load(open(root/'fixture-patterns/manifest.json'))
for item in patterns:
 block=root/'fixture-patterns'/item['path'];assert hashlib.sha256(block.read_bytes()).hexdigest()==item['block_sha256']
 digest=subprocess.check_output(['/work/qos-cross-hash-pattern',str(block),str(item['repeat_count'])],text=True).strip()
 assert digest==item['reconstructed_blake3'] and digests[item['bytes']]=={digest}
for trial in ['tail-1m','tail-2m']:
 for gate in json.load(open(root/'optimization'/trial/'checks.json')):
  path=root/'optimization'/trial
  if trial=='tail-2m':path/=gate['profile']
  d=json.load(open(path/(gate['arm']+'.json')));soft=gate.get('soft',4);ratio=d['iops']/soft;assert math.isclose(ratio,gate['ratio'])
  if gate.get('name','end_to_end_at_least_98_percent')=='end_to_end_at_least_98_percent':assert gate['passed']==(ratio>=.98)
  else:assert gate['passed']==V.validate_trace(d,'iops',soft,soft,2,False)[gate['name']]
out['all_five_full_fixture_hashes_reconstructed_from_archived_blocks']=True
out['rejected_optimization_verdicts_reproduced']=True
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2))

# Independently verify actual per-attempt SDK request counts from stderr.
import re
pressure=json.load(open(root/'pressure/checks.json'));wire={}
for row in json.load(open(root/'pressure/summary.json')):
 route,case=row['route'],row['case'];events=re.findall(r'\[S3-PRESSURE\] method=(\S+) kind=(\S+) range_bytes=(\d+) body_bytes=(\d+)',(root/'pressure'/f'{route}-{case}.stderr').read_text());d=json.load(open(root/'pressure'/f'{route}-{case}.json'))
 kind='range-get' if route=='s3-to-local' else 'upload-part';sizes=[int(r if route=='s3-to-local' else b) for m,k,r,b in events if k==kind]
 results={'payload_request_count_no_inflation':len(sizes)==8,'payload_requests_remain_8MiB':sizes==[8388608]*8,'payload_wire_bytes_match':sum(sizes)==d['bytes']}
 assert dict(collections.Counter(e[1] for e in events))==row['counts']
 if route=='s3-to-local' and d['admissions']:results['wire_requests_match_qos_accounting']=len(sizes)==d['operations']
 if route=='local-to-s3':results['independent_readback_wire_bytes_match']=sum(int(r) for m,k,r,b in events if k=='range-get')==d['bytes']
 if d['admissions']:
  cmd=d['command'];resource='iops' if case=='iops-strict' else 'bandwidth';key='iops' if resource=='iops' else 'bytes';soft=int(cmd[cmd.index('--soft-'+key)+1]);hard=int(cmd[cmd.index('--hard-'+key)+1]);packet=1 if resource=='iops' else max(e['bytes'] for e in d['admissions']);peak=4 if case=='bandwidth-dual' else .5
  results.update(hard_envelope=V.envelope_excess(d['admissions'],hard,resource)<=packet+1e-6,soft_envelope=V.envelope_excess(d['admissions'],soft,resource)<=(hard-soft)*peak+packet+1e-6)
 for name,passed in results.items():wire[(route,case,name)]=passed
assert len(wire)==len(pressure)==44 and all(g['passed']==wire[(g['route'],g['case'],g['name'])] for g in pressure)
block=root/'pressure/64.block.bin';assert hashlib.sha256(block.read_bytes()).hexdigest()==json.load(open(root/'pressure/environment.json'))['fixture_block_sha256'];digest=subprocess.check_output(['/work/qos-cross-hash-pattern',str(block),'64'],text=True).strip();assert digests[64*1048576]=={digest}
new=[]
for name,s in summary.items():
 if not name.startswith('s3-to-'):continue
 for case in ['bandwidth-strict','bandwidth-dual','combined']:
  d=json.load(open(root/'limits'/name/name/(case+'.json')));expected=(d['bytes']+s['request_cap_bytes']-1)//s['request_cap_bytes'];new.append(dict(profile=name,case=case,name='s3_payload_requests_no_inflation',actual=d['operations'],expected=expected,passed=d['operations']==expected))
assert len(new)==12 and all(g['passed'] for g in new)
(base/'request-pressure-existing.json').write_text(json.dumps(new,indent=2));out.update(actual_sdk_pressure_verdicts_reproduced=True,actual_sdk_pressure_checks=44,actual_sdk_pressure_passed=sum(wire.values()),additional_existing_matrix_s3_request_count_checks=12,additional_s3_checks_passed=12,pressure_64MiB_fixture_hash_reconstructed=True,s3_cleanup_all_four_exact_scopes_empty=all(p['empty'] for p in json.load(open(root/'pressure/cleanup.json'))))
(base/'evidence-audit.json').write_text(json.dumps(out,indent=2));print('Additional SDK request pressure: 44/44; existing S3 count checks: 12/12')
