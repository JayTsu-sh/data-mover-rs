import pathlib,json,hashlib,time
root=pathlib.Path.cwd()
while not (root/"tail-probes/status.json").exists():time.sleep(2)
folder=root/"fixture-patterns";folder.mkdir();records=[]
measurements={16:"preparation/warm-local-to-local.json",128:"limits/local-to-local/local-to-local/bandwidth-strict.json",512:"survey/local-to-local/baseline-0.json",2048:"duration-validation/nfs41-to-s3/baseline-0.json",12288:"duration-validation/s3-to-hdfs/baseline-0.json"}
for size,reference in measurements.items():
 path=root/"fixtures"/f"{size}.bin";measured=json.load(open(root/reference));assert path.stat().st_size==measured["bytes"]==size*1024*1024
 with path.open("rb") as f:block=f.read(1024*1024)
 name=f"{size}.block.bin";(folder/name).write_bytes(block);records.append({"path":name,"repeat_count":size,"bytes":size*1024*1024,"block_sha256":hashlib.sha256(block).hexdigest(),"reconstructed_blake3":measured["digest"],"reference_measurement":reference})
(folder/"manifest.json").write_text(json.dumps(records,indent=2));(root/"patterns-captured.json").write_text(json.dumps({"blocks":len(records),"total_bytes":sum((folder/r["path"]).stat().st_size for r in records)}));print("Five reproducible 1MiB fixture blocks captured")
