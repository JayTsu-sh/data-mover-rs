import pathlib,time,os,json,subprocess,shutil
root=pathlib.Path.cwd()
while True:
 active=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit():continue
  try:
   args=(p/"cmdline").read_bytes().split(b"\0")
   if b"run-cross-backend-qos.py" in args and b"warmup" in args and pathlib.Path(os.readlink(p/"cwd"))==root:active.append(int(p.name))
  except OSError:pass
 if not active:break
 time.sleep(1)
for name in ["warmup.log","warmup-checks.json","preparation"]:
 path=root/name
 if path.exists():path.rename(root/("initial-"+name))
command=["python3","run-cross-backend-qos.py","--config","endpoints.private.json","--root",str(root),"--binary",str(root/"qos-bin"),"--stage"]
results=[]
for phase in ["warmup","seed","survey","limits"]:
 with open(phase+".log","w") as f:code=subprocess.run(command+[phase],stdout=f,stderr=subprocess.STDOUT).returncode
 results.append([phase,code]);print(phase,code,flush=True)
 if code and phase in ["warmup","seed"]:break
(root/"matrix-status.json").write_text(json.dumps(results,indent=2));print("DONE",results,flush=True)
