import pathlib,json,time,subprocess
root=pathlib.Path.cwd()
while not (root/"calibration-status.json").exists():time.sleep(2)
overrides=json.load(open("baseline-overrides.private.json"));original=json.loads(json.dumps(overrides));results=[]
(root/"baseline-origins-first-long.json").write_text(json.dumps(original,indent=2))
try:
 for name,entry in overrides.items():
  if entry["exit"]==0:continue
  folder=root/"calibration"/name/"extended";folder.mkdir()
  command=["python3","run-backend-qos.py","--config",entry["config"],"--root",str(root),"--binary",str(root/"qos-bin"),"--phase","survey","--profiles",name,"--reuse-fixtures","--retain-source","--repeats","15","--performance-idle-ms","1000","--output",str(folder/"survey")]
  print("extended requalification",name,"15 pairs, 512MiB, equal 1s idle",flush=True)
  with (folder/"survey.log").open("w") as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
  entry.update(baseline=str(folder/"survey"),repetitions=15,performance_idle_ms=1000,exit=code,reason="first long sample failed amid >2% identical-control variation; fixed 15-pair requalification with equal idle")
  results.append([name,code]);print(name,code,flush=True)
 (root/"baseline-overrides.private.json").write_text(json.dumps(overrides,indent=2));(root/"baseline-overrides.private.json").chmod(0o600)
finally:
 (root/"extended-calibration-status.json").write_text(json.dumps(results,indent=2));(root/"extended-calibration.done").write_text("finished")
