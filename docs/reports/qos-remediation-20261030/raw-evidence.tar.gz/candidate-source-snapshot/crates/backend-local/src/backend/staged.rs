use std::io;
#[cfg(unix)]
use std::os::unix::fs::FileExt as _;
#[cfg(windows)]
use std::os::windows::fs::FileExt as _;
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
#[cfg(any(test, feature = "test-support"))]
use std::time::Duration;

use async_trait::async_trait;
use bytes::Bytes;
use cap_std::ambient_authority;
use cap_std::fs::{Dir, OpenOptions};
use futures::future::BoxFuture;
use futures::{FutureExt, StreamExt};
use tokio::task::JoinSet;

use super::creation::create_directory;
#[cfg(any(unix, windows))]
use crate::model::AclEncoding;
use crate::model::{
    BackendIdentity, EntryOperationFailure, FailureClass, Operation, StoragePath, Transience,
};
use crate::storage::artifacts::{ArtifactKind, is_artifact_native};
use crate::storage::durability::sync_directory;
use crate::storage::{
    ByteStream, CheckpointObservation, DestinationPrepareRequest, MetadataMutation, PrepareRequest,
    PreparedStage, PublicationEvidence, PublicationFailure, PublishRequest, StagedDestination,
    StagedMetadataApplicationFailure, StorageRoleFailure, VerificationEvidence, VerifyRequest,
    WriteEvidence,
};

mod at_destination;
mod checkpoint;
mod direct;
mod directory_sync;
mod hash_checkpoint;
#[cfg(unix)]
mod owner_privilege;
mod positioned;
mod probe;
mod publication;
mod published_recovery;
mod verification;

#[cfg(unix)]
use owner_privilege::OwnerPrivilege;
use probe::WriteProbe;

/// Maximum size of one positional write submitted by the Local destination.
///
/// This is independent of the Local source's 2 MiB read ceiling. Upstream
/// pieces at or below this limit are submitted whole; larger pieces are split
/// into zero-copy `Bytes` slices by `consume_input`.
const LOCAL_MAX_WRITE_CHUNK_BYTES: usize = 8 * 1024 * 1024;
/// Recovery cadence is a durability policy and must not change when the write-task ceiling is
/// tuned. Files must be strictly larger than this interval to enable deferred recovery.
#[cfg(not(test))]
const LOCAL_DURABLE_CHECKPOINT_INTERVAL_BYTES: u64 = 256 * 1024 * 1024;
#[cfg(test)]
const LOCAL_DURABLE_CHECKPOINT_INTERVAL_BYTES: u64 = 4 * 64 * 1024;

fn write_all_at(
    data: &[u8],
    offset: u64,
    mut write_at: impl FnMut(&[u8], u64) -> io::Result<usize>,
) -> io::Result<u64> {
    let mut written = 0usize;
    while written < data.len() {
        let position = offset
            .checked_add(written as u64)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "write offset overflow"))?;
        let count = match write_at(&data[written..], position) {
            Ok(count) => count,
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            Err(error) => return Err(error),
        };
        if count == 0 {
            return Err(io::Error::new(
                io::ErrorKind::WriteZero,
                "short local write",
            ));
        }
        if count > data.len() - written {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "local write exceeded the submitted buffer",
            ));
        }
        written += count;
    }
    Ok(written as u64)
}

// Per-attempt state: only the first write to an exclusively created empty stage
// can infer EOF from completed contiguous positional writes. Reuse and recovery
// must still normalize any previous tail.
struct LocalStageState {
    directory: Arc<Dir>,
    file: std::sync::Mutex<Option<Arc<std::fs::File>>>,
    token: Bytes,
    final_path: StoragePath,
    relative: PathBuf,
    name: std::ffi::OsString,
    first_write: AtomicBool,
    /// The transfer identity a destination-kept stage's pointer records.
    transfer_identity: Option<[u8; 32]>,
}

pub struct LocalStagedDestination {
    #[cfg(any(test, feature = "test-support"))]
    root: Arc<PathBuf>,
    root_dir: Arc<Dir>,
    identity: BackendIdentity,
    write_concurrency: usize,
    write_chunk_bytes: usize,
    write_probe: Arc<WriteProbe>,
    directory_sync: Arc<directory_sync::DirectorySync>,
    #[cfg(unix)]
    owner_privilege: OwnerPrivilege,
}

impl LocalStagedDestination {
    fn validate_prepare_request(request: &PrepareRequest) -> Result<(), StorageRoleFailure> {
        if request.source.kind != crate::model::EntryKind::File {
            return Err(failure(
                request.final_destination.path(),
                Operation::Prepare,
                FailureClass::Unsupported,
            ));
        }
        let relative =
            Self::checked_relative(request.final_destination.path(), Operation::Prepare)?;
        if is_artifact_native(&relative) {
            return Err(failure(
                request.final_destination.path(),
                Operation::Prepare,
                FailureClass::Conflict,
            ));
        }
        Ok(())
    }

    pub fn new(
        root: impl Into<PathBuf>,
        identity: BackendIdentity,
        write_concurrency: usize,
    ) -> Result<Self, StorageRoleFailure> {
        if write_concurrency == 0 {
            return Err(failure(
                &StoragePath::root(),
                Operation::Prepare,
                FailureClass::InvalidInput,
            ));
        }
        let root = root.into();
        let root_dir = Dir::open_ambient_dir(&root, ambient_authority())
            .map_err(|error| io_failure(&StoragePath::root(), Operation::Prepare, &error))?;
        Ok(Self {
            #[cfg(any(test, feature = "test-support"))]
            root: Arc::new(root),
            root_dir: Arc::new(root_dir),
            identity,
            write_concurrency,
            write_chunk_bytes: LOCAL_MAX_WRITE_CHUNK_BYTES,
            write_probe: Arc::new(WriteProbe::default()),
            directory_sync: Arc::new(directory_sync::DirectorySync::default()),
            #[cfg(unix)]
            owner_privilege: OwnerPrivilege::current(),
        })
    }

    #[must_use]
    pub fn with_write_chunk_bytes(mut self, bytes: std::num::NonZeroUsize) -> Self {
        self.write_chunk_bytes = bytes.get().min(LOCAL_MAX_WRITE_CHUNK_BYTES);
        self
    }

    async fn stage_directory(
        &self,
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<Arc<Dir>, StorageRoleFailure> {
        stage.validate_owner(&self.identity).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            )
        })?;
        if let Some(state) = Self::local_state(stage, operation)? {
            return Ok(Arc::clone(&state.directory));
        }
        let relative = Self::stage_relative(stage, operation)?;
        let parent = relative
            .parent()
            .filter(|path| !path.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."))
            .to_owned();
        let root = Arc::clone(&self.root_dir);
        tokio::task::spawn_blocking(move || root.open_dir(parent))
            .await
            .map_err(|_| {
                failure(
                    stage.final_destination().path(),
                    operation,
                    FailureClass::Internal,
                )
            })?
            .map(Arc::new)
            .map_err(|error| io_failure(stage.final_destination().path(), operation, &error))
    }

    fn local_state(
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<Option<&LocalStageState>, StorageRoleFailure> {
        let Some(cached) = &stage.backend_state() else {
            return Ok(None);
        };
        let cached = cached
            .downcast_ref::<LocalStageState>()
            .filter(|cached| {
                cached.token == stage.token()
                    && &cached.final_path == stage.final_destination().path()
            })
            .ok_or_else(|| {
                failure(
                    stage.final_destination().path(),
                    operation,
                    FailureClass::Corruption,
                )
            })?;
        Ok(Some(cached))
    }

    fn cache_stage(
        stage: &mut PreparedStage,
        directory: Arc<Dir>,
        file: Option<Arc<std::fs::File>>,
        fresh: bool,
        transfer_identity: Option<[u8; 32]>,
    ) -> Result<(), StorageRoleFailure> {
        let relative = Self::stage_relative(stage, Operation::Prepare)?;
        let name = relative
            .file_name()
            .ok_or_else(|| {
                failure(
                    stage.final_destination().path(),
                    Operation::Prepare,
                    FailureClass::Corruption,
                )
            })?
            .to_owned();
        stage.set_backend_state(Some(Arc::new(LocalStageState {
            directory,
            file: std::sync::Mutex::new(file),
            token: stage.token().clone(),
            final_path: stage.final_destination().path().clone(),
            relative,
            name,
            first_write: AtomicBool::new(fresh),
            transfer_identity,
        })));
        Ok(())
    }

    fn take_fresh_write(stage: &PreparedStage) -> bool {
        stage
            .backend_state()
            .as_ref()
            .and_then(|state| state.downcast_ref::<LocalStageState>())
            .is_some_and(|state| state.first_write.swap(false, Ordering::Relaxed))
    }

    fn stage_name(
        &self,
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<std::ffi::OsString, StorageRoleFailure> {
        stage.validate_owner(&self.identity).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            )
        })?;
        if let Some(state) = Self::local_state(stage, operation)? {
            return Ok(state.name.clone());
        }
        let relative = Self::stage_relative(stage, operation)?;
        relative
            .file_name()
            .map(std::ffi::OsStr::to_os_string)
            .ok_or_else(|| {
                failure(
                    stage.final_destination().path(),
                    operation,
                    FailureClass::Corruption,
                )
            })
    }

    fn checkpoint_name(
        &self,
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<std::ffi::OsString, StorageRoleFailure> {
        stage.validate_owner(&self.identity).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            )
        })?;
        at_destination::artifact(
            stage.final_destination().path(),
            ArtifactKind::Pointer,
            false,
        )
    }

    /// The transfer identity of a destination-kept stage, which its pointer records.
    fn transfer_identity(
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<[u8; 32], StorageRoleFailure> {
        Self::local_state(stage, operation)?
            .and_then(|state| state.transfer_identity)
            .ok_or_else(|| {
                failure(
                    stage.final_destination().path(),
                    operation,
                    FailureClass::Corruption,
                )
            })
    }

    async fn persist_checkpoint(
        &self,
        stage: &PreparedStage,
        durable_prefix: u64,
    ) -> Result<(), StorageRoleFailure> {
        checkpoint::persist(self, stage, durable_prefix).await?;
        stage.checkpoint_recorded(durable_prefix);
        Ok(())
    }

    async fn reobserve_checkpoint(&self, stage: &PreparedStage) -> Result<u64, StorageRoleFailure> {
        checkpoint::reobserve(self, stage).await
    }

    fn checked_relative(
        path: &StoragePath,
        operation: Operation,
    ) -> Result<PathBuf, StorageRoleFailure> {
        let path_buf = PathBuf::from(path.as_str());
        if path_buf.as_os_str().is_empty()
            || path_buf.is_absolute()
            || path_buf.components().any(|component| {
                matches!(
                    component,
                    Component::ParentDir | Component::RootDir | Component::Prefix(_)
                )
            })
        {
            return Err(failure(path, operation, FailureClass::InvalidInput));
        }
        Ok(path_buf)
    }

    fn stage_relative(
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<PathBuf, StorageRoleFailure> {
        if let Some(state) = Self::local_state(stage, operation)? {
            return Ok(state.relative.clone());
        }
        let encoded = std::str::from_utf8(stage.token()).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Corruption,
            )
        })?;
        let storage_path = StoragePath::new(encoded.to_owned()).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Corruption,
            )
        })?;
        let relative = Self::checked_relative(&storage_path, operation)?;
        let final_relative = Self::checked_relative(stage.final_destination().path(), operation)?;
        // The only stage name is the deterministic one beside the final file, and only a stage
        // prepared at the destination has it.
        let expected =
            at_destination::artifact(stage.final_destination().path(), ArtifactKind::Stage, false)?;
        let colocated = stage.at_destination()
            && relative.parent() == final_relative.parent()
            && relative.file_name() == Some(expected.as_os_str());
        if !colocated {
            return Err(failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Corruption,
            ));
        }
        Ok(relative)
    }

    #[cfg(any(test, feature = "test-support"))]
    fn stage_full_path(
        &self,
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<PathBuf, StorageRoleFailure> {
        stage.validate_owner(&self.identity).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            )
        })?;
        Ok(self.root.join(Self::stage_relative(stage, operation)?))
    }

    fn write_piece(
        file: &std::fs::File,
        probe: &WriteProbe,
        offset: u64,
        data: &[u8],
    ) -> Result<u64, io::Error> {
        probe.before_write(offset);
        let written = write_all_at(data, offset, |remaining, position| {
            #[cfg(unix)]
            let result = file.write_at(remaining, position);
            #[cfg(windows)]
            let result = file.seek_write(remaining, position);
            result
        })?;
        probe.after_write(offset);
        Ok(written)
    }

    async fn settle_one(
        writes: &mut JoinSet<Result<u64, io::Error>>,
        path: &StoragePath,
    ) -> Result<u64, StorageRoleFailure> {
        match writes.join_next().await {
            Some(Ok(Ok(written))) => Ok(written),
            Some(Ok(Err(error))) => Err(io_failure(path, Operation::Write, &error)),
            Some(Err(_)) | None => Err(failure(path, Operation::Write, FailureClass::Internal)),
        }
    }

    async fn open_stage_file_for(
        &self,
        stage: &PreparedStage,
        operation: Operation,
        _acl_access: bool,
    ) -> Result<Arc<std::fs::File>, StorageRoleFailure> {
        if stage.recovered_publication().is_some() {
            return Err(failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            ));
        }
        stage.validate_owner(&self.identity).map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Conflict,
            )
        })?;
        if let Some(state) = Self::local_state(stage, operation)? {
            let cached = state
                .file
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            #[cfg(unix)]
            if let Some(file) = cached.as_ref() {
                return Ok(Arc::clone(file));
            }
            #[cfg(not(unix))]
            {
                let mut cached = cached;
                if !_acl_access {
                    if let Some(file) = cached.take() {
                        return Ok(file);
                    }
                }
            }
        }
        let name = self.stage_name(stage, operation)?;
        let staging = self.stage_directory(stage, operation).await?;
        let result = tokio::task::spawn_blocking(move || {
            let mut options = OpenOptions::new();
            options.read(true).write(true);
            #[cfg(windows)]
            if _acl_access {
                use cap_std::fs::OpenOptionsExt as _;
                use windows_sys::Win32::Foundation::{GENERIC_READ, GENERIC_WRITE};
                use windows_sys::Win32::Storage::FileSystem::{READ_CONTROL, WRITE_DAC};
                options.access_mode(GENERIC_READ | GENERIC_WRITE | READ_CONTROL | WRITE_DAC);
            }
            staging
                .open_with(name, &options)
                .map(cap_std::fs::File::into_std)
        })
        .await
        .map_err(|_| {
            failure(
                stage.final_destination().path(),
                operation,
                FailureClass::Internal,
            )
        })?;
        result
            .map(Arc::new)
            .map_err(|error| io_failure(stage.final_destination().path(), operation, &error))
    }

    async fn consume_input(
        &self,
        stage: &PreparedStage,
        input: &mut ByteStream,
        file: &Arc<std::fs::File>,
        writes: &mut JoinSet<Result<u64, io::Error>>,
    ) -> (u64, u64, Option<StorageRoleFailure>, bool) {
        let mut checkpoint = None;
        let result = self
            .consume_input_chunks(stage, input, file, writes, &mut checkpoint)
            .await;
        // A pending checkpoint owns persistence work: settle it before cleanup or final truncation.
        if let Some(pending) = checkpoint
            && let Err(error) = pending.await
        {
            return (result.0, result.1, Some(error), true);
        }
        result
    }

    async fn consume_input_chunks<'a>(
        &'a self,
        stage: &'a PreparedStage,
        input: &mut ByteStream,
        file: &Arc<std::fs::File>,
        writes: &mut JoinSet<Result<u64, io::Error>>,
        checkpoint: &mut Option<BoxFuture<'a, Result<(), StorageRoleFailure>>>,
    ) -> (u64, u64, Option<StorageRoleFailure>, bool) {
        let (mut issued, mut persisted) = (stage.write_offset(), stage.write_offset());
        let interval = stage
            .deferred_checkpoint()
            .as_ref()
            .map(|checkpoint| checkpoint.interval_bytes)
            .or_else(|| {
                stage
                    .recovery_enabled()
                    .then_some(LOCAL_DURABLE_CHECKPOINT_INTERVAL_BYTES)
            });
        let mut next_checkpoint =
            interval.and_then(|bytes| stage.write_offset().checked_add(bytes));
        loop {
            let item = if let Some(pending) = checkpoint.as_mut() {
                tokio::select! {
                    biased;
                    result = pending => {
                        *checkpoint = None;
                        if let Err(error) = result {
                            return (issued, persisted, Some(error), true);
                        }
                        continue;
                    }
                    item = input.next() => item,
                }
            } else {
                input.next().await
            };
            let Some(item) = item else {
                break;
            };
            let data = match item {
                Ok(data) => data,
                Err(error) => return (issued, persisted, Some(error), false),
            };
            if data.is_empty() {
                continue;
            }
            let mut piece_start = 0usize;
            while piece_start < data.len() {
                let piece_end = piece_start
                    .saturating_add(self.write_chunk_bytes)
                    .min(data.len());
                let piece = data.slice(piece_start..piece_end);
                let offset = issued;
                let Some(next_offset) = issued.checked_add(piece.len() as u64) else {
                    return (
                        issued,
                        persisted,
                        Some(failure(
                            stage.final_destination().path(),
                            Operation::Write,
                            FailureClass::InvalidInput,
                        )),
                        false,
                    );
                };
                issued = next_offset;
                self.spawn_write_piece(stage, file, writes, offset, piece);
                piece_start = piece_end;
                if writes.len() >= self.write_concurrency {
                    match Self::settle_one(writes, stage.final_destination().path()).await {
                        Ok(written) => persisted += written,
                        Err(error) => return (issued, persisted, Some(error), false),
                    }
                }
                if next_checkpoint.is_some_and(|threshold| issued >= threshold)
                    && stage
                        .deferred_checkpoint()
                        .as_ref()
                        .is_none_or(|checkpoint| issued < checkpoint.source_size)
                {
                    if let Some(pending) = checkpoint.take()
                        && let Err(error) = pending.await
                    {
                        return (issued, persisted, Some(error), true);
                    }
                    if let Err(error) = self
                        .drain_checkpoint_window(stage, writes, issued, &mut persisted)
                        .await
                    {
                        return (issued, persisted, Some(error), true);
                    }
                    *checkpoint = Some(
                        self.persist_synced_progress(stage, Arc::clone(file), issued)
                            .boxed(),
                    );
                    // Freeze confirmed ranges across fsync and snapshotting. The unarmed path
                    // retains its existing overlap between writes and pointer persistence.
                    if stage.checkpoint_enabled()
                        && let Some(pending) = checkpoint.take()
                        && let Err(error) = pending.await
                    {
                        return (issued, persisted, Some(error), true);
                    }
                    next_checkpoint = interval.and_then(|bytes| issued.checked_add(bytes));
                }
            }
        }
        (issued, persisted, None, false)
    }

    fn spawn_write_piece(
        &self,
        stage: &PreparedStage,
        file: &Arc<std::fs::File>,
        writes: &mut JoinSet<Result<u64, io::Error>>,
        offset: u64,
        piece: Bytes,
    ) {
        let file = Arc::clone(file);
        let probe = Arc::clone(&self.write_probe);
        let observer = stage.write_observer().clone();
        writes.spawn_blocking(move || {
            let written = Self::write_piece(&file, &probe, offset, &piece)?;
            if let Some(observer) = observer {
                observer.confirmed(offset, written);
            }
            Ok(written)
        });
    }

    async fn drain_checkpoint_window(
        &self,
        stage: &PreparedStage,
        writes: &mut JoinSet<Result<u64, io::Error>>,
        issued: u64,
        persisted: &mut u64,
    ) -> Result<(), StorageRoleFailure> {
        let mut first_failure = None;
        Self::drain_writes(
            writes,
            stage.final_destination().path(),
            persisted,
            &mut first_failure,
        )
        .await;
        if let Some(error) = first_failure {
            return Err(error);
        }
        if *persisted != issued {
            return Err(failure(
                stage.final_destination().path(),
                Operation::Write,
                FailureClass::Corruption,
            ));
        }
        Ok(())
    }

    async fn persist_synced_progress(
        &self,
        stage: &PreparedStage,
        file: Arc<std::fs::File>,
        prefix: u64,
    ) -> Result<(), StorageRoleFailure> {
        // Subsequent positional writes may be in flight. Never truncate to this older prefix.
        tokio::task::spawn_blocking(move || file.sync_data())
            .await
            .map_err(|_| {
                failure(
                    stage.final_destination().path(),
                    Operation::Write,
                    FailureClass::Internal,
                )
            })?
            .map_err(|error| {
                io_failure(stage.final_destination().path(), Operation::Write, &error)
            })?;
        hash_checkpoint::barrier(stage, prefix).await?;
        self.persist_progress(stage, prefix).await
    }

    async fn persist_progress(
        &self,
        stage: &PreparedStage,
        persisted: u64,
    ) -> Result<(), StorageRoleFailure> {
        // The claim is held since prepare, and the pointer is the whole recovery record. Once it
        // exists, failures must preserve the recoverable stage.
        self.persist_checkpoint(stage, persisted).await?;
        stage.set_recovery_enabled(true);
        Ok(())
    }

    async fn drain_writes(
        writes: &mut JoinSet<Result<u64, io::Error>>,
        path: &StoragePath,
        persisted: &mut u64,
        first_failure: &mut Option<StorageRoleFailure>,
    ) {
        while !writes.is_empty() {
            match Self::settle_one(writes, path).await {
                Ok(written) => *persisted += written,
                Err(error) if first_failure.is_none() => *first_failure = Some(error),
                Err(_) => {}
            }
        }
    }

    async fn sync_written_file(
        file: Arc<std::fs::File>,
        issued: u64,
        path: &StoragePath,
        normalize_length: bool,
        durable: bool,
    ) -> Result<(), StorageRoleFailure> {
        tokio::task::spawn_blocking(move || {
            if normalize_length {
                file.set_len(issued)?;
            }
            // Recovery and safe publication both need file contents plus the length metadata
            // required to read them. They do not require unrelated inode metadata.
            if durable {
                file.sync_data()?;
            }
            Ok::<_, io::Error>(())
        })
        .await
        .map_err(|_| failure(path, Operation::Write, FailureClass::Internal))?
        .map_err(|error| io_failure(path, Operation::Write, &error))
    }

    async fn cleanup_stage_artifacts(
        &self,
        stage: &PreparedStage,
        operation: Operation,
    ) -> Result<(), StorageRoleFailure> {
        at_destination::cleanup(self, stage, operation).await
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn set_automatic_checkpoint_interval(&self, bytes: u64) {
        self.write_probe
            .automatic_interval
            .store(bytes, Ordering::Relaxed);
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn fail_checkpoint_at(&self, point: u64) {
        self.write_probe
            .checkpoint_failure
            .store(point, Ordering::SeqCst);
    }

    fn open_or_create_parent(root: &Dir, parent: &Path) -> io::Result<Dir> {
        match root.open_dir(parent) {
            Ok(directory) => return Ok(directory),
            Err(error) if error.kind() == io::ErrorKind::NotFound => {}
            Err(error) => return Err(error),
        }
        let mut directory = root.try_clone()?;
        for component in parent.components() {
            let Component::Normal(name) = component else {
                continue;
            };
            let next = match directory.open_dir(name) {
                Ok(next) => next,
                Err(error) if error.kind() == io::ErrorKind::NotFound => {
                    match create_directory(&directory, name) {
                        Ok(()) => sync_directory(&directory)?,
                        Err(error) if error.kind() == io::ErrorKind::AlreadyExists => {}
                        Err(error) => return Err(error),
                    }
                    directory.open_dir(name)?
                }
                Err(error) => return Err(error),
            };
            directory = next;
        }
        Ok(directory)
    }
}

#[async_trait]
impl StagedDestination for LocalStagedDestination {
    fn supports_hash_checkpoint(&self) -> bool {
        true
    }

    async fn persist_hash_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<(), StorageRoleFailure> {
        hash_checkpoint::persist(self, stage).await
    }

    async fn release_hash_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<(), StorageRoleFailure> {
        hash_checkpoint::release(self, stage).await
    }

    fn supports_direct(&self) -> bool {
        cfg!(unix)
    }

    async fn prepare_direct(
        &self,
        request: PrepareRequest,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        self.open_direct(request, cancel).await
    }
    fn copied_metadata_target(&self) -> Option<crate::storage::CopiedMetadataTarget> {
        #[cfg(unix)]
        {
            Some(crate::storage::CopiedMetadataTarget {
                timestamps: crate::storage::CopiedTimestampTarget::Stored(
                    crate::model::TimePrecision::Nanoseconds,
                ),
                ownership: crate::storage::CopiedOwnershipTarget::Numeric,
                acl: crate::storage::CopiedAclTarget::Encoding(crate::model::AclEncoding::Posix),
                xattrs: crate::storage::CopiedValueTarget::Supported,
                tags: crate::storage::CopiedValueTarget::Unsupported,
            })
        }
        #[cfg(windows)]
        {
            Some(crate::storage::CopiedMetadataTarget {
                timestamps: crate::storage::CopiedTimestampTarget::Stored(
                    crate::model::TimePrecision::HundredNanoseconds,
                ),
                ownership: crate::storage::CopiedOwnershipTarget::Unsupported,
                acl: crate::storage::CopiedAclTarget::Encoding(
                    AclEncoding::WindowsSecurityDescriptor,
                ),
                xattrs: crate::storage::CopiedValueTarget::Unsupported,
                tags: crate::storage::CopiedValueTarget::Unsupported,
            })
        }
        #[cfg(not(any(unix, windows)))]
        {
            None
        }
    }

    #[cfg(unix)]
    fn may_set_owner(&self, uid: u32, gid: u32) -> bool {
        self.owner_privilege.permits(uid, gid)
    }

    fn automatic_checkpoint_interval_bytes(&self) -> Option<u64> {
        #[cfg(any(test, feature = "test-support"))]
        if self.write_probe.automatic_interval.load(Ordering::Relaxed) != 0 {
            return Some(self.write_probe.automatic_interval.load(Ordering::Relaxed));
        }
        Some(crate::storage::backends::DEFAULT_CHECKPOINT_INTERVAL_BYTES)
    }

    async fn write_single(
        &self,
        stage: &PreparedStage,
        data: Bytes,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        if data.len() > self.write_chunk_bytes
            || stage.recovery_enabled()
            || stage.checkpoint_enabled()
        {
            return self
                .write(
                    stage,
                    Box::pin(futures::stream::once(async move { Ok(data) })),
                )
                .await;
        }
        let file = self
            .open_stage_file_for(stage, Operation::Write, false)
            .await?;
        let fresh = Self::take_fresh_write(stage);
        let probe = Arc::clone(&self.write_probe);
        let durable = stage.durable_publication();
        let direct = stage.direct();
        let written = tokio::task::spawn_blocking(move || {
            if direct {
                file.set_len(0)?;
            }
            let written = Self::write_piece(&file, &probe, 0, &data)?;
            if !fresh {
                file.set_len(written)?;
            }
            if durable {
                #[cfg(any(test, feature = "test-support"))]
                probe.final_data_sync_calls.fetch_add(1, Ordering::SeqCst);
                file.sync_data()?;
            }
            Ok::<_, io::Error>(written)
        })
        .await
        .map_err(|_| {
            failure(
                stage.final_destination().path(),
                Operation::Write,
                FailureClass::Internal,
            )
        })?
        .map_err(|error| io_failure(stage.final_destination().path(), Operation::Write, &error))?;
        Ok(WriteEvidence {
            persisted_bytes: written,
        })
    }

    async fn prepare_at_destination(
        &self,
        request: DestinationPrepareRequest,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        at_destination::prepare(self, request).await
    }

    fn supports_positioned_write(&self) -> bool {
        true
    }

    async fn write_positioned(
        &self,
        stage: &PreparedStage,
        input: crate::storage::PositionedByteStream,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        positioned::write(self, stage, input).await
    }

    async fn write(
        &self,
        stage: &PreparedStage,
        mut input: ByteStream,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        let file = self
            .open_stage_file_for(stage, Operation::Write, false)
            .await?;
        let fresh = Self::take_fresh_write(stage);
        if stage.direct() {
            let target = Arc::clone(&file);
            tokio::task::spawn_blocking(move || target.set_len(0))
                .await
                .map_err(|_| {
                    failure(
                        stage.final_destination().path(),
                        Operation::Write,
                        FailureClass::Internal,
                    )
                })?
                .map_err(|e| io_failure(stage.final_destination().path(), Operation::Write, &e))?;
        }
        let mut writes = JoinSet::new();
        let (issued, mut persisted, mut first_failure, checkpoint_failed) = self
            .consume_input(stage, &mut input, &file, &mut writes)
            .await;
        Self::drain_writes(
            &mut writes,
            stage.final_destination().path(),
            &mut persisted,
            &mut first_failure,
        )
        .await;
        if let Some(error) = first_failure {
            if checkpoint_failed {
                return Err(error);
            }
            if persisted == issued {
                Self::sync_written_file(
                    Arc::clone(&file),
                    issued,
                    stage.final_destination().path(),
                    !stage.checkpoint_enabled(),
                    stage.durable_publication(),
                )
                .await?;
                if stage.durable_publication() {
                    hash_checkpoint::barrier(stage, persisted).await?;
                }
                if stage.recovery_enabled() {
                    self.persist_checkpoint(stage, persisted).await?;
                }
            }
            return Err(error);
        }
        if persisted != issued {
            return Err(failure(
                stage.final_destination().path(),
                Operation::Write,
                FailureClass::Corruption,
            ));
        }
        if stage.durable_publication() || !fresh {
            #[cfg(any(test, feature = "test-support"))]
            if stage.durable_publication() {
                self.write_probe
                    .final_data_sync_calls
                    .fetch_add(1, Ordering::SeqCst);
            }
            Self::sync_written_file(
                file,
                issued,
                stage.final_destination().path(),
                !fresh,
                stage.durable_publication(),
            )
            .await?;
        }
        if stage.durable_publication() {
            hash_checkpoint::barrier(stage, persisted).await?;
        }
        if stage.recovery_enabled() {
            self.persist_checkpoint(stage, persisted).await?;
        }
        Ok(WriteEvidence {
            persisted_bytes: persisted,
        })
    }

    async fn observe_checkpoint(
        &self,
        stage: &PreparedStage,
    ) -> Result<CheckpointObservation, StorageRoleFailure> {
        if stage.recovered_publication().is_some() {
            published_recovery::validate(self, stage).await?;
            return Ok(CheckpointObservation {
                durable_prefix: stage.checkpoint_prefix(),
            });
        }
        if !stage.recovery_enabled() {
            return Err(failure(
                stage.final_destination().path(),
                Operation::Observe,
                FailureClass::Unsupported,
            ));
        }
        let durable_prefix = self.reobserve_checkpoint(stage).await?;
        Ok(CheckpointObservation { durable_prefix })
    }

    async fn verify(
        &self,
        stage: &PreparedStage,
        request: VerifyRequest,
    ) -> Result<VerificationEvidence, StorageRoleFailure> {
        if stage.recovered_publication().is_some() {
            published_recovery::validate(self, stage).await?;
        }
        let name = self.stage_name(stage, Operation::Verify)?;
        let staging = self.stage_directory(stage, Operation::Verify).await?;
        let path = stage.final_destination().path().clone();
        let direct_file = if stage.recovered_publication().is_some() {
            Some(published_recovery::file(stage)?)
        } else if stage.direct() {
            Some(
                self.open_stage_file_for(stage, Operation::Verify, false)
                    .await?,
            )
        } else {
            None
        };
        let probe = Arc::clone(&self.write_probe);
        let verified = tokio::task::spawn_blocking(move || {
            if let Some(file) = direct_file {
                use std::io::Seek as _;
                let mut file = file.try_clone()?;
                file.rewind()?;
                return verification::verify_file(file, &request, &probe);
            }
            verification::verify_local(&staging, &name, &request, &probe)
        })
        .await
        .map_err(|_| failure(&path, Operation::Verify, FailureClass::Internal))?
        .map_err(|error| {
            let class = if error.kind() == io::ErrorKind::Interrupted {
                FailureClass::Cancelled
            } else if error.kind() == io::ErrorKind::InvalidData {
                FailureClass::Corruption
            } else {
                return io_failure(&path, Operation::Verify, &error);
            };
            failure(&path, Operation::Verify, class)
        })?;
        if stage.recovered_publication().is_some() {
            published_recovery::validate(self, stage).await?;
        }
        Ok(verified)
    }

    async fn apply_metadata(
        &self,
        stage: &PreparedStage,
        mutation: MetadataMutation,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        if cancel.is_cancelled() {
            return Err(failure(
                stage.final_destination().path(),
                Operation::Metadata,
                FailureClass::Cancelled,
            ));
        }
        if !local_metadata_supported(&mutation) {
            return Err(failure(
                stage.final_destination().path(),
                Operation::Metadata,
                FailureClass::Unsupported,
            ));
        }
        // ReadyToPublish was recorded after metadata application; a recovered final is immutable.
        if stage.recovered_publication().is_some() {
            return published_recovery::validate(self, stage).await;
        }
        let file = self
            .open_stage_file_for(
                stage,
                Operation::Metadata,
                matches!(&mutation, MetadataMutation::Acl(_)),
            )
            .await?;
        let path = stage.final_destination().path().clone();
        let durable = stage.durable_publication();
        tokio::task::spawn_blocking(move || {
            apply_local_metadata(&file, mutation)?;
            if durable {
                file.sync_all()?;
            }
            Ok(())
        })
        .await
        .map_err(|_| failure(&path, Operation::Metadata, FailureClass::Internal))?
        .map_err(|error| io_failure(&path, Operation::Metadata, &error))
    }

    async fn apply_metadata_batch(
        &self,
        stage: &PreparedStage,
        mutations: Vec<MetadataMutation>,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StagedMetadataApplicationFailure> {
        if mutations.is_empty() {
            return Ok(());
        }
        refuse_before_applying(stage, &mutations, &cancel)?;
        if stage.recovered_publication().is_some() {
            return published_recovery::validate(self, stage)
                .await
                .map_err(|error| {
                    StagedMetadataApplicationFailure::whole_batch(mutations.len(), 0, Some(error))
                });
        }
        let file = self
            .open_stage_file_for(
                stage,
                Operation::Metadata,
                mutations
                    .iter()
                    .any(|mutation| matches!(mutation, MetadataMutation::Acl(_))),
            )
            .await
            .map_err(|error| {
                StagedMetadataApplicationFailure::whole_batch(mutations.len(), 0, Some(error))
            })?;
        let path = stage.final_destination().path().clone();
        let durable = stage.durable_publication();
        let count = mutations.len();
        #[cfg(any(test, feature = "test-support"))]
        let fail_sync = self.write_probe.fail_metadata_sync.load(Ordering::SeqCst);
        #[cfg(not(any(test, feature = "test-support")))]
        let fail_sync = false;
        self.write_probe.record_metadata_batch(durable);
        tokio::task::spawn_blocking(move || {
            apply_local_batch(&file, mutations, &cancel, durable, fail_sync)
        })
        .await
        .map_err(|_| {
            // Nothing says how far the lost task got, so nothing is claimed applied.
            StagedMetadataApplicationFailure::whole_batch(
                count,
                0,
                Some(failure(&path, Operation::Metadata, FailureClass::Internal)),
            )
        })?
        .map_err(
            |(failed_index, completed, error)| StagedMetadataApplicationFailure {
                failed_index,
                completed,
                error: error.map(|error| io_failure(&path, Operation::Metadata, &error)),
            },
        )
    }

    async fn publish(
        &self,
        stage: &PreparedStage,
        request: PublishRequest,
    ) -> Result<PublicationEvidence, PublicationFailure> {
        if let Some(evidence) = &stage.recovered_publication() {
            let changed = |error| PublicationFailure {
                error,
                final_destination_changed: true,
            };
            if request.cancel.is_cancelled() {
                return Err(changed(failure(
                    stage.final_destination().path(),
                    Operation::Publish,
                    FailureClass::Cancelled,
                )));
            }
            published_recovery::validate(self, stage)
                .await
                .map_err(changed)?;
            hash_checkpoint::published(self, stage)
                .await
                .map_err(changed)?;
            return Ok(evidence.clone());
        }
        if stage.direct() {
            return self.finish_direct(stage, request).await;
        }
        let precommit = |error| PublicationFailure {
            error,
            final_destination_changed: false,
        };
        let stage_name = self
            .stage_name(stage, Operation::Publish)
            .map_err(precommit)?;
        // Armed stages retain their pointer through verification and release.
        let checkpoint_name = self
            .checkpoint_name(stage, Operation::Publish)
            .map_err(precommit)?;
        let final_relative =
            Self::checked_relative(stage.final_destination().path(), Operation::Publish)
                .map_err(precommit)?;
        let final_destination = stage.final_destination().path().clone();
        let staging = self
            .stage_directory(stage, Operation::Publish)
            .await
            .map_err(precommit)?;
        let root = Arc::clone(&self.root_dir);
        let probe = Arc::clone(&self.write_probe);
        let colocated = Self::stage_relative(stage, Operation::Publish)
            .map_err(precommit)?
            .parent()
            == final_relative.parent();
        let directory_sync = Arc::clone(&self.directory_sync);
        let durable = stage.durable_publication();
        let retain_checkpoint = stage.checkpoint_enabled();
        let result = tokio::task::spawn_blocking(move || {
            publication::publish_local(
                publication::Directories {
                    root: &root,
                    staging: &staging,
                    sync: &directory_sync,
                    colocated,
                    durable,
                },
                &stage_name,
                (!retain_checkpoint).then_some(checkpoint_name.as_os_str()),
                &final_relative,
                &request,
                &probe,
            )
        })
        .await
        .map_err(|_| PublicationFailure {
            error: failure(
                &final_destination,
                Operation::Publish,
                FailureClass::Internal,
            ),
            final_destination_changed: false,
        })?;
        match result {
            Ok(disposition) => {
                if stage.checkpoint_enabled() {
                    hash_checkpoint::published(self, stage)
                        .await
                        .map_err(|error| PublicationFailure {
                            error,
                            final_destination_changed: true,
                        })?;
                }
                at_destination::finish_publication(self, stage, final_destination, disposition)
                    .await
            }
            Err(error) => Err(PublicationFailure {
                error: io_failure(&final_destination, Operation::Publish, &error.error),
                final_destination_changed: error.committed,
            }),
        }
    }

    async fn discard(&self, stage: PreparedStage) -> Result<(), StorageRoleFailure> {
        if stage.direct() {
            return Ok(());
        }
        self.cleanup_stage_artifacts(&stage, Operation::Namespace)
            .await
    }
}

/// Refuses a batch before any of it is applied: cancelled, or holding a mutation Local cannot
/// apply at all. The unsupported one is reported at its index with nothing completed, so the
/// caller resends the ones ahead of it.
fn refuse_before_applying(
    stage: &PreparedStage,
    mutations: &[MetadataMutation],
    cancel: &tokio_util::sync::CancellationToken,
) -> Result<(), StagedMetadataApplicationFailure> {
    if cancel.is_cancelled() {
        return Err(StagedMetadataApplicationFailure {
            failed_index: 0,
            completed: 0,
            error: None,
        });
    }
    match mutations
        .iter()
        .position(|mutation| !local_metadata_supported(mutation))
    {
        Some(index) => Err(StagedMetadataApplicationFailure {
            failed_index: index,
            completed: 0,
            error: Some(failure(
                stage.final_destination().path(),
                Operation::Metadata,
                FailureClass::Unsupported,
            )),
        }),
        None => Ok(()),
    }
}

/// Where a blocking Local metadata batch stopped, as `(failed_index, completed, error)`: the
/// fields of `StagedMetadataApplicationFailure` before the error is mapped.
type LocalBatchStop = (usize, usize, Option<io::Error>);

/// Applies a staged metadata batch in order and makes it durable.
///
/// A refused mutation ends the batch without the barrier: any refusal fails the item, so what the
/// batch applied is not published through a stage (a direct target never had a metadata barrier),
/// and a non-empty resent remainder ends in a barrier that covers the whole file; when none runs
/// the item fails anyway. Running it here could only replace the refusal — the reason a caller
/// acts on — with a barrier failure. A failed barrier belongs to no one mutation and is reported against the
/// batch (`failed_index == count`).
fn apply_local_batch(
    file: &std::fs::File,
    mutations: Vec<MetadataMutation>,
    cancel: &tokio_util::sync::CancellationToken,
    durable: bool,
    fail_sync: bool,
) -> Result<(), LocalBatchStop> {
    let count = mutations.len();
    for (index, mutation) in mutations.into_iter().enumerate() {
        if cancel.is_cancelled() {
            // Cancelled work is never published, so what it applied need not be durable.
            return Err((index, index, None));
        }
        if let Err(error) = apply_local_metadata(file, mutation) {
            return Err((index, index, Some(error)));
        }
    }
    let synced = match (durable, fail_sync) {
        (false, _) => Ok(()),
        (true, true) => Err(io::Error::other("injected metadata sync failure")),
        (true, false) => file.sync_all(),
    };
    synced.map_err(|error| (count, count, Some(error)))
}

#[cfg(unix)]
pub(super) fn local_metadata_supported(mutation: &MetadataMutation) -> bool {
    match mutation {
        MetadataMutation::Acl(acl) => acl.encoding() == AclEncoding::Posix,
        MetadataMutation::Xattrs(_)
        | MetadataMutation::NumericOwnership(_)
        | MetadataMutation::Mode(_) => true,
        MetadataMutation::Timestamps(value) => value.created.is_none(),
        MetadataMutation::Tags(_) | MetadataMutation::MappedOwnership(_) => false,
    }
}

#[cfg(windows)]
pub(super) fn local_metadata_supported(mutation: &MetadataMutation) -> bool {
    match mutation {
        MetadataMutation::Acl(acl) => {
            acl.encoding() == AclEncoding::WindowsSecurityDescriptor && acl.access().is_some()
        }
        MetadataMutation::Timestamps(value) => value.created.is_none(),
        _ => false,
    }
}

#[cfg(not(any(unix, windows)))]
pub(super) fn local_metadata_supported(_mutation: &MetadataMutation) -> bool {
    false
}

#[cfg(unix)]
pub(super) fn apply_local_metadata(
    file: &std::fs::File,
    mutation: MetadataMutation,
) -> io::Result<()> {
    use std::os::unix::ffi::OsStrExt as _;
    use std::os::unix::fs::{PermissionsExt as _, fchown};
    use xattr::FileExt as _;

    match mutation {
        MetadataMutation::Acl(acl) => {
            set_optional_xattr(file, "system.posix_acl_access", acl.access())?;
            set_optional_xattr(file, "system.posix_acl_default", acl.default_acl())
        }
        MetadataMutation::Xattrs(values) => {
            for value in values {
                let name = std::ffi::OsStr::from_bytes(value.name());
                file.set_xattr(name, value.value())?;
            }
            Ok(())
        }
        MetadataMutation::Mode(mode) => {
            file.set_permissions(std::fs::Permissions::from_mode(mode & 0o7777))
        }
        MetadataMutation::NumericOwnership(value) => {
            fchown(file, Some(value.uid), Some(value.gid))?;
            file.set_permissions(std::fs::Permissions::from_mode(value.mode))
        }
        MetadataMutation::Timestamps(value) => {
            let atime = value.accessed.map(local_file_time).transpose()?;
            let mtime = value.modified.map(local_file_time).transpose()?;
            filetime::set_file_handle_times(file, atime, mtime)
        }
        MetadataMutation::Tags(_) | MetadataMutation::MappedOwnership(_) => {
            Err(io::Error::from(io::ErrorKind::Unsupported))
        }
    }
}

#[cfg(unix)]
fn set_optional_xattr(file: &std::fs::File, name: &str, value: Option<&[u8]>) -> io::Result<()> {
    use xattr::FileExt as _;

    match value {
        Some(value) => file.set_xattr(name, value),
        None => match file.remove_xattr(name) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error),
        },
    }
}

#[cfg(any(unix, windows))]
fn local_file_time(value: crate::model::StorageTimestamp) -> io::Result<filetime::FileTime> {
    const NANOS_PER_SECOND: i64 = 1_000_000_000;
    let nanos = i64::try_from(value.unix_nanos())
        .map_err(|_| io::Error::from(io::ErrorKind::InvalidInput))?;
    Ok(filetime::FileTime::from_unix_time(
        nanos.div_euclid(NANOS_PER_SECOND),
        u32::try_from(nanos.rem_euclid(NANOS_PER_SECOND))
            .map_err(|_| io::Error::from(io::ErrorKind::InvalidInput))?,
    ))
}

#[cfg(windows)]
pub(super) fn apply_local_metadata(
    file: &std::fs::File,
    mutation: MetadataMutation,
) -> io::Result<()> {
    match mutation {
        MetadataMutation::Acl(acl) if acl.encoding() == AclEncoding::WindowsSecurityDescriptor => {
            super::windows_acl::apply_handle(
                file,
                acl.access()
                    .ok_or_else(|| io::Error::from(io::ErrorKind::InvalidInput))?,
            )
        }
        MetadataMutation::Timestamps(value) if value.created.is_none() => {
            filetime::set_file_handle_times(
                file,
                value.accessed.map(local_file_time).transpose()?,
                value.modified.map(local_file_time).transpose()?,
            )
        }
        _ => Err(io::Error::from(io::ErrorKind::Unsupported)),
    }
}

#[cfg(not(any(unix, windows)))]
pub(super) fn apply_local_metadata(
    _file: &std::fs::File,
    _mutation: MetadataMutation,
) -> io::Result<()> {
    Err(io::Error::from(io::ErrorKind::Unsupported))
}

fn failure(path: &StoragePath, operation: Operation, class: FailureClass) -> StorageRoleFailure {
    failure_with_transience(path, operation, class, Transience::Permanent)
}

fn failure_with_transience(
    path: &StoragePath,
    operation: Operation,
    class: FailureClass,
    transience: Transience,
) -> StorageRoleFailure {
    let failure = EntryOperationFailure::new(
        path.clone(),
        operation,
        class,
        transience,
        "local staged operation failed",
    )
    .unwrap_or_else(|_| unreachable!("the static diagnostic is valid"));
    StorageRoleFailure::Entry(failure)
}

fn io_failure(path: &StoragePath, operation: Operation, error: &io::Error) -> StorageRoleFailure {
    let class = match error.kind() {
        io::ErrorKind::NotFound => FailureClass::NotFound,
        io::ErrorKind::PermissionDenied => FailureClass::PermissionDenied,
        io::ErrorKind::AlreadyExists | io::ErrorKind::WouldBlock => FailureClass::Conflict,
        io::ErrorKind::Interrupted => FailureClass::Cancelled,
        io::ErrorKind::InvalidInput => FailureClass::InvalidInput,
        _ => FailureClass::Protocol,
    };
    failure(path, operation, class)
}

#[cfg(test)]
mod tests;
