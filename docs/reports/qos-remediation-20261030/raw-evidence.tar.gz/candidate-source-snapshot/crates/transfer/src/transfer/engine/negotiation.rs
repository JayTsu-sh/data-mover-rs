//! Which metadata a copy carries: the baseline every copy takes, caller-selected ACL/xattrs,
//! automatic S3-to-S3 tags, and what the two ends can do. See
//! `.claude/docs/metadata-negotiation.md`.

use std::fmt;
use std::sync::Arc;

use super::{TransferFailure, TransferPhase, TransferSide, Transferred};
use crate::metadata::{
    AclTarget, MetadataApplicationFailure, MetadataPlan, MetadataPlanError, MetadataPlanRequest,
    MetadataPolicies, MetadataPolicy, MetadataTarget, OwnershipTarget, RefusalCause, RefusalSide,
    TimestampTarget, TimestampTargetCapability, ValueTarget, compile_copied_metadata_plan,
    compile_nothing_stored_plan, compile_unavailable_plan, role_failure_text,
};
use crate::model::{
    EntryKind, MetadataObservation, MetadataObservations, ObservationMode, ObservationPlan,
};
use crate::storage::{
    CopiedAclTarget, CopiedMetadataTarget, CopiedOwnershipTarget, CopiedTimestampTarget,
    CopiedValueTarget, Metadata, SourceDescriptor, StagedDestination, StorageRoleFailure,
};
use crate::transfer::{CopiedMetadataRequest, TransferRequest};

pub(super) async fn apply_copied_metadata(
    transferred: &Transferred,
    copied: Option<&CopiedMetadataPlan>,
    cancel: tokio_util::sync::CancellationToken,
) -> Result<
    Option<crate::metadata::MetadataApplicationReport>,
    crate::metadata::MetadataApplicationFailure,
> {
    let Some(copied) = copied else {
        return Ok(None);
    };
    copied
        .plan
        .apply_to_stage(transferred.destination.as_ref(), &transferred.stage, cancel)
        .await
        .map(Some)
}

pub(super) struct CopiedMetadataPlan {
    plan: MetadataPlan,
}

impl CopiedMetadataPlan {
    pub(super) fn carries_mode(&self) -> bool {
        self.plan.carries_mode()
    }

    pub(super) async fn validate_recovered(
        &self,
        transferred: &Transferred,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        self.plan
            .validate_recovered_stage(transferred.destination.as_ref(), &transferred.stage, cancel)
            .await
    }

    pub(super) fn recovered_acl_report(
        &self,
    ) -> Option<crate::metadata::MetadataApplicationReport> {
        self.plan.recovered_acl_report()
    }

    pub(super) fn checkpoint_binding(&self) -> [u8; 32] {
        self.plan.checkpoint_binding()
    }
}

/// Bind selectors even when capabilities yielded no plan or no mutations. Domain/version also
/// pins the ordinary copy policy, not just the values it happened to produce this attempt.
/// ACL requests bind the automatic projection policy as v2. Requests without ACLs retain their
/// v1 binding, including the two reserved bytes formerly used by ACL strength selectors.
pub(super) fn checkpoint_metadata_binding(
    request: &TransferRequest,
    copied: Option<&CopiedMetadataPlan>,
) -> [u8; 32] {
    let mut hash = blake3::Hasher::new();
    hash.update(if request.copied_metadata.acl() {
        b"data-mover ordinary copied metadata policy v2\0"
    } else {
        b"data-mover ordinary copied metadata policy v1\0"
    });
    hash.update(&[
        u8::from(request.copied_metadata.acl()),
        u8::from(request.copied_metadata.xattrs()),
        0,
        0,
        u8::from(request.copies_tags()),
        u8::from(copied.is_some()),
    ]);
    if let Some(copied) = copied {
        hash.update(&copied.checkpoint_binding());
    }
    *hash.finalize().as_bytes()
}

pub(super) async fn copied_metadata_plan(
    request: &TransferRequest,
    descriptor: &SourceDescriptor,
) -> Result<Option<CopiedMetadataPlan>, TransferFailure> {
    let requested = request.copied_metadata;
    let copy_tags = request.copies_tags();
    let Some(MetadataRoles {
        source: metadata,
        baseline,
        destination,
        target,
    }) = metadata_roles(request)
    else {
        if !requested.acl() {
            return Ok(None);
        }
        let source_missing = request
            .source
            .metadata()
            .ok()
            .is_none_or(|metadata| metadata.copied_metadata_observation_plan().is_none());
        let reason = if source_missing {
            RefusalCause::SourceCannotObserve
        } else {
            RefusalCause::DestinationCannotStore
        };
        let policies = MetadataPolicies::default()
            .with_acl(optional_policy(requested.acl()))
            .with_xattrs(optional_policy(requested.xattrs()))
            .with_tags(optional_policy(copy_tags));
        return Ok(Some(CopiedMetadataPlan {
            plan: compile_unavailable_plan(policies, reason),
        }));
    };
    // Unselected optional capabilities must not trigger source metadata I/O.
    let requested_target = CopiedMetadataTarget {
        acl: if requested.acl() {
            target.acl
        } else {
            CopiedAclTarget::Unsupported
        },
        xattrs: if requested.xattrs() {
            target.xattrs
        } else {
            CopiedValueTarget::Unsupported
        },
        tags: if copy_tags {
            target.tags
        } else {
            CopiedValueTarget::Unsupported
        },
        ..target
    };
    if requested_target.stores_nothing() {
        return Ok(Some(nothing_stored(requested, copy_tags)));
    }
    let timestamps_stored = matches!(target.timestamps, CopiedTimestampTarget::Stored(_));
    let observation_plan = baseline
        .with_acl(observation_mode(requested.acl()))
        .with_xattrs(observation_mode(requested.xattrs()))
        .with_tags(observation_mode(
            copy_tags && target.tags == CopiedValueTarget::Supported,
        ));
    let observations = metadata
        .observe_copy_bound_version(
            request.source_path(),
            &descriptor.source_identity,
            &descriptor.version,
            observation_plan,
        )
        .await
        .map_err(|error| {
            let mut failure =
                TransferFailure::role(TransferPhase::Metadata, TransferSide::Source, error);
            failure.message = "observing source metadata failed";
            failure
        })?;
    let owner_permitted = owner_permitted(
        |uid, gid| destination.may_set_owner(uid, gid),
        &observations.observations,
    );
    let (target, ownership_policy) = metadata_target(target, owner_permitted);
    let policies = copied_policies(
        requested,
        copy_tags,
        ownership_policy,
        observations.mode_without_ownership.is_some(),
        timestamps_stored,
    );
    compile_copied_metadata_plan(
        &MetadataPlanRequest {
            observations: &observations.observations,
            target,
            policies,
            principal_mapper: None,
        },
        observations.mode_without_ownership,
        observations.owner_names_unmapped,
        requested.acl() && descriptor.kind == EntryKind::File,
    )
    .map(|plan| Some(CopiedMetadataPlan { plan }))
    .map_err(TransferFailure::refused_metadata)
}

/// A destination that keeps nothing a copy carries: nothing the source holds could change the
/// outcome, so the source is not read — no request per file just to report that the destination
/// keeps none of it. The baseline and whatever the caller asked for are each skipped with that
/// reason. The source identity is still enforced by every read of the data.
fn nothing_stored(requested: CopiedMetadataRequest, copy_tags: bool) -> CopiedMetadataPlan {
    let policies = MetadataPolicies::default()
        .with_ownership_mode(MetadataPolicy::AllowKnownLoss)
        .with_timestamps(MetadataPolicy::AllowKnownLoss)
        .with_acl(optional_policy(requested.acl()))
        .with_xattrs(optional_policy(requested.xattrs()))
        .with_tags(optional_policy(copy_tags));
    CopiedMetadataPlan {
        plan: compile_nothing_stored_plan(policies),
    }
}

/// The source's metadata role with the baseline it observes for a copy, and what the destination
/// accepts.
struct MetadataRoles {
    source: Arc<dyn Metadata>,
    baseline: ObservationPlan,
    destination: Arc<dyn StagedDestination>,
    target: CopiedMetadataTarget,
}

/// Both ends' metadata roles, or `None` when an end has none. An ACL request then receives
/// an unavailable-family report; a copy without ACL continues without a metadata plan.
fn metadata_roles(request: &TransferRequest) -> Option<MetadataRoles> {
    let source = request.source.metadata().ok()?;
    let baseline = source.copied_metadata_observation_plan()?;
    let destination = request.destination.staged_destination().ok()?;
    let target = destination.copied_metadata_target()?;
    Some(MetadataRoles {
        source,
        baseline,
        destination,
        target,
    })
}

/// Whether the destination may give this file the source's owner and group — asked per file,
/// because an unprivileged writer may keep its own files' owners but not give files away.
fn owner_permitted(
    may_set_owner: impl Fn(u32, u32) -> bool,
    observations: &MetadataObservations,
) -> bool {
    match observations.ownership_mode() {
        MetadataObservation::Value { value, .. } => may_set_owner(value.uid, value.gid),
        _ => true,
    }
}

/// Translates what the destination accepts across the layer boundary — `storage` cannot name
/// `metadata`'s vocabulary, and this is the layer that sees both — together with the ownership
/// policy that target implies. Whether a family is carried at all is the caller's request, which
/// reaches the compiler as a policy.
fn metadata_target(
    target: CopiedMetadataTarget,
    owner_permitted: bool,
) -> (MetadataTarget, MetadataPolicy) {
    let (ownership_mode, ownership_policy) = match target.ownership {
        CopiedOwnershipTarget::Numeric if owner_permitted => {
            (OwnershipTarget::Numeric, MetadataPolicy::RequireExact)
        }
        CopiedOwnershipTarget::Numeric => (
            OwnershipTarget::NotPermitted,
            MetadataPolicy::AllowKnownLoss,
        ),
        CopiedOwnershipTarget::Unsupported => (
            OwnershipTarget::NotApplicable,
            MetadataPolicy::AllowKnownLoss,
        ),
        CopiedOwnershipTarget::ModeOnly => {
            (OwnershipTarget::ModeOnly, MetadataPolicy::AllowKnownLoss)
        }
    };
    let target = MetadataTarget {
        acl: match target.acl {
            CopiedAclTarget::Encoding(encoding) => AclTarget::Encoding(encoding),
            CopiedAclTarget::Unsupported => AclTarget::Unsupported,
        },
        xattrs: match target.xattrs {
            CopiedValueTarget::Supported => ValueTarget::Supported,
            CopiedValueTarget::Unsupported => ValueTarget::Unsupported,
        },
        tags: match target.tags {
            CopiedValueTarget::Supported => ValueTarget::Supported,
            CopiedValueTarget::Unsupported => ValueTarget::Unsupported,
        },
        ownership_mode,
        timestamps: match target.timestamps {
            CopiedTimestampTarget::Stored(precision) => {
                TimestampTargetCapability::Supported(TimestampTarget {
                    precision,
                    accessed: false,
                    modified: true,
                    created: false,
                })
            }
            CopiedTimestampTarget::NotStored => TimestampTargetCapability::Unsupported,
        },
    };
    (target, ownership_policy)
}

/// The baseline every copy carries — ownership/mode as the target allows, mtime — plus the
/// selected ACL/xattrs and automatic S3-to-S3 tags. A destination that does not store the
/// modification time has it skipped with that reason; it is not the copy's to refuse.
fn copied_policies(
    requested: CopiedMetadataRequest,
    copy_tags: bool,
    ownership_policy: MetadataPolicy,
    mode_without_ownership: bool,
    timestamps_stored: bool,
) -> MetadataPolicies {
    let ownership_policy = if mode_without_ownership {
        MetadataPolicy::AllowKnownLoss
    } else {
        ownership_policy
    };
    MetadataPolicies::default()
        .with_ownership_mode(ownership_policy)
        .with_timestamps(if timestamps_stored {
            MetadataPolicy::AllowKnownLoss
        } else {
            MetadataPolicy::BestEffort
        })
        .with_acl(optional_policy(requested.acl()))
        .with_xattrs(optional_policy(requested.xattrs()))
        .with_tags(optional_policy(copy_tags))
}

/// How an optional feature is planned: not asked for, it is not even read; asked for, it is
/// carried exactly or with a named loss when both ends can, and skipped with the reason when
/// either cannot — never refused, because what a user asks the storage cannot do is the caller's
/// to judge. A read that fails is still a failure (`BestEffort` no longer skips those).
const fn optional_policy(asked: bool) -> MetadataPolicy {
    if asked {
        MetadataPolicy::BestEffort
    } else {
        MetadataPolicy::Omit
    }
}

impl TransferFailure {
    /// Copied metadata refused while planning: the headline names the end the cause is about.
    pub(super) fn refused_metadata(error: MetadataPlanError) -> Self {
        let side = match error.cause().side() {
            RefusalSide::Source => TransferSide::Source,
            RefusalSide::Destination => TransferSide::Destination,
            _ => TransferSide::Orchestration,
        };
        let mut failure = Self::orchestration(
            TransferPhase::Metadata,
            "copied metadata was refused while planning",
        );
        failure.side = side;
        failure.refusal = Some(Box::new(error));
        failure
    }
}

/// The part of a metadata-phase failure a caller acts on: which family was refused while
/// planning and why, or which write failed and how, or what reading the source reported — each
/// with the adapter's (already redacted) diagnostic.
pub(super) fn write_metadata_detail(
    formatter: &mut fmt::Formatter<'_>,
    refusal: Option<MetadataPlanError>,
    application: Option<&MetadataApplicationFailure>,
    role: Option<&StorageRoleFailure>,
) -> fmt::Result {
    if let Some(refusal) = refusal {
        write!(formatter, ": {refusal}")?;
    }
    if let Some(application) = application {
        write!(formatter, ": {application}")?;
    } else if let Some(role) = role {
        write!(formatter, ": {}", role_failure_text(role))?;
    }
    Ok(())
}

/// How hard the source looks for an optional feature: not at all unless asked, and when asked,
/// as far as it can — a source that cannot read the feature says so rather than failing.
const fn observation_mode(asked: bool) -> ObservationMode {
    if asked {
        ObservationMode::BestEffort
    } else {
        ObservationMode::Omit
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::metadata::{MetadataFamily, RefusalCause};
    use crate::model::{AclEncoding, StoragePath};

    /// Not asked for, a feature is not even read; asked for, the source reads it as far as it can.
    #[test]
    fn asking_decides_whether_the_source_looks() {
        assert_eq!(observation_mode(false), ObservationMode::Omit);
        assert_eq!(observation_mode(true), ObservationMode::BestEffort);
        assert_eq!(optional_policy(false), MetadataPolicy::Omit);
        assert_eq!(optional_policy(true), MetadataPolicy::BestEffort);
    }

    fn selector_request() -> Result<TransferRequest, Box<dyn std::error::Error>> {
        let root = tempfile::tempdir()?;
        let source = crate::storage::backends::local::test_source_storage(
            root.path(),
            "acl-selector-source",
        )?
        .0;
        let destination = crate::storage::backends::local::test_destination_storage(
            root.path(),
            "acl-selector-target",
        )?;
        Ok(TransferRequest::new(
            source,
            StoragePath::new("file")?,
            destination,
            tokio_util::sync::CancellationToken::new(),
        ))
    }

    fn legacy_binding(request: &TransferRequest) -> [u8; 32] {
        let mut hash = blake3::Hasher::new();
        hash.update(b"data-mover ordinary copied metadata policy v1\0");
        hash.update(&[
            u8::from(request.copied_metadata.acl()),
            u8::from(request.copied_metadata.xattrs()),
            0,
            0,
            u8::from(request.copies_tags()),
            0,
        ]);
        *hash.finalize().as_bytes()
    }

    #[test]
    fn automatic_acl_selection_is_distinct_and_invalidates_old_acl_checkpoints()
    -> Result<(), Box<dyn std::error::Error>> {
        let request = selector_request()?;
        let mut bindings = std::collections::HashSet::new();
        for selectors in [
            CopiedMetadataRequest::default(),
            CopiedMetadataRequest::default().with_acl(),
            CopiedMetadataRequest::default().with_xattrs(),
            CopiedMetadataRequest::default().with_acl().with_xattrs(),
        ] {
            let request = request.clone().with_copied_metadata(selectors);
            let binding = checkpoint_metadata_binding(&request, None);
            assert_eq!(binding == legacy_binding(&request), !selectors.acl());
            bindings.insert(binding);
        }
        assert_eq!(bindings.len(), 4);
        Ok(())
    }

    #[test]
    fn acl_selection_keeps_the_existing_ownership_policy() {
        let expected = MetadataPolicies::default()
            .with_ownership_mode(MetadataPolicy::AllowKnownLoss)
            .with_timestamps(MetadataPolicy::AllowKnownLoss)
            .with_acl(MetadataPolicy::BestEffort);
        assert_eq!(
            copied_policies(
                CopiedMetadataRequest::default().with_acl(),
                false,
                MetadataPolicy::AllowKnownLoss,
                true,
                true
            ),
            expected,
        );
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn automatic_acl_projection_is_limited_to_regular_files()
    -> Result<(), Box<dyn std::error::Error>> {
        let root = tempfile::tempdir()?;
        std::fs::write(root.path().join("file"), b"ACL")?;
        std::fs::create_dir(root.path().join("directory"))?;
        let source =
            crate::storage::backends::local::test_source_storage(root.path(), "acl-kind-source")?.0;
        let destination = crate::storage::backends::local::test_destination_storage(
            root.path(),
            "acl-kind-target",
        )?;
        for name in ["file", "directory"] {
            let path = StoragePath::new(name)?;
            let descriptor = source.read_source()?.describe(&path).await?;
            let request = TransferRequest::new(
                source.clone(),
                path,
                destination.clone(),
                tokio_util::sync::CancellationToken::new(),
            )
            .with_copied_metadata(CopiedMetadataRequest::default().with_acl());
            let copied = copied_metadata_plan(&request, &descriptor)
                .await?
                .ok_or("metadata plan missing")?;
            assert_eq!(copied.plan.acl_copy_report().is_some(), name == "file");
        }
        Ok(())
    }

    fn numeric_destination() -> CopiedMetadataTarget {
        CopiedMetadataTarget {
            timestamps: CopiedTimestampTarget::Stored(crate::model::TimePrecision::Nanoseconds),
            ownership: CopiedOwnershipTarget::Numeric,
            acl: CopiedAclTarget::Unsupported,
            xattrs: CopiedValueTarget::Unsupported,
            tags: CopiedValueTarget::Unsupported,
        }
    }

    /// A numeric destination that may not give this file its source owner carries the mode alone,
    /// as a known loss — never a refusal that fails the file on the write.
    #[test]
    fn an_owner_the_writer_may_not_set_becomes_mode_only_with_a_named_loss() {
        let (target, policy) = metadata_target(numeric_destination(), true);
        assert_eq!(target.ownership_mode, OwnershipTarget::Numeric);
        assert_eq!(policy, MetadataPolicy::RequireExact);
        let (target, policy) = metadata_target(numeric_destination(), false);
        assert_eq!(target.ownership_mode, OwnershipTarget::NotPermitted);
        assert_eq!(policy, MetadataPolicy::AllowKnownLoss);
    }

    /// The destination is asked about the owner the source actually has; with no owner observed
    /// there is nothing to ask, and nothing to lose.
    #[test]
    fn the_destination_is_asked_about_this_files_owner() {
        let owned_by = |uid, gid| {
            crate::model::MetadataObservationParts {
                ownership_mode: MetadataObservation::Value {
                    value: crate::model::OwnershipMode {
                        uid,
                        gid,
                        mode: 0o100_644,
                    },
                    provenance: crate::model::MetadataProvenance::Inline,
                },
                ..crate::model::MetadataObservationParts::default()
            }
            .build()
            .unwrap_or_else(|error| panic!("{error}"))
        };
        let only_mine = |uid, gid| uid == 1000 && gid == 1000;
        assert!(owner_permitted(only_mine, &owned_by(1000, 1000)));
        assert!(!owner_permitted(only_mine, &owned_by(0, 0)));
        assert!(!owner_permitted(only_mine, &owned_by(1000, 0)));
        assert!(owner_permitted(
            |_, _| false,
            &MetadataObservations::default()
        ));
    }

    /// A destination that keeps owner and mode but not the modification time: mtime is skipped
    /// because of the destination, and the file is not failed for it.
    #[test]
    fn a_modification_time_the_destination_does_not_store_is_skipped_not_refused()
    -> Result<(), Box<dyn std::error::Error>> {
        let (target, ownership_policy) = metadata_target(
            CopiedMetadataTarget {
                timestamps: CopiedTimestampTarget::NotStored,
                ..numeric_destination()
            },
            true,
        );
        assert_eq!(target.timestamps, TimestampTargetCapability::Unsupported);
        let policies = copied_policies(
            CopiedMetadataRequest::default(),
            false,
            ownership_policy,
            false,
            false,
        );
        let observations = crate::model::MetadataObservationParts {
            timestamps: MetadataObservation::Value {
                value: crate::model::TimestampMetadata {
                    accessed: None,
                    modified: Some(crate::model::StorageTimestamp::new(
                        1_000_000_000,
                        crate::model::TimePrecision::Nanoseconds,
                    )?),
                    created: None,
                },
                provenance: crate::model::MetadataProvenance::Inline,
            },
            ownership_mode: MetadataObservation::Value {
                value: crate::model::OwnershipMode {
                    uid: 1000,
                    gid: 1000,
                    mode: 0o100_644,
                },
                provenance: crate::model::MetadataProvenance::Inline,
            },
            ..crate::model::MetadataObservationParts::default()
        }
        .build()
        .unwrap_or_else(|error| panic!("{error}"));
        let plan = compile_copied_metadata_plan(
            &MetadataPlanRequest {
                observations: &observations,
                target,
                policies,
                principal_mapper: None,
            },
            None,
            false,
            false,
        )?;
        assert!(matches!(plan.skipped(), [skipped]
            if skipped.family == MetadataFamily::Timestamps
                && skipped.reason == RefusalCause::DestinationCannotStore));
        Ok(())
    }

    fn refused(cause: RefusalCause) -> String {
        TransferFailure::refused_metadata(MetadataPlanError::new(
            MetadataFamily::Acl,
            MetadataPolicy::RequireExact,
            cause,
        ))
        .to_string()
    }

    /// A refusal names the family, the policy it was asked under, and which end lacks it — "the
    /// source cannot read it" and "the destination cannot store it" send a caller to different
    /// places, and so does "the encodings differ", which also names both.
    #[test]
    fn a_planning_refusal_says_what_which_end_and_why() {
        let source = refused(RefusalCause::SourceCannotObserve);
        let destination = refused(RefusalCause::DestinationCannotStore);
        assert!(source.contains("on Source"), "{source}");
        assert!(
            source.contains("ACL (RequireExact): the source cannot read it"),
            "{source}"
        );
        assert!(destination.contains("on Destination"), "{destination}");
        assert!(
            destination.contains("the destination cannot store it"),
            "{destination}"
        );
        let encodings = refused(RefusalCause::EncodingsDiffer {
            source: AclEncoding::NfsV4,
            destination: AclEncoding::WindowsSecurityDescriptor,
        });
        assert!(encodings.contains("NfsV4"), "{encodings}");
        assert!(
            encodings.contains("WindowsSecurityDescriptor"),
            "{encodings}"
        );
    }
}
