#![allow(clippy::wildcard_imports)] // Fake protocols share their parent adapter helpers.
use std::collections::HashMap;
use std::num::NonZeroUsize;
use std::sync::Arc;

use async_trait::async_trait;
use bytes::{Bytes, BytesMut};
use std::sync::atomic::{AtomicUsize, Ordering};
use tokio::sync::Mutex;

use super::protocol::{
    HdfsEntryFacts, HdfsListedChild, HdfsListing, HdfsProtocol, HdfsReadCursor, HdfsWriteSession,
    entry_failure,
};
use crate::model::{
    EntryKind, EntryOperationFailure, FailureClass, Operation, StoragePath, Transience,
};
use crate::storage::StorageRoleFailure;
use crate::storage::artifacts::{ArtifactKind, parse_artifact_name};

#[derive(Clone, Default)]
pub struct MemoryHdfs {
    state: Arc<MemoryHdfsState>,
    source_prefix: String,
}

impl std::ops::Deref for MemoryHdfs {
    type Target = MemoryHdfsState;

    fn deref(&self) -> &Self::Target {
        &self.state
    }
}

#[derive(Default)]
pub struct MemoryHdfsState {
    objects: Mutex<HashMap<String, Bytes>>,
    file_modes: Mutex<HashMap<String, u32>>,
    metadata_calls: Mutex<Vec<String>>,
    stat_calls: AtomicUsize,
    use_read_cursor: std::sync::atomic::AtomicBool,
    fail_cursor_reads: std::sync::atomic::AtomicBool,
    reader_opens: AtomicUsize,
    cursor_reads: AtomicUsize,
    read_active: AtomicUsize,
    read_peak: AtomicUsize,
    read_limit: AtomicUsize,
    write_limit: AtomicUsize,
    write_peak: AtomicUsize,
    append_calls: AtomicUsize,
    stabilize_calls: AtomicUsize,
    recovered_tail: Mutex<Option<Bytes>>,
    hsync_calls: AtomicUsize,
    pointer_writes: AtomicUsize,
    data_closes: AtomicUsize,
    fail_after_hsync: std::sync::atomic::AtomicBool,
    fail_pointer_write: std::sync::atomic::AtomicBool,
    hsync_completed: std::sync::atomic::AtomicBool,
    delayed_reads: std::sync::atomic::AtomicBool,
    fail_write: std::sync::atomic::AtomicBool,
    fail_rename_after_commit: std::sync::atomic::AtomicBool,
    undescribable: Mutex<Vec<String>>,
    /// Statuses every listing has handed out, as a name node would have returned them.
    listed_statuses: Arc<AtomicUsize>,
    /// A listing fails once it has handed out this many statuses.
    listing_fails_after: std::sync::Mutex<Option<usize>>,
    /// A listing stops answering once it has handed out this many statuses.
    listing_stalls_after: std::sync::Mutex<Option<usize>>,
    /// Listings dropped so far.
    listings_dropped: Arc<AtomicUsize>,
}

struct MemoryReadCursor {
    protocol: MemoryHdfs,
    path: StoragePath,
}

#[async_trait]
impl HdfsReadCursor for MemoryReadCursor {
    async fn read_range(&self, range: std::ops::Range<u64>) -> Result<Bytes, StorageRoleFailure> {
        self.protocol.cursor_reads.fetch_add(1, Ordering::SeqCst);
        if self.protocol.fail_cursor_reads.load(Ordering::SeqCst) {
            return Err(entry_failure(
                &self.path,
                Operation::Read,
                FailureClass::Connectivity,
                Transience::Transient,
            ));
        }
        self.protocol.read_range(&self.path, range).await
    }
}

/// One listing of a snapshot of a [`MemoryHdfs`] directory, in name order, page by page.
struct MemoryListing {
    directory: StoragePath,
    children: std::vec::IntoIter<HdfsListedChild>,
    served: usize,
    fail_after: Option<usize>,
    stall_after: Option<usize>,
    listed: Arc<AtomicUsize>,
    dropped: Arc<AtomicUsize>,
}

impl Drop for MemoryListing {
    fn drop(&mut self) {
        self.dropped.fetch_add(1, Ordering::SeqCst);
    }
}

#[async_trait]
impl HdfsListing for MemoryListing {
    async fn next_page(
        &mut self,
        max: NonZeroUsize,
    ) -> Result<Option<Vec<HdfsListedChild>>, StorageRoleFailure> {
        tokio::task::yield_now().await;
        if self.stall_after.is_some_and(|limit| self.served >= limit) {
            std::future::pending::<()>().await;
        }
        let room = match self.fail_after {
            Some(limit) if self.served >= limit => {
                self.fail_after = None;
                self.children = Vec::new().into_iter();
                return Err(StorageRoleFailure::Entry(listing_failure(
                    &self.directory,
                    FailureClass::Protocol,
                )));
            }
            Some(limit) => max.get().min(limit - self.served),
            None => max.get(),
        };
        let page: Vec<_> = self.children.by_ref().take(room).collect();
        if page.is_empty() {
            return Ok(None);
        }
        self.served += page.len();
        self.listed.fetch_add(page.len(), Ordering::SeqCst);
        Ok(Some(page))
    }
}

fn listing_failure(path: &StoragePath, class: FailureClass) -> EntryOperationFailure {
    match entry_failure(path, Operation::Traverse, class, Transience::Permanent) {
        StorageRoleFailure::Entry(failure) => failure,
        StorageRoleFailure::Session(_) => unreachable!("entry failure"),
    }
}

/// Whether `path` names a pointer artifact or its temporary, exactly (not a data file whose name
/// merely contains "pointer").
fn is_pointer(path: &StoragePath) -> bool {
    let name = path.as_str().rsplit('/').next().unwrap_or_default();
    parse_artifact_name(name).is_some_and(|parsed| parsed.kind == ArtifactKind::Pointer)
}

impl MemoryHdfs {
    pub fn enable_read_cursor(&self) {
        self.use_read_cursor.store(true, Ordering::SeqCst);
    }

    pub fn fail_cursor_reads(&self, fail: bool) {
        self.state.fail_cursor_reads.store(fail, Ordering::SeqCst);
    }

    #[must_use]
    pub fn reader_counts(&self) -> (usize, usize) {
        (
            self.reader_opens.load(Ordering::SeqCst),
            self.cursor_reads.load(Ordering::SeqCst),
        )
    }
    /// A read-only source root in the same test filesystem, retaining shared I/O counters.
    #[must_use]
    pub fn source_root(self: &Arc<Self>, prefix: &str) -> Arc<Self> {
        Arc::new(Self {
            state: self.state.clone(),
            source_prefix: format!("{}/", prefix.trim_end_matches('/')),
        })
    }

    /// Fails the first data write after an hsync: the pointer an at-destination checkpoint
    /// writes right after its hsync is not data and goes through.
    pub fn fail_once_after_hsync(&self) {
        self.fail_after_hsync.store(true, Ordering::SeqCst);
    }
    /// Fails the next write of a pointer (or its temporary).
    pub fn fail_once_on_pointer_write(&self) {
        self.fail_pointer_write.store(true, Ordering::SeqCst);
    }
    pub fn configure_io(&self, read: usize, write: usize) {
        self.read_limit.store(read, Ordering::SeqCst);
        self.write_limit.store(write, Ordering::SeqCst);
        self.delayed_reads.store(true, Ordering::SeqCst);
    }
    #[must_use]
    pub fn io_peaks(&self) -> (usize, usize, usize) {
        (
            self.read_peak.load(Ordering::SeqCst),
            self.write_peak.load(Ordering::SeqCst),
            self.append_calls.load(Ordering::SeqCst),
        )
    }
    #[must_use]
    pub fn hsync_calls(&self) -> usize {
        self.hsync_calls.load(Ordering::SeqCst)
    }
    #[must_use]
    pub fn checkpoint_io_counts(&self) -> (usize, usize, usize) {
        (
            self.pointer_writes.load(Ordering::SeqCst),
            self.hsync_calls.load(Ordering::SeqCst),
            self.data_closes.load(Ordering::SeqCst),
        )
    }
    pub async fn reveal_tail_during_lease_recovery(&self, tail: Bytes) {
        *self.recovered_tail.lock().await = Some(tail);
    }
    #[must_use]
    pub fn stabilize_calls(&self) -> usize {
        self.stabilize_calls.load(Ordering::SeqCst)
    }
    /// Lists `path` as a child the listing cannot describe (as a real listing does for a status
    /// whose time or size does not convert).
    pub async fn make_undescribable(&self, path: &str) {
        self.undescribable.lock().await.push(path.into());
    }

    /// Makes every later listing fail once it has handed out `statuses` statuses.
    pub fn fail_listings_after(&self, statuses: usize) {
        *self
            .listing_fails_after
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner) = Some(statuses);
    }

    /// Makes every later listing stop answering once it has handed out `statuses` statuses.
    pub fn stall_listings_after(&self, statuses: usize) {
        *self
            .listing_stalls_after
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner) = Some(statuses);
    }

    /// Listings dropped so far.
    #[must_use]
    pub fn listings_dropped(&self) -> usize {
        self.listings_dropped.load(Ordering::SeqCst)
    }

    /// Statuses every listing so far has handed out.
    #[must_use]
    pub fn listed_statuses(&self) -> usize {
        self.listed_statuses.load(Ordering::SeqCst)
    }

    pub async fn insert(&self, path: &str, value: Bytes) {
        self.objects.lock().await.insert(path.into(), value);
    }

    pub async fn get(&self, path: &str) -> Option<Bytes> {
        self.objects.lock().await.get(path).cloned()
    }

    pub async fn is_empty(&self) -> bool {
        self.len().await == 0
    }

    pub async fn len(&self) -> usize {
        self.objects.lock().await.len()
    }

    pub fn fail_writes(&self) {
        self.fail_write
            .store(true, std::sync::atomic::Ordering::SeqCst);
    }

    pub fn allow_writes(&self) {
        self.fail_write.store(false, Ordering::SeqCst);
    }

    pub fn fail_rename_after_commit(&self) {
        self.fail_rename_after_commit.store(true, Ordering::SeqCst);
    }

    pub async fn metadata_calls(&self) -> Vec<String> {
        self.metadata_calls.lock().await.clone()
    }

    pub async fn file_mode(&self, path: &str) -> Option<u32> {
        self.file_modes.lock().await.get(path).copied()
    }

    #[must_use]
    pub fn stat_calls(&self) -> usize {
        self.stat_calls.load(Ordering::SeqCst)
    }

    fn facts(path: &StoragePath, size: u64) -> HdfsEntryFacts {
        HdfsEntryFacts {
            path: path.clone(),
            kind: EntryKind::File,
            size: Some(size),
            atime: 0,
            mtime: 0,
            mode: 0o640,
            owner: "alice".into(),
            group: "users".into(),
            replication: Some(3),
            block_size: Some(128 * 1024 * 1024),
        }
    }

    fn missing(path: &StoragePath, operation: Operation) -> StorageRoleFailure {
        entry_failure(
            path,
            operation,
            FailureClass::NotFound,
            Transience::Permanent,
        )
    }
}

#[async_trait]
impl HdfsProtocol for MemoryHdfs {
    async fn open_reader(
        &self,
        path: &StoragePath,
    ) -> Result<Option<Arc<dyn HdfsReadCursor>>, StorageRoleFailure> {
        if !self.use_read_cursor.load(Ordering::SeqCst) {
            return Ok(None);
        }
        self.stat(path).await?;
        self.reader_opens.fetch_add(1, Ordering::SeqCst);
        Ok(Some(Arc::new(MemoryReadCursor {
            protocol: self.clone(),
            path: path.clone(),
        })))
    }
    fn maximum_read_chunk_bytes(&self) -> usize {
        match self.read_limit.load(Ordering::SeqCst) {
            0 => 2 * 1024 * 1024,
            value => value,
        }
    }
    fn maximum_write_chunk_bytes(&self) -> usize {
        match self.write_limit.load(Ordering::SeqCst) {
            0 => 2 * 1024 * 1024,
            value => value,
        }
    }
    async fn stat(&self, path: &StoragePath) -> Result<HdfsEntryFacts, StorageRoleFailure> {
        self.stat_calls.fetch_add(1, Ordering::SeqCst);
        let objects = self.objects.lock().await;
        let value = objects
            .get(&format!("{}{}", self.source_prefix, path.as_str()))
            .ok_or_else(|| Self::missing(path, Operation::Observe))?;
        Ok(Self::facts(path, value.len() as u64))
    }

    async fn open_listing(&self, path: &StoragePath) -> Box<dyn HdfsListing> {
        let prefix = if path.as_str().is_empty() {
            String::new()
        } else {
            format!("{}/", path.as_str())
        };
        let undescribable = self.undescribable.lock().await.clone();
        let objects = self.objects.lock().await;
        let mut names: Vec<(&String, &Bytes)> = objects
            .iter()
            .filter(|(name, _)| {
                name.strip_prefix(&prefix)
                    .is_some_and(|relative| !relative.contains('/'))
            })
            .collect();
        names.sort_unstable_by_key(|(name, _)| name.as_str());
        let children = names
            .into_iter()
            .map(|(name, value)| {
                let path = StoragePath::new(name).unwrap_or_else(|error| panic!("{error}"));
                if undescribable.contains(name) {
                    return Err(listing_failure(&path, FailureClass::InvalidInput));
                }
                Ok(Self::facts(&path, value.len() as u64))
            })
            .collect::<Vec<_>>();
        Box::new(MemoryListing {
            directory: path.clone(),
            children: children.into_iter(),
            served: 0,
            fail_after: *self
                .listing_fails_after
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner),
            stall_after: *self
                .listing_stalls_after
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner),
            listed: Arc::clone(&self.listed_statuses),
            dropped: Arc::clone(&self.listings_dropped),
        })
    }

    async fn read_range(
        &self,
        path: &StoragePath,
        range: std::ops::Range<u64>,
    ) -> Result<Bytes, StorageRoleFailure> {
        let _active = ActiveRead(self);
        let active = self.read_active.fetch_add(1, Ordering::SeqCst) + 1;
        self.read_peak.fetch_max(active, Ordering::SeqCst);
        if self.delayed_reads.load(Ordering::SeqCst) {
            tokio::time::sleep(std::time::Duration::from_millis(2)).await;
        }
        let objects = self.objects.lock().await;
        let value = objects
            .get(&format!("{}{}", self.source_prefix, path.as_str()))
            .ok_or_else(|| Self::missing(path, Operation::Read))?;
        let start = usize::try_from(range.start).map_err(|_| {
            entry_failure(
                path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            )
        })?;
        let end = usize::try_from(range.end).map_err(|_| {
            entry_failure(
                path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            )
        })?;
        Ok(value.slice(start..end))
    }

    async fn create_directory(&self, _path: &StoragePath) -> Result<(), StorageRoleFailure> {
        Ok(())
    }

    async fn delete(&self, path: &StoragePath, _kind: EntryKind) -> Result<(), StorageRoleFailure> {
        self.objects.lock().await.remove(path.as_str());
        self.file_modes.lock().await.remove(path.as_str());
        Ok(())
    }

    async fn rename(
        &self,
        from: &StoragePath,
        to: &StoragePath,
        overwrite: bool,
    ) -> Result<(), StorageRoleFailure> {
        let mut objects = self.objects.lock().await;
        if !overwrite && objects.contains_key(to.as_str()) {
            return Err(entry_failure(
                to,
                Operation::Publish,
                FailureClass::Conflict,
                Transience::Permanent,
            ));
        }
        let value = objects
            .remove(from.as_str())
            .ok_or_else(|| Self::missing(from, Operation::Publish))?;
        objects.insert(to.as_str().into(), value);
        let mut modes = self.file_modes.lock().await;
        if let Some(mode) = modes.remove(from.as_str()) {
            modes.insert(to.as_str().into(), mode);
        } else {
            modes.remove(to.as_str());
        }
        if self.fail_rename_after_commit.load(Ordering::SeqCst) {
            return Err(entry_failure(
                to,
                Operation::Publish,
                FailureClass::Connectivity,
                Transience::Transient,
            ));
        }
        Ok(())
    }

    async fn create_empty_stage_exclusive(
        &self,
        path: &StoragePath,
    ) -> Result<(), StorageRoleFailure> {
        let mut objects = self.objects.lock().await;
        if objects.contains_key(path.as_str()) {
            return Err(entry_failure(
                path,
                Operation::Prepare,
                FailureClass::Conflict,
                Transience::Permanent,
            ));
        }
        objects.insert(path.as_str().into(), Bytes::new());
        Ok(())
    }

    async fn open_stage_writer(
        &self,
        path: &StoragePath,
        start_offset: u64,
        direct: bool,
    ) -> Result<Box<dyn HdfsWriteSession + '_>, StorageRoleFailure> {
        // Data writers only: the pointer an at-destination stage writes is not an append of it.
        if !is_pointer(path) {
            self.append_calls.fetch_add(1, Ordering::SeqCst);
        }
        if self.fail_write.load(Ordering::SeqCst) {
            return Err(entry_failure(
                path,
                Operation::Write,
                FailureClass::Protocol,
                Transience::Transient,
            ));
        }
        let mut objects = self.objects.lock().await;
        if direct {
            if start_offset != 0 {
                return Err(entry_failure(
                    path,
                    Operation::Write,
                    FailureClass::InvalidInput,
                    Transience::Permanent,
                ));
            }
            objects.insert(path.as_str().into(), Bytes::new());
        } else {
            let current = objects
                .get(path.as_str())
                .ok_or_else(|| Self::missing(path, Operation::Write))?;
            if current.len() as u64 != start_offset {
                return Err(entry_failure(
                    path,
                    Operation::Write,
                    FailureClass::Conflict,
                    Transience::Permanent,
                ));
            }
        }
        drop(objects);
        Ok(Box::new(MemoryWriteSession {
            storage: self,
            path: path.clone(),
            offset: start_offset,
        }))
    }

    async fn stabilize_recovered_stage(
        &self,
        path: &StoragePath,
    ) -> Result<u64, StorageRoleFailure> {
        self.stabilize_calls.fetch_add(1, Ordering::SeqCst);
        if let Some(tail) = self.recovered_tail.lock().await.take() {
            self.objects.lock().await.insert(path.as_str().into(), tail);
        }
        let objects = self.objects.lock().await;
        let value = objects
            .get(path.as_str())
            .ok_or_else(|| Self::missing(path, Operation::Prepare))?;
        Ok(value.len() as u64)
    }

    async fn set_mapped_ownership(
        &self,
        path: &StoragePath,
        owner: &str,
        group: &str,
        mode: u32,
    ) -> Result<(), StorageRoleFailure> {
        self.metadata_calls.lock().await.push(format!(
            "ownership:{}:{owner}:{group}:{mode:o}",
            path.as_str()
        ));
        Ok(())
    }

    async fn set_mode(&self, path: &StoragePath, mode: u32) -> Result<(), StorageRoleFailure> {
        self.file_modes
            .lock()
            .await
            .insert(path.as_str().into(), mode);
        self.metadata_calls
            .lock()
            .await
            .push(format!("mode:{}:{mode:o}", path.as_str()));
        Ok(())
    }

    async fn set_timestamps(
        &self,
        path: &StoragePath,
        atime: Option<i64>,
        mtime: Option<i64>,
    ) -> Result<(), StorageRoleFailure> {
        self.metadata_calls
            .lock()
            .await
            .push(format!("timestamps:{}:{atime:?}:{mtime:?}", path.as_str()));
        Ok(())
    }
}

struct MemoryWriteSession<'a> {
    storage: &'a MemoryHdfs,
    path: StoragePath,
    offset: u64,
}

impl MemoryWriteSession<'_> {
    async fn check_checkpoint_privacy(&self, data: &[u8]) {
        if crate::storage::pointer::DestinationPointer::decode(data)
            .is_ok_and(|pointer| pointer.checkpoint.is_some())
        {
            assert_eq!(
                self.storage.file_mode(self.path.as_str()).await,
                Some(0o600),
                "hash fragments must be private before the first write"
            );
        }
    }
}

#[async_trait]
impl HdfsWriteSession for MemoryWriteSession<'_> {
    async fn write(&mut self, data: Bytes) -> Result<usize, StorageRoleFailure> {
        let pointer = is_pointer(&self.path);
        if pointer {
            self.check_checkpoint_privacy(&data).await;
            self.storage.pointer_writes.fetch_add(1, Ordering::SeqCst);
        }
        if (pointer
            && self
                .storage
                .fail_pointer_write
                .swap(false, Ordering::SeqCst))
            || (self.storage.hsync_completed.load(Ordering::SeqCst)
                && !pointer
                && self.storage.fail_after_hsync.swap(false, Ordering::SeqCst))
        {
            return Err(entry_failure(
                &self.path,
                Operation::Write,
                FailureClass::Protocol,
                Transience::Transient,
            ));
        }
        self.storage
            .write_peak
            .fetch_max(data.len(), Ordering::SeqCst);
        let mut objects = self.storage.objects.lock().await;
        let value = objects
            .get_mut(self.path.as_str())
            .ok_or_else(|| MemoryHdfs::missing(&self.path, Operation::Write))?;
        if value.len() as u64 != self.offset {
            return Err(entry_failure(
                &self.path,
                Operation::Write,
                FailureClass::Conflict,
                Transience::Permanent,
            ));
        }
        let count = data.len();
        let mut appended = BytesMut::from(value.as_ref());
        appended.extend_from_slice(&data);
        *value = appended.freeze();
        self.offset = self
            .offset
            .checked_add(count as u64)
            .ok_or_else(|| MemoryHdfs::missing(&self.path, Operation::Write))?;
        Ok(count)
    }

    async fn hsync(&mut self) -> Result<(), StorageRoleFailure> {
        self.storage.hsync_calls.fetch_add(1, Ordering::SeqCst);
        self.storage.hsync_completed.store(true, Ordering::SeqCst);
        Ok(())
    }

    async fn close(self: Box<Self>) -> Result<(), StorageRoleFailure> {
        if !is_pointer(&self.path) {
            self.storage.data_closes.fetch_add(1, Ordering::SeqCst);
        }
        Ok(())
    }
}

#[tokio::test]
async fn exclusive_stage_creation_preserves_existing_partial() {
    let storage = MemoryHdfs::default();
    let path = StoragePath::new("partial").unwrap_or_else(|error| panic!("{error}"));

    storage
        .create_empty_stage_exclusive(&path)
        .await
        .unwrap_or_else(|error| panic!("{error:?}"));
    let conflict = storage.create_empty_stage_exclusive(&path).await;

    assert!(conflict.is_err());
    assert_eq!(storage.get("partial").await, Some(Bytes::new()));
}

struct ActiveRead<'a>(&'a MemoryHdfs);
impl Drop for ActiveRead<'_> {
    fn drop(&mut self) {
        self.0.read_active.fetch_sub(1, Ordering::SeqCst);
    }
}
