use std::sync::Arc;

use async_trait::async_trait;

use crate::model::{
    BackendIdentity, FailureClass, MetadataCapabilities, MetadataFamily as F, MetadataObservation,
    MetadataObservations, MetadataProvenance, ObjectTag, ObservationMode, ObservationPlan,
    ObservationSupport as S, Operation, SourceIdentity, SourceVersion, StoragePath,
    TimestampMetadata, Transience,
};
use crate::storage::{CopiedMetadataObservation, Metadata, MetadataMutation, StorageRoleFailure};

use super::source::{cancelled, classified_entry, entry, object_identity, role_failure};
use super::{S3ObjectFacts, S3Protocol, S3ProtocolFailure};

pub struct S3Metadata<P> {
    protocol: Arc<P>,
    identity: BackendIdentity,
    tag_support: S3TagSupport,
}

#[derive(Clone, Copy)]
pub enum S3TagSupport {
    Supported,
    Unsupported,
}

impl<P> S3Metadata<P> {
    pub const fn new(
        protocol: Arc<P>,
        identity: BackendIdentity,
        tag_support: S3TagSupport,
    ) -> Self {
        Self {
            protocol,
            identity,
            tag_support,
        }
    }
}

/// Owner and mode: an object has none, so there is nothing to carry and nothing lost.
fn omitted<T>(mode: ObservationMode) -> MetadataObservation<T> {
    match mode {
        ObservationMode::Omit => MetadataObservation::NotRequested,
        ObservationMode::InlineOnly => MetadataObservation::Unsupported,
        ObservationMode::BestEffort | ObservationMode::Required => {
            MetadataObservation::NotApplicable
        }
    }
}

/// ACLs and extended attributes in the file sense: S3 cannot give them, so a copy that asked
/// for them reports them skipped because of the source.
fn cannot_read<T>(mode: ObservationMode) -> MetadataObservation<T> {
    if mode == ObservationMode::Omit {
        MetadataObservation::NotRequested
    } else {
        MetadataObservation::Unsupported
    }
}

/// The object's own `Last-Modified`, from the same response as its identity. An object carries no
/// access or creation time; the legacy `x-amz-meta-last-modified` header is not consulted.
fn timestamps(
    mode: ObservationMode,
    facts: Option<&S3ObjectFacts>,
) -> MetadataObservation<TimestampMetadata> {
    match (mode, facts) {
        (ObservationMode::Omit, _) => MetadataObservation::NotRequested,
        (_, None) => MetadataObservation::Unsupported,
        (_, Some(facts)) => MetadataObservation::Value {
            value: TimestampMetadata {
                accessed: None,
                modified: facts.last_modified,
                created: None,
            },
            provenance: MetadataProvenance::AdditionalCall,
        },
    }
}

/// An inline-only plan can report unsupported families without asking the object again.
fn permits_additional_calls(plan: ObservationPlan) -> bool {
    [
        plan.acl(),
        plan.xattrs(),
        plan.tags(),
        plan.ownership_mode(),
        plan.timestamps(),
    ]
    .into_iter()
    .any(|mode| {
        matches!(
            mode,
            ObservationMode::BestEffort | ObservationMode::Required
        )
    })
}

impl<P: S3Protocol + 'static> S3Metadata<P> {
    async fn head(
        &self,
        path: &StoragePath,
        version: &SourceVersion,
    ) -> Result<S3ObjectFacts, StorageRoleFailure> {
        match version.version_id() {
            None => self.protocol.head(path.as_str()).await,
            Some(version) => self.protocol.head_version(path.as_str(), version).await,
        }
        .map_err(|e| role_failure(path, Operation::Metadata, e))
    }

    /// Observes `version` of `path` in one HEAD that must still show the expected identity, so a
    /// replaced object is a conflict rather than the new object's time on the old object's bytes.
    async fn observe_version_bound(
        &self,
        path: &StoragePath,
        expected: &SourceIdentity,
        version: &SourceVersion,
        plan: ObservationPlan,
    ) -> Result<MetadataObservations, StorageRoleFailure> {
        if !permits_additional_calls(plan) {
            return self.observations(path, plan, None, version).await;
        }
        let facts = self.head(path, version).await?;
        let observed = object_identity(&self.identity, path, &facts)
            .map_err(|e| entry(path, Operation::Metadata, e.to_string()))?;
        if observed != *expected {
            return Err(classified_entry(
                path,
                Operation::Metadata,
                FailureClass::Conflict,
                Transience::Permanent,
                "S3 source identity changed",
            ));
        }
        self.observations(path, plan, Some(&facts), version).await
    }

    async fn observations(
        &self,
        path: &StoragePath,
        plan: ObservationPlan,
        facts: Option<&S3ObjectFacts>,
        version: &SourceVersion,
    ) -> Result<MetadataObservations, StorageRoleFailure> {
        MetadataObservations::new(
            cannot_read(plan.acl()),
            cannot_read(plan.xattrs()),
            self.tags(path, plan.tags(), version.version_id()).await?,
            omitted(plan.ownership_mode()),
            timestamps(plan.timestamps(), facts),
        )
        .map_err(|e| entry(path, Operation::Metadata, e.to_string()))
    }

    async fn tags(
        &self,
        path: &StoragePath,
        mode: ObservationMode,
        version: Option<&str>,
    ) -> Result<MetadataObservation<Vec<ObjectTag>>, StorageRoleFailure> {
        Ok(if matches!(self.tag_support, S3TagSupport::Supported) {
            match mode {
                ObservationMode::Omit => MetadataObservation::NotRequested,
                ObservationMode::InlineOnly => MetadataObservation::Unsupported,
                ObservationMode::BestEffort | ObservationMode::Required => {
                    match self.protocol.get_tags(path.as_str(), version).await {
                        Ok(value) => MetadataObservation::Value {
                            value,
                            provenance: MetadataProvenance::AdditionalCall,
                        },
                        Err(S3ProtocolFailure::Entry {
                            class, transience, ..
                        }) if mode == ObservationMode::BestEffort => {
                            MetadataObservation::Failed { class, transience }
                        }
                        Err(failure) => {
                            return Err(role_failure(path, Operation::Metadata, failure));
                        }
                    }
                }
            }
        } else {
            match mode {
                ObservationMode::Omit => MetadataObservation::NotRequested,
                _ => MetadataObservation::Unsupported,
            }
        })
    }
}

#[async_trait]
impl<P: S3Protocol + 'static> Metadata for S3Metadata<P> {
    fn observation_capabilities(&self) -> MetadataCapabilities {
        MetadataCapabilities::default()
            .with(F::Acl, S::Unsupported)
            .with(F::Xattrs, S::Unsupported)
            .with(
                F::Tags,
                match self.tag_support {
                    S3TagSupport::Supported => S::Supported,
                    S3TagSupport::Unsupported => S::Unsupported,
                },
            )
            .with(F::OwnershipMode, S::NotApplicable)
            .with(F::Timestamps, S::Supported)
    }

    /// Every copy from S3 carries the object's `Last-Modified` as the file's mtime; owner and mode
    /// are asked for only so the plan records that an object has none.
    fn copied_metadata_observation_plan(&self) -> Option<ObservationPlan> {
        Some(
            ObservationPlan::default()
                .with_ownership_mode(ObservationMode::Required)
                .with_timestamps(ObservationMode::Required),
        )
    }

    async fn observe(
        &self,
        path: &StoragePath,
        plan: ObservationPlan,
    ) -> Result<MetadataObservations, StorageRoleFailure> {
        let current = SourceVersion::Current;
        let facts = match plan.timestamps() {
            ObservationMode::BestEffort | ObservationMode::Required => {
                Some(self.head(path, &current).await?)
            }
            ObservationMode::Omit | ObservationMode::InlineOnly => None,
        };
        self.observations(path, plan, facts.as_ref(), &current)
            .await
    }

    /// Binds the time to the object the copy described: the `Last-Modified` comes from a HEAD whose
    /// `ETag` / version must still be the one described, so a replaced object is a conflict rather
    /// than the new object's time on the old object's bytes.
    async fn observe_bound(
        &self,
        path: &StoragePath,
        expected: &SourceIdentity,
        plan: ObservationPlan,
    ) -> Result<MetadataObservations, StorageRoleFailure> {
        self.observe_version_bound(path, expected, &SourceVersion::Current, plan)
            .await
    }

    /// The copy baseline of the version the describe pinned: its own `Last-Modified` and tags,
    /// also when a newer version became current meanwhile.
    async fn observe_copy_bound_version(
        &self,
        path: &StoragePath,
        expected: &SourceIdentity,
        version: &SourceVersion,
        plan: ObservationPlan,
    ) -> Result<CopiedMetadataObservation, StorageRoleFailure> {
        Ok(CopiedMetadataObservation {
            observations: self
                .observe_version_bound(path, expected, version, plan)
                .await?,
            mode_without_ownership: None,
            owner_names_unmapped: false,
        })
    }

    async fn apply(
        &self,
        path: &crate::model::StoragePath,
        mutation: MetadataMutation,
        cancel: tokio_util::sync::CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        if cancel.is_cancelled() {
            return Err(cancelled(path, Operation::Metadata));
        }
        if matches!(self.tag_support, S3TagSupport::Unsupported)
            && matches!(mutation, MetadataMutation::Tags(_))
        {
            return Err(super::source::classified_entry(
                path,
                Operation::Metadata,
                FailureClass::Unsupported,
                Transience::Permanent,
                "object tags are unsupported by this S3 compatibility profile",
            ));
        }
        match mutation {
            MetadataMutation::Tags(tags) => self
                .protocol
                .put_tags(path.as_str(), &tags)
                .await
                .map_err(|e| role_failure(path, Operation::Metadata, e)),
            _ => Err(entry(
                path,
                Operation::Metadata,
                "metadata kind is unsupported by S3",
            )),
        }
    }
}

#[cfg(test)]
#[path = "metadata_tests.rs"]
mod tests;
