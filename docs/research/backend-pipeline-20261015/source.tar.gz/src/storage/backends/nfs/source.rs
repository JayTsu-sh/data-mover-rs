use std::fmt;
use std::sync::Arc;

use async_trait::async_trait;
use bytes::Bytes;
use futures::StreamExt as _;
use futures::future::Either;
use futures::stream::{FuturesOrdered, FuturesUnordered};

use crate::model::{
    BackendIdentity, BackendSessionFailure, EntryKind, EntryOperationFailure, FailureClass,
    IdentityStrength, Operation, SourceIdentity, SourceVersion, StoragePath, Transience,
};
use crate::storage::ListingFacts;
use crate::storage::{
    ByteStream, PositionedByteStream, PositionedChunk, ReadRequest, ReadSource, SourceDescriptor,
    StorageRoleFailure,
};

const MAX_ROLE_READ: usize = 1024 * 1024;

#[derive(Clone)]
pub(crate) struct NfsSourceObservation {
    pub(crate) kind: EntryKind,
    pub(crate) size: Option<u64>,
    pub(crate) file_handle: Bytes,
    pub(crate) content_version: Bytes,
    pub(crate) timestamps: Option<crate::model::TimestampMetadata>,
    pub(crate) ownership: Option<crate::storage::InlineOwnership>,
    pub(crate) mode: Option<u32>,
}

#[derive(Clone)]
pub(crate) struct NfsProtocolFailure {
    pub(crate) class: FailureClass,
    pub(crate) transience: Transience,
    /// The status the server answered with, when the failure came from one — `NFS4ERR_PERM
    /// (permission denied)`: the diagnostic names it, so a refused owner can be told from a
    /// refused permission without a packet capture.
    pub(crate) status: Option<Arc<str>>,
    /// The directory level that failed, when it is not the entry the operation names: a missing
    /// parent the write, rename or directory creation had to create first
    /// (`NFSStorage::role_create_all`). The failure is reported at that level, and the
    /// diagnostic names the operation's own entry.
    pub(crate) level: Option<StoragePath>,
}

impl NfsProtocolFailure {
    /// A failure with no server status: the client or transport decided it.
    pub(crate) const fn new(class: FailureClass, transience: Transience) -> Self {
        Self {
            class,
            transience,
            status: None,
            level: None,
        }
    }

    /// Reports the failure at the missing parent `level` that failed, unless a deeper call
    /// already named the level that failed.
    #[must_use]
    pub(crate) fn at_level(mut self, level: StoragePath) -> Self {
        self.level.get_or_insert(level);
        self
    }

    pub(crate) const fn protocol() -> Self {
        Self::new(FailureClass::Protocol, Transience::Permanent)
    }

    /// Names the status the server answered with.
    pub(crate) fn with_status(mut self, status: impl fmt::Debug + fmt::Display) -> Self {
        self.status = Some(Arc::from(format!("{status:?} ({status})")));
        self
    }
}

#[async_trait]
pub(crate) trait NfsReadCursor: Send + Sync {
    async fn read_at(&self, offset: u64, count: usize) -> Result<Bytes, NfsProtocolFailure>;
}

#[async_trait]
pub(crate) trait NfsSourceProtocol: Send + Sync {
    fn read_concurrency(&self) -> usize {
        4
    }
    fn maximum_read_chunk_bytes(&self) -> usize {
        MAX_ROLE_READ
    }
    async fn describe(
        &self,
        path: &StoragePath,
    ) -> Result<NfsSourceObservation, NfsProtocolFailure>;
    async fn open(
        &self,
        path: &StoragePath,
    ) -> Result<(Box<dyn NfsReadCursor>, Bytes), NfsProtocolFailure>;
}

pub(crate) struct NfsReadSourceAdapter {
    protocol: Arc<dyn NfsSourceProtocol>,
    identity: BackendIdentity,
}

impl NfsReadSourceAdapter {
    pub(crate) fn new(protocol: Arc<dyn NfsSourceProtocol>, identity: BackendIdentity) -> Self {
        Self { protocol, identity }
    }

    #[cfg(test)]
    fn with_protocol(protocol: Arc<dyn NfsSourceProtocol>, identity: BackendIdentity) -> Self {
        Self { protocol, identity }
    }

    async fn descriptor(&self, path: &StoragePath) -> Result<SourceDescriptor, StorageRoleFailure> {
        let observed = self
            .protocol
            .describe(path)
            .await
            .map_err(|error| role_failure(path, Operation::Observe, error))?;
        let source_identity = SourceIdentity::new(
            self.identity.clone(),
            IdentityStrength::StableWithinBackend,
            &observed.file_handle,
        )
        .map_err(|_| role_failure(path, Operation::Observe, NfsProtocolFailure::protocol()))?;
        Ok(SourceDescriptor {
            path: path.clone(),
            kind: observed.kind,
            size: observed.size,
            source_identity,
            backend_fact: None,
            content_version: Some(observed.content_version),
            inline_timestamps: observed.timestamps,
            inline_mode: observed.mode,
            inline_ownership: observed.ownership,
            version: SourceVersion::Current,
            listing: ListingFacts::default(),
        })
    }
}

#[async_trait]
impl ReadSource for NfsReadSourceAdapter {
    fn read_concurrency(&self) -> usize {
        self.protocol.read_concurrency().max(1)
    }
    fn supports_read_budget(&self) -> bool {
        true
    }
    fn maximum_read_chunk_bytes(&self) -> usize {
        self.protocol.maximum_read_chunk_bytes().max(1)
    }

    async fn describe(&self, path: &StoragePath) -> Result<SourceDescriptor, StorageRoleFailure> {
        self.descriptor(path).await
    }

    fn supports_positioned_read(&self) -> bool {
        true
    }

    async fn read(&self, request: ReadRequest) -> Result<ByteStream, StorageRoleFailure> {
        request.require_current()?;
        let state = self.open_state(request, false).await?;
        Ok(Box::pin(
            futures::stream::try_unfold(state, read_next)
                .map(|result| result.map(|chunk| chunk.data)),
        ))
    }

    async fn read_positioned(
        &self,
        request: ReadRequest,
    ) -> Result<PositionedByteStream, StorageRoleFailure> {
        request.require_current()?;
        let state = self.open_state(request, true).await?;
        Ok(Box::pin(futures::stream::try_unfold(state, read_next)))
    }
}

impl NfsReadSourceAdapter {
    async fn open_state(
        &self,
        request: ReadRequest,
        unordered: bool,
    ) -> Result<ReadState, StorageRoleFailure> {
        if request.cancel.is_cancelled() {
            return Err(cancelled(&request.path));
        }
        if request.maximum_chunk_bytes == 0 || request.read_inflight == 0 {
            return Err(entry_failure(
                &request.path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            ));
        }
        let range = if let Some(range) = request.range {
            range
        } else {
            let observed = self.descriptor(&request.path).await?;
            0..observed.size.ok_or_else(|| {
                entry_failure(
                    &request.path,
                    Operation::Read,
                    FailureClass::Unsupported,
                    Transience::Permanent,
                )
            })?
        };
        if range.end < range.start {
            return Err(entry_failure(
                &request.path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            ));
        }
        let (cursor, opened_handle) = self
            .protocol
            .open(&request.path)
            .await
            .map_err(|error| role_failure(&request.path, Operation::Read, error))?;
        let opened_identity = SourceIdentity::new(
            self.identity.clone(),
            IdentityStrength::StableWithinBackend,
            opened_handle,
        )
        .map_err(|_| {
            entry_failure(
                &request.path,
                Operation::Read,
                FailureClass::Protocol,
                Transience::Permanent,
            )
        })?;
        if request
            .expected_source
            .as_ref()
            .is_some_and(|expected| expected != &opened_identity)
        {
            return Err(entry_failure(
                &request.path,
                Operation::Read,
                FailureClass::Conflict,
                Transience::Permanent,
            ));
        }
        let state = ReadState {
            cursor: Arc::from(cursor),
            path: request.path,
            next_issue: range.start,
            next_emit: range.start,
            end: range.end,
            maximum_chunk_bytes: request
                .maximum_chunk_bytes
                .min(self.protocol.maximum_read_chunk_bytes().max(1)),
            read_concurrency: request.read_inflight.min(self.read_concurrency()),
            inflight: if unordered {
                Either::Right(FuturesUnordered::new())
            } else {
                Either::Left(FuturesOrdered::new())
            },
            cancel: request.cancel,
            qos: request.source_qos,
            budget: request.read_budget,
        };
        Ok(state)
    }
}

struct ReadState {
    cursor: Arc<dyn NfsReadCursor>,
    path: StoragePath,
    next_issue: u64,
    next_emit: u64,
    end: u64,
    maximum_chunk_bytes: usize,
    read_concurrency: usize,
    inflight: Either<FuturesOrdered<NfsReadFuture>, FuturesUnordered<NfsReadFuture>>,
    cancel: tokio_util::sync::CancellationToken,
    qos: Option<crate::storage::SourceQosBudget>,
    budget: Option<crate::storage::ReadBudget>,
}

impl ReadState {
    fn inflight_len(&self) -> usize {
        match &self.inflight {
            Either::Left(queue) => queue.len(),
            Either::Right(queue) => queue.len(),
        }
    }
}

type NfsReadFuture = std::pin::Pin<
    Box<
        dyn std::future::Future<
                Output = (
                    u64,
                    usize,
                    Result<Bytes, NfsProtocolFailure>,
                    Option<crate::storage::ReadAdmission>,
                ),
            > + Send,
    >,
>;

async fn fill_read_pipeline(state: &mut ReadState) -> Result<(), StorageRoleFailure> {
    while state.inflight_len() < state.read_concurrency && state.next_issue < state.end {
        if state.cancel.is_cancelled() {
            return Err(cancelled(&state.path));
        }
        let requested = (state.end - state.next_issue).min(state.maximum_chunk_bytes as u64);
        let admission = if let Some(budget) = &state.budget {
            let Some(admission) = budget
                .reserve(
                    usize::try_from(requested).map_err(|_| {
                        entry_failure(
                            &state.path,
                            Operation::Read,
                            FailureClass::InvalidInput,
                            Transience::Permanent,
                        )
                    })?,
                    state.inflight_len() == 0,
                )
                .await
                .map_err(|_| cancelled(&state.path))?
            else {
                break;
            };
            Some(admission)
        } else {
            None
        };
        let granted = if let Some(qos) = &state.qos {
            qos.admit_read(requested, &state.cancel)
                .await
                .map_err(|_| cancelled(&state.path))?
        } else {
            requested
        };
        let count = usize::try_from(granted).map_err(|_| {
            entry_failure(
                &state.path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            )
        })?;
        let offset = state.next_issue;
        let cursor = Arc::clone(&state.cursor);
        let cancel = state.cancel.clone();
        let future: NfsReadFuture = Box::pin(async move {
            let result = tokio::select! {
                biased;
                () = cancel.cancelled() => Err(NfsProtocolFailure::new(
                    FailureClass::Cancelled,
                    Transience::Transient,
                )),
                result = cursor.read_at(offset, count) => result,
            };
            (offset, count, result, admission)
        });
        match &mut state.inflight {
            Either::Left(queue) => queue.push_back(future),
            Either::Right(queue) => queue.push(future),
        }
        state.next_issue = state.next_issue.checked_add(granted).ok_or_else(|| {
            entry_failure(
                &state.path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            )
        })?;
    }
    Ok(())
}

async fn read_next(
    mut state: ReadState,
) -> Result<Option<(PositionedChunk, ReadState)>, StorageRoleFailure> {
    fill_read_pipeline(&mut state).await?;
    if state.inflight_len() == 0 {
        return Ok(None);
    }
    let next = tokio::select! {
        biased;
        () = state.cancel.cancelled() => return Err(cancelled(&state.path)),
        result = state.inflight.next() => result,
    };
    let (offset, count, result, admission) = next.ok_or_else(|| {
        entry_failure(
            &state.path,
            Operation::Read,
            FailureClass::Internal,
            Transience::Unknown,
        )
    })?;
    if matches!(state.inflight, Either::Left(_)) && offset != state.next_emit {
        return Err(entry_failure(
            &state.path,
            Operation::Read,
            FailureClass::Internal,
            Transience::Unknown,
        ));
    }
    let bytes = result.map_err(|error| role_failure(&state.path, Operation::Read, error))?;
    if bytes.len() != count {
        return Err(entry_failure(
            &state.path,
            Operation::Read,
            FailureClass::Corruption,
            Transience::Unknown,
        ));
    }
    if let Some(qos) = &state.qos {
        qos.record_read_bytes(bytes.len() as u64);
    }
    state.next_emit = state
        .next_emit
        .checked_add(bytes.len() as u64)
        .ok_or_else(|| {
            entry_failure(
                &state.path,
                Operation::Read,
                FailureClass::InvalidInput,
                Transience::Permanent,
            )
        })?;
    if let (Some(budget), Some(admission)) = (&state.budget, admission) {
        budget.ready(offset, admission);
    }
    Ok(Some((
        PositionedChunk {
            offset,
            data: bytes,
        },
        state,
    )))
}

pub(super) fn cancelled(path: &StoragePath) -> StorageRoleFailure {
    entry_failure(
        path,
        Operation::Read,
        FailureClass::Cancelled,
        Transience::Transient,
    )
}

pub(super) fn role_failure(
    path: &StoragePath,
    operation: Operation,
    error: NfsProtocolFailure,
) -> StorageRoleFailure {
    if error.class == FailureClass::Connectivity {
        let diagnostic = diagnostic("session", error.status.as_deref());
        return StorageRoleFailure::Session(
            BackendSessionFailure::new(operation, error.class, error.transience, diagnostic)
                .unwrap_or_else(|_| unreachable!("{DIAGNOSTIC_IS_VALID}")),
        );
    }
    entry_scoped(path, operation, error)
}

/// The failure as entry-scoped even when it is a connectivity class — for callers that must not
/// promote it to the session — keeping the server's status in the diagnostic.
pub(super) fn entry_scoped(
    path: &StoragePath,
    operation: Operation,
    error: NfsProtocolFailure,
) -> StorageRoleFailure {
    let NfsProtocolFailure {
        class,
        transience,
        status,
        level,
    } = error;
    let plain = diagnostic("role", status.as_deref());
    let (at, diagnostic) = match level {
        Some(level) if level != *path => {
            let context = parent_context(path, operation, status.as_deref());
            (level, context)
        }
        _ => (path.clone(), plain.clone()),
    };
    let failure = EntryOperationFailure::new(at.clone(), operation, class, transience, diagnostic)
        .or_else(|_| EntryOperationFailure::new(at, operation, class, transience, plain));
    StorageRoleFailure::Entry(failure.unwrap_or_else(|_| unreachable!("{DIAGNOSTIC_IS_VALID}")))
}

/// The diagnostic of a failure at a missing parent level: which entry's operation needed it.
fn parent_context(path: &StoragePath, operation: Operation, status: Option<&str>) -> String {
    let context = format!(
        "NFS role failed creating a missing parent directory of `{}` ({operation:?})",
        path.as_str()
    );
    match status {
        Some(status) => format!("{context}: {status}"),
        None => context,
    }
}

const DIAGNOSTIC_IS_VALID: &str =
    "the prefix is non-blank and nfs-rs status text is fixed, NUL-free and short";

fn diagnostic(scope: &str, status: Option<&str>) -> String {
    match status {
        Some(status) => format!("NFS {scope} failed: {status}"),
        None => format!("NFS {scope} failed"),
    }
}

pub(super) fn entry_failure(
    path: &StoragePath,
    operation: Operation,
    class: FailureClass,
    transience: Transience,
) -> StorageRoleFailure {
    StorageRoleFailure::Entry(
        EntryOperationFailure::new(
            path.clone(),
            operation,
            class,
            transience,
            "NFS role failed",
        )
        .unwrap_or_else(|_| unreachable!("static diagnostic is valid")),
    )
}

#[cfg(test)]
#[path = "source_tests.rs"]
mod tests;
