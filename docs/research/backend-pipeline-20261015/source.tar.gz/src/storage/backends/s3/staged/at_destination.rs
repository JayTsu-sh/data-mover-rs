//! Destination-resident recovery for S3 (ADR-0006 C15b): an object larger than the single-PUT
//! threshold is a multipart upload on its final key, and a checkpointed one is resumable through
//! the `.upload` pointer object beside that key (see [`upload_pointer`](super::upload_pointer)).
//!
//! The pointer names the upload and carries no durable prefix: the parts `ListParts` reports are
//! the durable record. A resume continues from their **contiguous prefix** — parts `1..=k`, each
//! exactly the pointer's part size, the last one shorter only when it ends exactly at the source's
//! size. A gap is not corruption (parts finish out of order, so a process killed mid-write leaves
//! some): the parts after it are uploaded again, and uploading a part number again replaces it.
//!
//! As on NFS, CIFS and HDFS, every prepare draws a nonce and records it in the pointer (a resume
//! rewrites the pointer with its own); before it writes the pointer, completes the upload, or
//! cleans up, a stage reads the pointer back, and another nonce there — or no pointer after it
//! wrote one — means another writer took the upload over (`Conflict`, permanent). The fence is a
//! check, not a lock, and a stage without a pointer has nothing to fence with until its first
//! checkpoint; both are two writers of one key, which the caller contract excludes.
//!
//! Publication completes the upload; nothing is written to the final key before it, and the final
//! key is never deleted. Once the upload completed, failing to delete the pointer is a warning
//! (the next prepare of the key cleans it up). Verification reads the object back after
//! publication.
//!
//! In a versioned bucket (ADR-0006 C17) the pointer is deleted by the version its write reported,
//! a resume deletes the version of the pointer it replaced, and a completion whose reply was lost
//! is settled through the key's versions, claiming the version it made (see
//! [`completion`](super::completion)).

use std::sync::Arc;
use std::sync::atomic::Ordering;

use async_trait::async_trait;
use tokio_util::sync::CancellationToken;

use super::super::source::{cancelled, classified_entry, entry, role_failure};
use super::super::{S3Protocol, S3ProtocolFailure, S3WriteFacts, composite_etag};
use super::completion::completed_object;
use super::direct::is_composite;
use super::final_upload::FinalUpload;
pub(super) use super::final_upload::of;
use super::parts::{PartTarget, PartsCheckpoint};
use super::upload_discovery::{S3Artifacts, leftover_reason};
use super::upload_pointer::{self, pointer_path};
use super::{
    S3StagedDestination, cleanup_result, limits, metadata_unavailable, planned_part_size, single,
};
use crate::model::{FailureClass, ObjectTag, Operation, StoragePath, Transience};
use crate::storage::discovery::discover;
use crate::storage::pointer::{DestinationPointer, MAX_POINTER_BYTES};
use crate::storage::{
    ByteStream, CheckpointObservation, DestinationPrepareRequest, MetadataMutation, PrepareFact,
    PreparedStage, PublicationDisposition, PublicationEvidence, PublicationFailure, PublishRequest,
    ResumeMode, StorageRoleFailure, VerificationEvidence, VerifyRequest, WriteEvidence,
};

/// Whether the pointer is still this stage's.
enum Fence {
    /// Present with our nonce (`pointer`), or — before we wrote one — absent.
    Ours {
        pointer: bool,
    },
    TakenOver,
}

fn failure(path: &StoragePath, operation: Operation, class: FailureClass) -> StorageRoleFailure {
    classified_entry(
        path,
        operation,
        class,
        Transience::Permanent,
        "S3 upload on the final key",
    )
}

fn taken_over(path: &StoragePath, operation: Operation) -> StorageRoleFailure {
    // Another writer holds the upload now; retrying would take it back and forth.
    classified_entry(
        path,
        operation,
        FailureClass::Conflict,
        Transience::Permanent,
        "another writer took the S3 upload over",
    )
}

fn is_not_found(failure: &S3ProtocolFailure) -> bool {
    matches!(
        failure,
        S3ProtocolFailure::Entry {
            class: FailureClass::NotFound,
            ..
        }
    )
}

/// A completion the service refused before it could commit anything. `NoSuchUpload` is not one:
/// it is also how a retried completion that already committed is answered.
fn refused_before_commit(failure: &S3ProtocolFailure) -> bool {
    single::definite_refusal(failure) && !is_not_found(failure)
}

fn unchanged(error: StorageRoleFailure) -> PublicationFailure {
    PublicationFailure {
        error,
        final_destination_changed: false,
    }
}

fn changed(error: StorageRoleFailure) -> PublicationFailure {
    PublicationFailure {
        error,
        final_destination_changed: true,
    }
}

/// At the upload's first deferred checkpoint: writes the pointer unless prepare already did, and
/// turns the stage's recovery on.
struct PointerCheckpoint<'a, P> {
    adapter: &'a S3StagedDestination<P>,
    stage: &'a PreparedStage,
    upload: &'a FinalUpload,
}

#[async_trait]
impl<P: S3Protocol + 'static> PartsCheckpoint for PointerCheckpoint<'_, P> {
    async fn reached(&self) -> Result<(), StorageRoleFailure> {
        if !self.upload.pointer_written() {
            self.adapter
                .write_pointer(self.stage, self.upload, false)
                .await?;
        }
        self.stage.recovery_enabled.store(true, Ordering::Release);
        Ok(())
    }
}

impl<P: S3Protocol + 'static> S3StagedDestination<P> {
    /// Prepares by looking at the destination first. Up to T a single stage (after cleaning up a
    /// leftover pointer); above T one streamed `PutObject` ([`streaming`](super::streaming), after
    /// the same clean-up) for a directory object (one request up to 5 GiB, P7 D13 / F5h) and for
    /// any object on a bucket without multipart uploads (§14.2); otherwise, or of unknown size, a
    /// multipart upload on the final key that resumes or starts over as the decision table says.
    pub(super) async fn prepare_at_destination_stage(
        &self,
        request: DestinationPrepareRequest,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        let path = request.prepare.final_destination.path().clone();
        let size = request.prepare.source.size;
        limits::refuse(self.protocol.bucket_capabilities(), &path, size)?;
        let single = self.single_put_size(&path, size)?;
        let pointer = pointer_path(&path)?;
        if let Some(size) = single {
            let fact = self.clear_leftover(&request, &pointer).await?;
            let previous = self.previous_object(&path).await?;
            let mut stage = self.prepare_single(request.prepare, size, previous);
            stage.mark_at_destination(fact);
            return Ok(stage);
        }
        if let Some(size) = self.streamed_size(&path, size) {
            // One streamed PutObject (a directory object over the threshold, P7 F5h; any object on
            // a bucket without multipart uploads, §14.2): nothing to resume, and what an earlier
            // writer left is cleaned up as for a buffered one (nothing to look for where the bucket
            // keeps no progress).
            let fact = self.clear_leftover(&request, &pointer).await?;
            let mut stage = self.prepare_streaming(request.prepare, size, false).await?;
            stage.mark_at_destination(fact);
            return Ok(stage);
        }
        let part_size = planned_part_size(size, &path)?;
        self.prepare_final_upload(request, part_size, pointer).await
    }

    /// A multipart upload on the final key with parts of `part_size` bytes: the one discovery
    /// found, resumed at the part size its pointer records, or a new one.
    pub(super) async fn prepare_final_upload(
        &self,
        request: DestinationPrepareRequest,
        part_size: usize,
        pointer: StoragePath,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        let path = request.prepare.final_destination.path().clone();
        limits::refuse_multipart(self.protocol.bucket_capabilities(), &path)?;
        let artifacts = S3Artifacts::new(&*self.protocol, &path, &pointer, &request);
        let found = discover(&artifacts, &request).await?;
        let Some(point) = found.resume else {
            let held = artifacts.held_pointer();
            return self
                .start_upload(&request, part_size, pointer, found.fact, held)
                .await;
        };
        let left = artifacts.into_found();
        let record = left
            .record
            .ok_or_else(|| failure(&path, Operation::Prepare, FailureClass::Internal))?;
        let upload = FinalUpload::new(&request, record.upload_id, record.part_size, pointer)?;
        upload.lock().parts = left.prefix;
        let stage = self.upload_stage(&request, upload, point.prefix, found.fact);
        let upload =
            of(&stage).ok_or_else(|| failure(&path, Operation::Prepare, FailureClass::Internal))?;
        // Take the upload over first, then abort whatever else an earlier writer left on the key.
        self.write_pointer(&stage, upload, true).await?;
        let ours = upload.lock().pointer_version.clone();
        let replaced = left.pointer.unwrap_or_default();
        let replaced_gone = upload_pointer::delete_replaced(
            &*self.protocol,
            &upload.pointer,
            replaced.version.as_deref(),
            ours.as_deref(),
        )
        .await;
        upload.forget_replaced(replaced.bytes, replaced_gone);
        upload_pointer::abort_uploads(&*self.protocol, &path, Some(&upload.upload_id)).await?;
        Ok(stage)
    }

    /// Before an object written in one request (a single `PutObject`, C14b, or one `CopyObject`,
    /// C18) only the pointer is looked at — no listing, for cost: a leftover one is removed with
    /// the uploads on the key, and the prepare reports the restart. A bucket that keeps no
    /// progress (P7 §14.2) holds no pointer to look for: nothing is asked, and the stage is fresh.
    pub(super) async fn clear_leftover(
        &self,
        request: &DestinationPrepareRequest,
        pointer: &StoragePath,
    ) -> Result<PrepareFact, StorageRoleFailure> {
        if !self.protocol.bucket_capabilities().resumable {
            return Ok(PrepareFact::Fresh);
        }
        let path = request.prepare.final_destination.path();
        let Some(found) =
            upload_pointer::read(&*self.protocol, pointer, MAX_POINTER_BYTES + 1).await?
        else {
            return Ok(PrepareFact::Fresh);
        };
        let reason = leftover_reason(request, &found.bytes);
        let stale = [found.bytes.as_slice()];
        let version = found.version.as_deref();
        upload_pointer::delete(&*self.protocol, pointer, version, &stale).await?;
        upload_pointer::abort_uploads(&*self.protocol, path, None).await?;
        Ok(PrepareFact::Restarted { reason })
    }

    fn upload_stage(
        &self,
        request: &DestinationPrepareRequest,
        upload: FinalUpload,
        write_offset: u64,
        fact: PrepareFact,
    ) -> PreparedStage {
        let final_destination = request.prepare.final_destination.clone();
        let token = Self::encode_token(final_destination.path().as_str(), &upload.upload_id);
        let mut stage = PreparedStage::new(
            self.identity.clone(),
            final_destination,
            token,
            request.prepare.recovery_binding,
            write_offset,
            None,
        );
        stage.backend_state = Some(Arc::new(upload));
        stage.mark_at_destination(fact);
        stage
    }

    /// Begins a new upload on the final key (discovery aborted any other). A recoverable stage
    /// over the automatic interval writes its pointer at once, and so does a resumable one of
    /// known size over it (ADR-0006 C16); any other at its first deferred checkpoint, if it has
    /// one. `held` is a leftover pointer Object Lock kept in place (see
    /// [`FinalUpload::held_pointer`]).
    async fn start_upload(
        &self,
        request: &DestinationPrepareRequest,
        part_size: usize,
        pointer: StoragePath,
        fact: PrepareFact,
        held: Option<Vec<u8>>,
    ) -> Result<PreparedStage, StorageRoleFailure> {
        let path = request.prepare.final_destination.path();
        let upload_id = self
            .protocol
            .begin_multipart(path.as_str())
            .await
            .map_err(|error| role_failure(path, Operation::Prepare, error))?;
        let mut upload = FinalUpload::new(request, upload_id, part_size as u64, pointer)?;
        upload.held_pointer = held;
        let mut stage = self.upload_stage(request, upload, 0, fact);
        if !self.pointer_at_prepare(request) {
            stage = stage.disable_recovery();
            if !self.pointer_before_checkpoint(request) {
                return Ok(stage);
            }
        }
        let upload =
            of(&stage).ok_or_else(|| failure(path, Operation::Prepare, FailureClass::Internal))?;
        if let Err(error) = self.write_pointer(&stage, upload, false).await {
            // Nothing names this new upload unless the PUT stored the pointer after all; then the
            // next prepare finds a pointer without its upload and cleans it up.
            let aborted = self
                .protocol
                .abort_multipart(path.as_str(), &upload.upload_id)
                .await;
            if let Err(abort) = cleanup_result(path, aborted) {
                tracing::warn!(path = %path.as_str(), ?abort, "could not abort a new S3 upload");
            }
            return Err(error);
        }
        Ok(stage)
    }

    /// Whether a fresh upload is recoverable from prepare, pointer written: a `recoverable` one
    /// over the automatic interval (D3: a pointer only for checkpointed objects over 64 MiB). The
    /// expert
    /// destination half asks for every checkpointed object over one chunk; a smaller one keeps
    /// no pointer and is not resumable.
    fn pointer_at_prepare(&self, request: &DestinationPrepareRequest) -> bool {
        request.recoverable
            && request
                .prepare
                .source
                .size
                .is_none_or(|size| size > self.checkpoint_interval)
    }

    /// Whether an upload that is not recoverable yet still writes its pointer at once: a
    /// resumable one of known size over the automatic interval — the one the engine arms a
    /// deferred checkpoint for (`plan_request` in `transfer/engine.rs`; keep the two in step), and a
    /// `Checkpointed` native copy, whose fill turns recovery on at the interval (ADR-0006 C18). A
    /// crash before that checkpoint then leaves an upload the next prepare resumes from its listed
    /// parts, instead of parts without a pointer, which it could only abort. Recovery still turns
    /// on at the checkpoint: a failure or cancellation before it discards the upload and pointer.
    fn pointer_before_checkpoint(&self, request: &DestinationPrepareRequest) -> bool {
        request.resume == ResumeMode::Discover
            && request
                .prepare
                .source
                .size
                .is_some_and(|size| size > self.checkpoint_interval)
    }

    async fn fence(&self, upload: &FinalUpload) -> Result<Fence, StorageRoleFailure> {
        let found =
            upload_pointer::read(&*self.protocol, &upload.pointer, MAX_POINTER_BYTES + 1).await?;
        Ok(match found {
            None if upload.pointer_written() => Fence::TakenOver,
            None => Fence::Ours { pointer: false },
            // The leftover Object Lock kept in place: no pointer of anyone's, until ours is written.
            Some(stored)
                if !upload.pointer_written()
                    && upload.held_pointer.as_deref() == Some(stored.bytes.as_slice()) =>
            {
                Fence::Ours { pointer: false }
            }
            Some(stored)
                if DestinationPointer::decode(&stored.bytes)
                    .is_ok_and(|found| Some(found.extension) == upload.extension()) =>
            {
                Fence::Ours { pointer: true }
            }
            Some(_) => Fence::TakenOver,
        })
    }

    /// Writes the pointer: unless `take_over`, only while the pointer is still this stage's.
    async fn write_pointer(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
        take_over: bool,
    ) -> Result<(), StorageRoleFailure> {
        let path = stage.final_destination.path();
        if !take_over && matches!(self.fence(upload).await?, Fence::TakenOver) {
            return Err(taken_over(path, Operation::Write));
        }
        let internal = || failure(path, Operation::Write, FailureClass::Internal);
        let bytes = DestinationPointer {
            binding: stage.recovery_binding,
            transfer_identity: upload.transfer_identity,
            durable_prefix: None,
            extension: upload.extension().ok_or_else(internal)?,
        }
        .encode()
        .map_err(|_| internal())?;
        let version = upload_pointer::put(&*self.protocol, &upload.pointer, bytes.clone()).await?;
        upload.record_pointer(version, bytes);
        upload.pointer_written.store(true, Ordering::Release);
        Ok(())
    }

    /// Sends the parts after the resumed prefix; the first deferred checkpoint turns recovery on
    /// (and writes the pointer, if prepare did not). The upload is completed by `publish`.
    pub(super) async fn write_final_upload(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
        input: ByteStream,
    ) -> Result<WriteEvidence, StorageRoleFailure> {
        let path = stage.final_destination.path();
        let prefix = {
            let current = upload.lock();
            if current.written.is_some() {
                return Err(entry(
                    path,
                    Operation::Write,
                    "S3 upload is already written",
                ));
            }
            current.parts.clone()
        };
        let resumed_parts = prefix.len();
        let hook = PointerCheckpoint {
            adapter: self,
            stage,
            upload,
        };
        let checkpoint = stage
            .deferred_checkpoint
            .as_ref()
            .filter(|_| !stage.recovery_enabled())
            .map(|checkpoint| (checkpoint.interval_bytes, &hook as &dyn PartsCheckpoint));
        let target = PartTarget {
            stage: Some(stage),
            path,
            key: path.as_str(),
            upload_id: &upload.upload_id,
            part_size: upload.part_size,
            max_inflight: upload.streamed_inflight(self.protocol.write_concurrency()),
            checkpoint,
        };
        let sent = self.upload_parts(&target, prefix, input).await?;
        let size = stage.write_offset + sent.bytes;
        upload.record_written(path, sent, resumed_parts, size)?;
        Ok(WriteEvidence {
            persisted_bytes: size,
        })
    }

    /// The bytes the upload holds, once the pointer is confirmed still this stage's.
    pub(super) async fn observe_final_upload(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
    ) -> Result<CheckpointObservation, StorageRoleFailure> {
        if matches!(self.fence(upload).await?, Fence::TakenOver) {
            return Err(taken_over(
                stage.final_destination.path(),
                Operation::Observe,
            ));
        }
        let durable_prefix = upload.lock().written.unwrap_or(stage.write_offset);
        Ok(CheckpointObservation { durable_prefix })
    }

    /// Keeps tags for the object, which exists only once the upload completes.
    pub(super) fn apply_final_upload_metadata(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
        mutation: MetadataMutation,
        cancel: &CancellationToken,
    ) -> Result<(), StorageRoleFailure> {
        if self.metadata.is_none() {
            return Err(metadata_unavailable(stage));
        }
        let path = stage.final_destination.path();
        let tags = single::pending_tags(path, self.tags_supported, mutation, cancel)?;
        upload.lock().tags = Some(tags);
        Ok(())
    }

    /// Completes the upload, while it is still this stage's, then sets the pending tags and
    /// removes the pointer.
    pub(super) async fn publish_final_upload(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
        request: &PublishRequest,
    ) -> Result<PublicationEvidence, PublicationFailure> {
        let path = stage.final_destination.path();
        self.validate(stage).map_err(unchanged)?;
        if request.cancel.is_cancelled() {
            return Err(unchanged(cancelled(path, Operation::Publish)));
        }
        let (parts, md5_etags, tags) = {
            let current = upload.lock();
            if current.written != Some(request.expected_size) || current.published.is_some() {
                return Err(unchanged(entry(
                    path,
                    Operation::Publish,
                    "S3 upload content differs from the published size",
                )));
            }
            (
                current.parts.clone(),
                current.md5_etags,
                current.tags.clone(),
            )
        };
        let Fence::Ours { pointer } = self.fence(upload).await.map_err(unchanged)? else {
            return Err(unchanged(taken_over(path, Operation::Publish)));
        };
        let facts = self
            .complete_final_upload(path, upload, &parts, md5_etags, request.expected_size)
            .await?;
        upload.lock().published = Some(facts.clone());
        self.finish_published(path, upload, tags, pointer).await?;
        Ok(PublicationEvidence {
            final_destination: path.clone(),
            disposition: PublicationDisposition::Published,
            version: facts.version_id,
        })
    }

    /// After the completion: sets the pending tags (a failure reports the final key changed), then
    /// deletes the pointer, when this stage has one. The object is committed, so failing to delete
    /// the pointer is only a warning: the pointer, its upload gone, is cleaned up by the key's next
    /// prepare, and failing now would have a retry add another version.
    async fn finish_published(
        &self,
        path: &StoragePath,
        upload: &FinalUpload,
        tags: Option<Vec<ObjectTag>>,
        pointer: bool,
    ) -> Result<(), PublicationFailure> {
        if let Some(tags) = tags {
            self.protocol
                .put_tags(path.as_str(), &tags)
                .await
                .map_err(|error| changed(role_failure(path, Operation::Publish, error)))?;
        }
        if pointer && let Err(error) = self.delete_own_pointer(upload).await {
            tracing::warn!(
                pointer = %upload.pointer.as_str(),
                ?error,
                "could not delete the S3 upload pointer after publishing; the next prepare of the key cleans it up"
            );
        }
        Ok(())
    }

    /// `CompleteMultipartUpload` with every part. When every part this stage sent came back with
    /// its MD5 as `ETag` and the object's `ETag` has the multipart form, it must be the composite
    /// of the parts; a mismatch is a permanent `Corruption` with the final key changed.
    async fn complete_final_upload(
        &self,
        path: &StoragePath,
        upload: &FinalUpload,
        parts: &[(i32, String)],
        md5_etags: Option<bool>,
        size: u64,
    ) -> Result<S3WriteFacts, PublicationFailure> {
        let etags: Vec<String> = parts.iter().map(|part| part.1.clone()).collect();
        let expected = composite_etag(&etags);
        let facts = match self
            .protocol
            .complete_multipart(path.as_str(), &upload.upload_id, parts)
            .await
        {
            Ok(facts) => facts,
            Err(error) => {
                self.settle_completion(path, upload, size, expected.as_deref(), error)
                    .await?
            }
        };
        match expected {
            Some(expected)
                if md5_etags == Some(true)
                    && is_composite(&facts.etag)
                    && !single::same_etag(&facts.etag, &expected) =>
            {
                Err(changed(classified_entry(
                    path,
                    Operation::Publish,
                    FailureClass::Corruption,
                    Transience::Permanent,
                    "the completed S3 object's ETag is not the composite of its parts",
                )))
            }
            _ => Ok(facts),
        }
    }

    /// Settles a failed completion. Only a refusal the service answered before it could commit
    /// (a 4xx such as `InvalidPart`, `EntityTooSmall`, `AccessDenied`) leaves the final key
    /// unchanged. Any other failure may still complete on the server — a completion whose reply
    /// timed out can finish after `ListParts` still lists the upload — so an upload still listed,
    /// or one that cannot be listed, reports the final key changed. One that is gone
    /// (`NoSuchUpload`) completed if the key's latest version has our size and composite `ETag`,
    /// and that version is claimed (ADR-0006 C17; none in an unversioned bucket); otherwise
    /// something else happened to the key (`Conflict`, changed).
    async fn settle_completion(
        &self,
        path: &StoragePath,
        upload: &FinalUpload,
        size: u64,
        expected: Option<&str>,
        error: S3ProtocolFailure,
    ) -> Result<S3WriteFacts, PublicationFailure> {
        if refused_before_commit(&error) {
            return Err(unchanged(role_failure(path, Operation::Publish, error)));
        }
        let key = path.as_str();
        match self.protocol.list_parts(key, &upload.upload_id).await {
            Err(listed) if is_not_found(&listed) => {}
            _ => return Err(changed(role_failure(path, Operation::Publish, error))),
        }
        let completed = match expected {
            Some(expected) => completed_object(&*self.protocol, path, size, expected, true).await,
            None => None,
        };
        match completed {
            Some(facts) => {
                let aborted = self.protocol.abort_multipart(key, &upload.upload_id).await;
                if let Err(error) = cleanup_result(path, aborted) {
                    tracing::warn!(path = %key, ?error, "could not abort a reconciled S3 upload");
                }
                Ok(facts)
            }
            None => Err(changed(classified_entry(
                path,
                Operation::Publish,
                FailureClass::Conflict,
                Transience::Permanent,
                "the S3 upload is gone and the final object is not the one it would complete",
            ))),
        }
    }

    /// Removes the pointer, then aborts the upload — only while the pointer is still this
    /// stage's: a taken-over upload is the other writer's now. A pointer that cannot be deleted
    /// does not stop the abort (a held one is no failure at all, another failure is reported
    /// after the abort). The final key is never touched.
    pub(super) async fn discard_final_upload(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
    ) -> Result<(), StorageRoleFailure> {
        let Fence::Ours { pointer } = self.fence(upload).await? else {
            return Ok(());
        };
        // The upload is aborted even when the pointer could not be deleted; that failure is
        // still reported.
        let removed = if pointer {
            self.delete_own_pointer(upload).await.map(drop)
        } else {
            Ok(())
        };
        let path = stage.final_destination.path();
        cleanup_result(
            path,
            self.protocol
                .abort_multipart(path.as_str(), &upload.upload_id)
                .await,
        )?;
        removed
    }

    /// Deletes the pointer this stage wrote, by the version its write reported (ADR-0006 C17).
    async fn delete_own_pointer(
        &self,
        upload: &FinalUpload,
    ) -> Result<upload_pointer::Removal, StorageRoleFailure> {
        let (version, stale) = {
            let state = upload.lock();
            (state.pointer_version.clone(), state.stale_pointers.clone())
        };
        let stale: Vec<&[u8]> = stale.iter().map(Vec::as_slice).collect();
        upload_pointer::delete(&*self.protocol, &upload.pointer, version.as_deref(), &stale).await
    }

    /// Reads the completed object back, pinned to what the completion created.
    pub(super) async fn verify_final_upload(
        &self,
        stage: &PreparedStage,
        upload: &FinalUpload,
        request: &VerifyRequest,
    ) -> Result<VerificationEvidence, StorageRoleFailure> {
        let path = stage.final_destination.path();
        self.validate(stage)?;
        let facts = upload.lock().published.clone().ok_or_else(|| {
            entry(
                path,
                Operation::Verify,
                "S3 object is verified only after publication",
            )
        })?;
        single::verify_written(self, path, facts, request).await
    }
}

#[cfg(test)]
#[path = "at_destination_tests.rs"]
mod tests;
